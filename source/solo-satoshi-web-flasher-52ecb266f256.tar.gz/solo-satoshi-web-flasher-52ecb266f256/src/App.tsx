import { useEffect, useMemo, useState } from 'react'
import { CheckCircle2, ChevronRight, CircleAlert, ExternalLink, GitFork, RefreshCw, ShieldCheck, Usb } from 'lucide-react'
import { siDiscord, siFacebook, siInstagram, siReddit, siTiktok, siX, siYoutube } from 'simple-icons/icons'
import './App.css'
import { familyLabels } from './deviceCatalog'
import { getChannelSources, getCompatibleReleaseSources, getLatestModelImages } from './lib/compatibility'
import { downloadAndVerify, loadManifest } from './lib/firmware'
import { flashFirmware, requestMinerPort, supportsWebSerial } from './lib/flasher'
import type { FirmwareFamily, FirmwareImage, FirmwareManifest, FlashStatus, ReleaseChannel } from './types'

const initialStatus: FlashStatus = { stage: 'idle', message: 'Ready to flash', progress: 0 }
const formatDate = (date: string) => new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(date))
const socialLinks = [
  { label: 'YouTube', href: 'https://www.youtube.com/@solo.satoshi', icon: siYoutube },
  { label: 'X', href: 'https://twitter.com/SoloSatoshi', icon: siX },
  { label: 'TikTok', href: 'https://tiktok.com/@solo.satoshi', icon: siTiktok },
  { label: 'Facebook', href: 'https://www.facebook.com/people/Solo-Satoshi/61575323724787/', icon: siFacebook },
  { label: 'Instagram', href: 'https://www.instagram.com/solosatoshi_/', icon: siInstagram },
  { label: 'Reddit', href: 'https://www.reddit.com/r/SoloSatoshi/', icon: siReddit },
  { label: 'Discord', href: 'https://discord.gg/solosatoshi', icon: siDiscord },
]

function App() {
  const [manifest, setManifest] = useState<FirmwareManifest | null>(null)
  const [manifestError, setManifestError] = useState('')
  const [usingFallback, setUsingFallback] = useState(false)
  const [family, setFamily] = useState<FirmwareFamily>('bitaxe')
  const [familyConfirmed, setFamilyConfirmed] = useState(false)
  const [channel, setChannel] = useState<ReleaseChannel>('stable')
  const [channelConfirmed, setChannelConfirmed] = useState(false)
  const [minerPort, setMinerPort] = useState<SerialPort | null>(null)
  const [selectedModel, setSelectedModel] = useState('')
  const [selectedReleaseTag, setSelectedReleaseTag] = useState('')
  const [selectedBoard, setSelectedBoard] = useState('')
  const [keepSettings, setKeepSettings] = useState(false)
  const [status, setStatus] = useState<FlashStatus>(initialStatus)
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    loadManifest().then(({ manifest: value, fallback }) => {
      setManifest(value)
      setUsingFallback(fallback)
    }).catch((error: unknown) => setManifestError(error instanceof Error ? error.message : 'Firmware list could not be loaded.'))
  }, [])

  const channelSources = useMemo(() => getChannelSources(manifest, family, channel), [channel, family, manifest])
  const modelImages = useMemo(() => getLatestModelImages(manifest, family, channel, channelSources), [channel, channelSources, family, manifest])
  const modelOptions = useMemo(() => modelImages.filter((image, index, images) => images.findIndex((candidate) => candidate.model === image.model) === index), [modelImages])
  const boardOptions = useMemo(() => modelImages.filter((image) => image.model === selectedModel), [modelImages, selectedModel])
  const activeBoard = modelImages.some((image) => image.board === selectedBoard) ? selectedBoard : undefined
  const releaseSources = useMemo(() => getCompatibleReleaseSources(manifest, family, channel, activeBoard, channelSources), [activeBoard, channel, channelSources, family, manifest])
  const selectedSource = channel === 'beta' ? releaseSources[0] : releaseSources.find((item) => item.releaseTag === selectedReleaseTag)
  const selected = manifest?.firmware.find((image) =>
    image.family === family && image.channel === channel && image.board === activeBoard && image.releaseTag === selectedSource?.releaseTag
  )
  const betaAvailable = manifest?.sources.some((item) => item.family === family && item.channel === 'beta') ?? false
  const isBusy = ['downloading', 'connecting', 'flashing'].includes(status.stage)
  const serialAvailable = supportsWebSerial()

  async function connectMiner() {
    if (minerPort) {
      setMinerPort(null)
      setFamilyConfirmed(false)
      setChannelConfirmed(false)
      setSelectedModel('')
      setSelectedBoard('')
      setSelectedReleaseTag('')
      setStatus(initialStatus)
      return
    }
    try {
      setStatus({ stage: 'connecting', message: 'Choose the miner USB device.', progress: 0 })
      setMinerPort(await requestMinerPort())
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotFoundError') {
        setStatus(initialStatus)
        return
      }
      setStatus({ stage: 'error', message: error instanceof Error ? error.message : 'The USB device could not be selected.', progress: 0 })
    }
  }

  async function startFlash(image: FirmwareImage) {
    if (!minerPort) return
    setLogs([])
    try {
      setStatus({ stage: 'downloading', message: 'Downloading and verifying firmware…', progress: 0 })
      const firmware = await downloadAndVerify(image, (progress) => setStatus({ stage: 'downloading', message: 'Downloading and verifying firmware…', progress }))
      await flashFirmware(minerPort, firmware, keepSettings, {
        onConnecting: (message) => setStatus({ stage: 'connecting', message, progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: 'Installing firmware. Keep the miner connected.', progress }),
        onRestarting: (message) => setStatus({ stage: 'flashing', message, progress: 100 }),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: 'Flash successful.', progress: 100 })
    } catch (error) {
      setStatus({ stage: 'error', message: error instanceof Error ? error.message : 'The firmware update did not complete.', progress: 0 })
    }
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label="Solo Satoshi home (opens in a new tab)">
          <img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" />
          <span className="brand-name">SOLO SATOSHI</span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="https://www.solosatoshi.com/shop" target="_blank" rel="noopener noreferrer">Shop Hardware</a>
          <a href="#how-it-works">Guide</a>
          <a href="https://github.com/SoloSatoshi" target="_blank" rel="noopener noreferrer">GitHub <GitFork size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <h1><span className="headline-line">Update your miner</span><span className="headline-line"><span>with </span><span className="headline-accent">verified firmware.</span></span></h1>
            <p className="hero-summary">A precise, browser based installer for Bitaxe and NerdAxe devices.</p>
          </div>

          <div className="hero-bolt" aria-hidden="true">
            <div className="bolt-halo" />
            <div className="bolt-ring bolt-ring-one" />
            <div className="bolt-ring bolt-ring-two" />
            <svg className="bolt-mark" viewBox="0 0 260 360" role="presentation">
              <defs>
                <linearGradient id="bolt-gradient" x1="35" y1="30" x2="230" y2="330" gradientUnits="userSpaceOnUse">
                  <stop offset="0" stopColor="#f7931a" />
                  <stop offset="0.3" stopColor="#eb4b55" />
                  <stop offset="0.62" stopColor="#c71e82" />
                  <stop offset="1" stopColor="#54205a" />
                </linearGradient>
                <linearGradient id="bolt-highlight" x1="65" y1="40" x2="180" y2="300" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#fff4dd" stopOpacity="0.9" />
                  <stop offset="0.55" stopColor="#f8a8d3" stopOpacity="0.5" />
                  <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path className="bolt-shadow" d="M151 16 47 197h74l-19 147 111-199h-76z" />
              <path className="bolt-body" d="M151 16 47 197h74l-19 147 111-199h-76z" />
              <path className="bolt-highlight" d="M151 16 72 181h62l-21 120 78-140h-72z" />
            </svg>
            <span className="bolt-spark spark-one" />
            <span className="bolt-spark spark-two" />
            <span className="bolt-spark spark-three" />
          </div>
        </section>

        <section className="installer" id="installer" aria-labelledby="installer-title">
          <div className="installer-heading">
            <div>
              <p className="section-label">FIRMWARE INSTALLER</p>
              <h2 id="installer-title">Configure the update</h2>
            </div>
            <div className="verified-mark"><ShieldCheck size={17} /><span>Verified release files</span></div>
          </div>

          <div className="installer-layout">
            <aside className="process-rail" aria-label="Flashing process">
              <ol>
                <li className={minerPort ? 'complete' : 'active'} aria-current={!minerPort ? 'step' : undefined}><span>1</span><div><strong>Connect</strong><small>Approve the USB device</small></div></li>
                <li className={!minerPort ? 'locked' : familyConfirmed ? 'complete' : 'active'} aria-current={minerPort && !familyConfirmed ? 'step' : undefined}><span>2</span><div><strong>Miner family</strong><small>Choose Bitaxe or NerdAxe</small></div></li>
                <li className={!familyConfirmed ? 'locked' : channelConfirmed ? 'complete' : 'active'} aria-current={familyConfirmed && !channelConfirmed ? 'step' : undefined}><span>3</span><div><strong>Release channel</strong><small>Latest or prerelease (if available)</small></div></li>
                <li className={!channelConfirmed ? 'locked' : selectedModel ? 'complete' : 'active'} aria-current={channelConfirmed && !selectedModel ? 'step' : undefined}><span>4</span><div><strong>Model</strong><small>Select the exact miner</small></div></li>
                <li className={!selectedModel ? 'locked' : activeBoard ? 'complete' : 'active'} aria-current={selectedModel && !activeBoard ? 'step' : undefined}><span>5</span><div><strong>Board match</strong><small>Confirm hardware support</small></div></li>
                <li className={!activeBoard ? 'locked' : selected ? 'complete' : 'active'} aria-current={activeBoard && !selected ? 'step' : undefined}><span>6</span><div><strong>Version</strong><small>Choose compatible firmware</small></div></li>
                <li className={!selected ? 'locked' : status.stage === 'idle' ? 'active' : 'complete'} aria-current={selected && status.stage === 'idle' ? 'step' : undefined}><span>7</span><div><strong>Settings</strong><small>Choose what to preserve</small></div></li>
                <li className={!selected || status.stage === 'idle' ? 'locked' : 'active'} aria-current={selected && status.stage !== 'idle' ? 'step' : undefined}><span>8</span><div><strong>Install</strong><small>Keep power connected</small></div></li>
              </ol>
            </aside>

            <div className="flasher-panel">
              <section className="flow-stage connect-stage" aria-label="Connect miner">
                {!serialAvailable && <div className="browser-warning"><CircleAlert size={20} /><div><strong>Use Chrome, Edge, or Brave on a desktop.</strong><span>Your current browser does not support USB flashing.</span></div></div>}
                <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={connectMiner}>
                  {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                  {minerPort ? 'Disconnect miner' : 'Connect miner'}
                </button>
                <p className="stage-note">Your browser will ask you to approve the miner's USB serial device.</p>
              </section>

              <section className={`flow-stage family-stage ${!minerPort ? 'locked' : ''}`} aria-label="Choose miner family" aria-disabled={!minerPort}>
                {manifestError ? (
                  <div className="browser-warning"><CircleAlert size={20} /><div><strong>Firmware unavailable</strong><span>{manifestError}</span></div></div>
                ) : (
                  <fieldset className="field-group">
                    <legend>Miner family</legend>
                    <div className="family-tabs">
                      {(Object.keys(familyLabels) as FirmwareFamily[]).map((key) => (
                        <button type="button" className={`${familyConfirmed && family === key ? 'active' : ''} family-${key}`} aria-pressed={familyConfirmed && family === key} onClick={() => { setFamily(key); setFamilyConfirmed(true); setChannel('stable'); setChannelConfirmed(false); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setStatus(initialStatus) }} disabled={!minerPort || isBusy} key={key}>
                          <img className="family-wordmark" src={`${import.meta.env.BASE_URL}device-logos/${key}-wordmark.webp`} alt={familyLabels[key]} width={key === 'bitaxe' ? 370 : 520} height={key === 'bitaxe' ? 150 : 112} decoding="async" />
                        </button>
                      ))}
                    </div>
                  </fieldset>
                )}
              </section>

              <section className={`flow-stage channel-stage ${!familyConfirmed ? 'locked' : ''}`} aria-label="Choose release channel" aria-disabled={!familyConfirmed}>
                  <fieldset className="field-group">
                    <legend>Release channel</legend>
                    <div className="channel-tabs">
                      <button type="button" className={channelConfirmed && channel === 'stable' ? 'active' : ''} aria-pressed={channelConfirmed && channel === 'stable'} onClick={() => { setChannel('stable'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>Latest Releases <small>Recommended</small></button>
                      {betaAvailable ? <button type="button" className={channelConfirmed && channel === 'beta' ? 'active beta' : 'beta'} aria-pressed={channelConfirmed && channel === 'beta'} onClick={() => { setChannel('beta'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>Prereleases <small>Beta releases</small></button> : <button type="button" className="unavailable" disabled>No prereleases available</button>}
                    </div>
                  </fieldset>
                  {channel === 'beta' && <div className="beta-warning"><CircleAlert size={20} /><div><strong>Prerelease firmware is for testing.</strong><span>It may contain bugs, behave unexpectedly, or require recovery. The latest production release remains the recommended choice.</span></div></div>}
              </section>

              <section className={`flow-stage model-stage ${!channelConfirmed ? 'locked' : ''}`} aria-label="Choose miner model" aria-disabled={!channelConfirmed}>
                    <div className="field-group">
                      <label htmlFor="model">Model</label>
                      <select id="model" value={selectedModel} onChange={(event) => {
                        const model = event.target.value
                        setSelectedModel(model)
                        setSelectedBoard(family === 'nerdaxe' ? modelImages.find((image) => image.model === model)?.board ?? '' : '')
                        setSelectedReleaseTag('')
                        setStatus(initialStatus)
                      }} disabled={!manifest || !channelConfirmed || isBusy}>
                        <option value="" disabled>Select model</option>
                        {modelOptions.map((image) => <option value={image.model} key={image.model}>{image.model}</option>)}
                      </select>
                    </div>
              </section>

              <section className={`flow-stage board-stage ${!selectedModel ? 'locked' : ''}`} aria-label="Match board version" aria-disabled={!selectedModel}>
                    {family === 'bitaxe' ? (
                      <div className="field-group">
                        <label htmlFor="board">Board version</label>
                        <select id="board" value={selectedBoard} onChange={(event) => { setSelectedBoard(event.target.value); setSelectedReleaseTag(''); setStatus(initialStatus) }} disabled={!selectedModel || isBusy}>
                          <option value="" disabled>Select board version</option>
                          {boardOptions.map((image) => <option value={image.board} key={image.board}>{image.board}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!selectedModel ? 'disabled' : ''}`}><span>BOARD MATCH</span><strong>{selectedBoard || 'Select a model first'}</strong><small>Matched automatically for the selected NerdAxe model</small></div>
                    )}
              </section>

              <section className={`flow-stage version-stage ${!activeBoard ? 'locked' : ''}`} aria-label="Choose firmware version" aria-disabled={!activeBoard}>
                    {channel === 'stable' ? (
                      <div className="field-group">
                        <label htmlFor="version">Version</label>
                        <select id="version" value={selectedReleaseTag} onChange={(event) => { setSelectedReleaseTag(event.target.value); setStatus(initialStatus) }} disabled={!activeBoard || isBusy}>
                          <option value="" disabled>Select firmware version</option>
                          {releaseSources.map((item, index) => <option value={item.releaseTag} key={item.releaseTag}>{item.releaseTag}{index === 0 ? '  •  Latest' : ''}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!activeBoard ? 'disabled' : ''}`}><span>VERSION</span><strong>{selected?.releaseTag ?? 'Select a model'}</strong>{selectedSource && <small>{formatDate(selectedSource.publishedAt)}</small>}</div>
                    )}
              </section>

              <section className={`flow-stage settings-stage ${!selected ? 'locked' : ''}`} aria-label="Choose settings preservation" aria-disabled={!selected}>
                  <label className={`settings-row ${!selected ? 'disabled' : ''}`}>
                    <span className="settings-copy"><strong>Preserve miner settings</strong><small>Keep Wi-Fi, pool, and saved configuration</small></span>
                    <span className="switch"><input type="checkbox" checked={keepSettings} onChange={(event) => setKeepSettings(event.target.checked)} disabled={!selected || isBusy} /><i /></span>
                  </label>
              </section>

              <section className={`flow-stage install-stage ${!selected ? 'locked' : ''}`} aria-label="Install firmware" aria-disabled={!selected}>
                  {status.stage !== 'idle' && (
                    <div className={`status-panel ${status.stage}`} role="status">
                      <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{['downloading', 'flashing'].includes(status.stage) && <strong>{status.progress}%</strong>}</div>
                      {['downloading', 'flashing'].includes(status.stage) && <progress className="progress-track" max="100" value={status.progress} aria-label="Firmware update progress">{status.progress}%</progress>}
                      {status.stage === 'complete' && <p>You can disconnect USB after the miner restarts.</p>}
                    </div>
                  )}

                  <button className="flash-button" type="button" disabled={!minerPort || !selected || !serialAvailable || isBusy} onClick={() => selected && startFlash(selected)}><Usb size={19} /> {isBusy ? 'Update in progress…' : 'Flash firmware'} <ChevronRight size={18} /></button>
                  <p className="button-note">{!minerPort ? 'Connect your miner to unlock hardware selection.' : !selected ? 'Complete each selection above to unlock flashing.' : 'Keep USB and power connected until the miner restarts.'}</p>
                  {usingFallback && <p className="fallback-note">Using the most recent bundled firmware list while the update service reconnects.</p>}
                  {logs.length > 0 && <details className="logs"><summary>Technical log</summary><pre>{logs.join('\n')}</pre></details>}
              </section>
            </div>
          </div>
        </section>

        <section className="preflight" id="how-it-works">
          <div className="preflight-intro">
            <p className="section-label">BEFORE CONNECTING</p>
            <h2>Three checks before you begin.</h2>
            <p>A careful setup prevents most flashing problems. Complete these checks before opening the USB connection.</p>
          </div>
          <ol className="preflight-list">
            <li><span>1</span><div><strong>Use a data cable</strong><p>Charge-only USB cables cannot communicate with the miner.</p></div></li>
            <li><span>2</span><div><strong>Match the board number</strong><p>Read the number printed on the device and select the exact match.</p></div></li>
            <li><span>3</span><div><strong>Maintain stable power</strong><p>Keep power and USB connected until the miner restarts.</p></div></li>
          </ol>
        </section>

        <section className="provenance">
          <div className="provenance-icon"><ShieldCheck size={23} /></div>
          <div><p className="section-label">VERIFIABLE BY DESIGN</p><h2>Firmware provenance you can inspect.</h2><p>Release files come from the official open source projects and are matched against the SHA-256 checksums published by GitHub.</p></div>
          <div className="source-links">{selected && <a href={selected.releaseUrl} target="_blank" rel="noopener noreferrer">View release <ExternalLink size={14} /></a>}{selectedSource && <a href={selectedSource.sourceArchiveUrl} target="_blank" rel="noopener noreferrer">Download source <ExternalLink size={14} /></a>}</div>
        </section>

        <section className="device-support" aria-labelledby="support-title">
          <div className="support-heading"><p className="section-label">DEVICE SUPPORT</p><h2 id="support-title">One tool for both firmware families.</h2><p>The model list is generated from current official releases, so new supported factory images appear automatically.</p></div>
          <div className="support-list">
            <article><h3>Bitaxe</h3><p>Gamma, Gamma Duo, Gamma Turbo, Hex, Max, Supra, SupraHex, Ultra, GammaHex, and Naja Duo board revisions.</p></article>
            <article><h3>NerdAxe</h3><p>NerdAxe, NerdAxe Gamma, NerdEKO, NerdHaxe Gamma, NerdOCTAXE Gamma, NerdOCTAXE+, NerdQAxe+, NerdQAxe++, NerdQX, Q1370, and Q1373.</p></article>
          </div>
        </section>

        <section className="faq" id="faq" aria-labelledby="faq-title">
          <div><p className="section-label">QUESTIONS</p><h2 id="faq-title">What to know.</h2></div>
          <div className="faq-list">
            <details><summary>How do I flash firmware with the Solo Satoshi Web Flasher?</summary><p>Connect and approve the miner's USB serial device, choose the firmware family and release channel, select the exact model and Bitaxe board revision when applicable, then select a compatible version. Choose whether to preserve settings and keep USB and power connected until installation and restart finish.</p></details>
            <details><summary>Which browsers support the web flasher?</summary><p>Use a current desktop version of Google Chrome, Microsoft Edge, or Brave with Web Serial support. Safari, Firefox, and mobile browsers do not currently support USB flashing with this tool.</p></details>
            <details><summary>Can the flasher preserve my miner settings?</summary><p>Yes. Preserve miner settings leaves the device NVS settings area untouched while updating the remaining firmware. Record important settings before every update as a precaution.</p></details>
            <details><summary>How is firmware verified before flashing?</summary><p>The release automation verifies each downloaded file against the digest published by GitHub. Your browser calculates and checks the firmware SHA-256 checksum again before writing it to the miner.</p></details>
            <details><summary>Which Bitaxe and NerdAxe models are supported?</summary><p>The supported model list is generated from current official ESP-Miner releases. Select the exact model and board revision printed on your miner before flashing.</p></details>
            <details><summary>Where does the firmware come from?</summary><p>Firmware comes from the official ESP-Miner repositories for Bitaxe and NerdAxe devices. Every listed file links to its upstream GitHub release and corresponding source archive.</p></details>
            <details><summary>Can I test prerelease firmware?</summary><p>Yes. When an official prerelease is newer than the latest production release, select the Prereleases channel. Prerelease firmware may contain bugs or require recovery, so the Latest Releases channel remains recommended.</p></details>
          </div>
        </section>

        <section className="legal-notice" aria-labelledby="legal-title">
          <div>
            <p className="section-label">POLICIES</p>
            <h2 id="legal-title">Use the flasher with confidence.</h2>
          </div>
          <div className="legal-copy">
            <p>This tool communicates with your selected miner directly through your browser. Review how the service handles data, the risks of installing open source firmware, and the terms that govern your use before flashing.</p>
            <nav aria-label="Legal policies">
              <a href={`${import.meta.env.BASE_URL}privacy.html`}>Privacy Policy</a>
              <a href={`${import.meta.env.BASE_URL}terms.html`}>Terms of Service</a>
              <a href={`${import.meta.env.BASE_URL}licenses.html`}>Licenses and Source</a>
            </nav>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <a className="brand footer-brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label="Solo Satoshi home (opens in a new tab)"><img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" /><span className="brand-name">SOLO SATOSHI</span></a>
          <nav className="social-links" aria-label="Solo Satoshi social media">
            {socialLinks.map(({ label, href, icon }) => (
              <a href={href} target="_blank" rel="me noopener noreferrer" aria-label={`${label} (opens in a new tab)`} title={label} key={label}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d={icon.path} /></svg>
              </a>
            ))}
          </nav>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Solo Satoshi LLC. All rights reserved.</span>
          <nav aria-label="Footer policies"><a href={`${import.meta.env.BASE_URL}privacy.html`}>Privacy</a><a href={`${import.meta.env.BASE_URL}terms.html`}>Terms</a><a href={`${import.meta.env.BASE_URL}licenses.html`}>Licenses</a></nav>
        </div>
      </footer>
    </div>
  )
}

export default App
