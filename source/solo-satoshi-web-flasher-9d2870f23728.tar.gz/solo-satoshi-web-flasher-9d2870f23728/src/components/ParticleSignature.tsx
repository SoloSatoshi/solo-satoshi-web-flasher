import { useEffect, useRef } from 'react'

interface Particle {
  x: number
  y: number
  targetX: number
  targetY: number
  velocityX: number
  velocityY: number
  radius: number
  depth: number
  phase: number
  tone: number
}

const PARTICLE_COLORS = [
  'rgba(84, 32, 90, .92)',
  'rgba(199, 30, 130, .96)',
  'rgba(235, 75, 85, .94)',
  'rgba(247, 147, 26, .92)',
]

export default function ParticleSignature() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const context = canvas.getContext('2d', { alpha: true })
    if (!context) return
    const surface: HTMLCanvasElement = canvas
    const drawingContext: CanvasRenderingContext2D = context

    const particles: Particle[] = []
    const pointer = { x: -10_000, y: -10_000, active: false }
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let width = 0
    let height = 0
    let frame = 0
    let visible = true
    let resizeTimer = 0

    function buildParticles() {
      const bounds = surface.getBoundingClientRect()
      width = Math.max(1, Math.round(bounds.width))
      height = Math.max(1, Math.round(bounds.height))
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 2)
      surface.width = Math.round(width * pixelRatio)
      surface.height = Math.round(height * pixelRatio)
      drawingContext.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0)

      const mask = document.createElement('canvas')
      mask.width = width
      mask.height = height
      const maskContext = mask.getContext('2d', { willReadFrequently: true })
      if (!maskContext) return
      const fontSize = Math.min(150, width / 7.35)
      maskContext.fillStyle = '#fff'
      maskContext.font = `800 ${fontSize}px "Manrope Variable", sans-serif`
      maskContext.textAlign = 'center'
      maskContext.textBaseline = 'middle'
      maskContext.fillText('SOLO SATOSHI', width / 2, height / 2)
      const pixels = maskContext.getImageData(0, 0, width, height).data
      const sampleGap = width >= 900 ? 3 : width >= 620 ? 4 : 5
      const next: Particle[] = []

      for (let y = 0; y < height; y += sampleGap) {
        for (let x = 0; x < width; x += sampleGap) {
          if (pixels[(y * width + x) * 4 + 3] < 100) continue
          const depth = Math.random()
          next.push({
            x,
            y,
            targetX: x,
            targetY: y,
            velocityX: 0,
            velocityY: 0,
            radius: .65 + depth * 1.25,
            depth,
            phase: Math.random() * Math.PI * 2,
            tone: depth > .94 ? 3 : depth > .78 ? 2 : depth > .36 ? 1 : 0,
          })
        }
      }
      particles.splice(0, particles.length, ...next)
      draw(0)
    }

    function draw(time: number) {
      drawingContext.clearRect(0, 0, width, height)
      drawingContext.globalCompositeOperation = 'lighter'

      if (!reduceMotion) {
        const repulsionRadius = Math.min(125, width * .14)
        for (const particle of particles) {
          const spring = .018 + particle.depth * .012
          const floatScale = .7 + particle.depth * 1.5
          const floatingX = Math.sin(time * .00072 + particle.phase) * floatScale
          const floatingY = Math.cos(time * .0009 + particle.phase * 1.31) * floatScale
          particle.velocityX += (particle.targetX + floatingX - particle.x) * spring
          particle.velocityY += (particle.targetY + floatingY - particle.y) * spring

          if (pointer.active) {
            const deltaX = particle.x - pointer.x
            const deltaY = particle.y - pointer.y
            const distanceSquared = deltaX * deltaX + deltaY * deltaY
            if (distanceSquared < repulsionRadius * repulsionRadius) {
              const distance = Math.max(1, Math.sqrt(distanceSquared))
              const force = (1 - distance / repulsionRadius) ** 2 * (2.8 + particle.depth * 3.4)
              particle.velocityX += (deltaX / distance) * force - (deltaY / distance) * force * .16
              particle.velocityY += (deltaY / distance) * force + (deltaX / distance) * force * .16
            }
          }

          const shimmer = Math.sin(time * .0016 + particle.phase) * .004 * particle.depth
          particle.velocityX += shimmer
          particle.velocityY -= shimmer * .55
          particle.velocityX *= .88
          particle.velocityY *= .88
          particle.x += particle.velocityX
          particle.y += particle.velocityY
        }
      }

      drawingContext.fillStyle = 'rgba(199, 30, 130, .1)'
      for (let index = 0; index < particles.length; index += 5) {
        const particle = particles[index]
        const halo = particle.radius * 4.5
        drawingContext.beginPath()
        drawingContext.arc(particle.x, particle.y, halo, 0, Math.PI * 2)
        drawingContext.fill()
      }

      for (let tone = 0; tone < PARTICLE_COLORS.length; tone += 1) {
        drawingContext.fillStyle = PARTICLE_COLORS[tone]
        for (const particle of particles) {
          if (particle.tone !== tone) continue
          const pulse = reduceMotion ? 1 : .88 + Math.sin(time * .002 + particle.phase) * .12
          const radius = particle.radius * pulse
          drawingContext.beginPath()
          drawingContext.arc(particle.x, particle.y, radius, 0, Math.PI * 2)
          drawingContext.fill()
        }
      }
      drawingContext.globalCompositeOperation = 'source-over'
    }

    function animate(time: number) {
      if (!visible) {
        frame = 0
        return
      }
      draw(time)
      frame = window.requestAnimationFrame(animate)
    }

    function updatePointer(event: PointerEvent) {
      const bounds = surface.getBoundingClientRect()
      pointer.x = event.clientX - bounds.left
      pointer.y = event.clientY - bounds.top
      pointer.active = true
    }

    function clearPointer() {
      pointer.active = false
    }

    const resizeObserver = new ResizeObserver(() => {
      window.clearTimeout(resizeTimer)
      resizeTimer = window.setTimeout(buildParticles, 100)
    })
    const visibilityObserver = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting
      if (visible && !reduceMotion && frame === 0) frame = window.requestAnimationFrame(animate)
    }, { rootMargin: '160px' })

    surface.addEventListener('pointermove', updatePointer)
    surface.addEventListener('pointerleave', clearPointer)
    surface.addEventListener('pointercancel', clearPointer)
    resizeObserver.observe(surface)
    visibilityObserver.observe(surface)
    void document.fonts.ready.then(() => {
      buildParticles()
      if (!reduceMotion && frame === 0) frame = window.requestAnimationFrame(animate)
    })

    return () => {
      window.cancelAnimationFrame(frame)
      window.clearTimeout(resizeTimer)
      resizeObserver.disconnect()
      visibilityObserver.disconnect()
      surface.removeEventListener('pointermove', updatePointer)
      surface.removeEventListener('pointerleave', clearPointer)
      surface.removeEventListener('pointercancel', clearPointer)
    }
  }, [])

  return (
    <section className="particle-signature" aria-label="Interactive Solo Satoshi particle artwork">
      <canvas ref={canvasRef} role="img" aria-label="Solo Satoshi formed from interactive magenta particles">
        SOLO SATOSHI
      </canvas>
    </section>
  )
}
