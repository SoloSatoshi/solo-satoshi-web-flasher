/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'

// https://vite.dev/config/
export default defineConfig(() => {
  const mujinaModule = process.env.VITE_ENABLE_MUJINA === 'true'
    ? './src/lib/k230.ts'
    : './src/lib/mujinaUnavailable.ts'
  const mujinaUiModule = process.env.VITE_ENABLE_MUJINA === 'true'
    ? './src/features/MujinaTool.tsx'
    : './src/features/MujinaUnavailable.tsx'

  return {
    base: './',
    build: {
      // The application is open source; production maps improve debuggability and
      // let browser quality audits verify every shipped first-party script.
      sourcemap: true,
    },
    plugins: [react()],
    resolve: {
      alias: {
        '#mujina': fileURLToPath(new URL(mujinaModule, import.meta.url)),
        '#mujina-ui': fileURLToPath(new URL(mujinaUiModule, import.meta.url)),
      },
    },
  }
})
