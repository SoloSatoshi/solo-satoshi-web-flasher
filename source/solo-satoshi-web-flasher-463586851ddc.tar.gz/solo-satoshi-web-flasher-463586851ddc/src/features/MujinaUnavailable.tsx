export default function MujinaUnavailable(_props: { onOpenAdvanced: () => void }) {
  return null
}
