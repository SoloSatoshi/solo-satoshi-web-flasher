/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import type { FirmwareFamily } from './types'

export const familyLabels: Record<FirmwareFamily, string> = {
  bitaxe: 'Bitaxe',
  bitforge: 'BitForge',
  nerdaxe: 'NerdAxe',
  nerdnos: 'NerdNOS',
}

export const TOUCH_BOARD = 'GT-TOUCH'
export const TOUCH_MODEL = 'Bitaxe Turbo Touch — Screen Only'

const AUTO_SELECTED_MODEL_FAMILIES = new Set<FirmwareFamily>(['bitforge', 'nerdnos'])

export function familyHasSingleModel(family: FirmwareFamily): boolean {
  return AUTO_SELECTED_MODEL_FAMILIES.has(family)
}

export function bootloaderCopyKeys(family: FirmwareFamily): { hint: string; failure: string } {
  if (family === 'bitforge') return { hint: 'bitforgeBootloaderHint', failure: 'bitforgeBootloaderFailed' }
  if (family === 'nerdnos') return { hint: 'nerdnosBootloaderHint', failure: 'nerdnosBootloaderFailed' }
  return { hint: 'bootloaderHint', failure: 'bootloaderFailed' }
}

export function displayModelName(family: FirmwareFamily, model: string): string {
  if (family !== 'bitaxe') return model
  if (model === TOUCH_MODEL) return 'Turbo Touch (Screen Only)'
  if (model === 'Bitaxe Hex') return 'UltraHex'
  return model.startsWith('Bitaxe ') ? model.slice('Bitaxe '.length) : model
}

export function orderModelChoices<T extends { model: string }>(family: FirmwareFamily, choices: T[]): T[] {
  const ordered = [...choices]
  if (family !== 'bitaxe') return ordered

  const moveBefore = (model: string, target: string) => {
    const modelIndex = ordered.findIndex((choice) => choice.model === model)
    const targetIndex = ordered.findIndex((choice) => choice.model === target)
    if (modelIndex < 0 || targetIndex < 0) return
    const [choice] = ordered.splice(modelIndex, 1)
    ordered.splice(ordered.findIndex((candidate) => candidate.model === target), 0, choice)
  }

  const moveToEnd = (model: string) => {
    const modelIndex = ordered.findIndex((choice) => choice.model === model)
    if (modelIndex < 0) return
    ordered.push(ordered.splice(modelIndex, 1)[0])
  }

  moveBefore(TOUCH_MODEL, 'Bitaxe Gamma Turbo')
  moveBefore('Bitaxe Gamma', 'Bitaxe Ultra')
  moveBefore('Bitaxe Supra', 'Bitaxe Ultra')
  moveToEnd('Bitaxe Max')
  return ordered
}

export const bitaxeBoardNames: Record<string, string> = {
  '102': 'Bitaxe Max',
  '201': 'Bitaxe Ultra',
  '202': 'Bitaxe Ultra',
  '203': 'Bitaxe Ultra',
  '204': 'Bitaxe Ultra',
  '205': 'Bitaxe Ultra',
  '207': 'Bitaxe Ultra',
  '302': 'Bitaxe Hex',
  '303': 'Bitaxe Hex',
  '400': 'Bitaxe Supra',
  '401': 'Bitaxe Supra',
  '402': 'Bitaxe Supra',
  '403': 'Bitaxe Supra',
  '600': 'Bitaxe Gamma',
  '601': 'Bitaxe Gamma',
  '602': 'Bitaxe Gamma',
  '603': 'Bitaxe Gamma',
  '650': 'Bitaxe Gamma Duo',
  '701': 'Bitaxe SupraHex',
  '702': 'Bitaxe SupraHex',
  '801': 'Bitaxe Gamma Turbo',
  '1201': 'Naja Duo',
  '1300': 'GammaHex',
}

export function friendlyModel(family: FirmwareFamily, board: string): string {
  if (family === 'bitaxe') return bitaxeBoardNames[board] ?? `Bitaxe board ${board}`
  if (family === 'bitforge') return board === 'Nano' ? 'BitForge Nano' : board
  if (family === 'nerdnos') return board === '100' ? 'NerdNOS' : board

  const names: Record<string, string> = {
    'NerdQAxe++': 'NerdQAxe++',
    NerdQX: 'NerdQX',
    'NerdQAxe+': 'NerdQAxe+',
    NerdAxe: 'NerdAxe',
    NerdAxeGamma: 'NerdAxe Gamma',
    'NerdOCTAXE+': 'NerdOCTAXE+',
    'NerdOCTAXE-Gamma': 'NerdOCTAXE Gamma',
    'NerdHaxe-Gamma': 'NerdHaxe Gamma',
    NerdEKO: 'NerdEKO',
    Q1370: 'Q1370',
    Q1373: 'Q1373',
  }
  return names[board] ?? board
}
