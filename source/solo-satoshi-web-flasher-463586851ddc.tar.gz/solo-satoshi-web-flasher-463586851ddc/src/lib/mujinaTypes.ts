/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 */

export type K230Mode = 'bootrom' | 'uboot'

export type KdImagePartition = {
  name: string
  offset: number
  size: number
  eraseSize: number
  maxSize: number
  contentOffset: number
  contentSize: number
  writeSize: number
  expectedSha256: string
}

export type KdImage = {
  file: File
  version: number
  imageInfo: string
  chipInfo: string
  boardInfo: string
  partitions: KdImagePartition[]
  totalWriteBytes: number
}

export type K230FlashStage = 'loading' | 'starting-loader' | 'waiting-loader' | 'probing' | 'flashing' | 'restarting'

export type K230FlashCallbacks = {
  onStage: (stage: K230FlashStage) => void
  onProgress: (progress: number) => void
  onLog: (line: string) => void
}
