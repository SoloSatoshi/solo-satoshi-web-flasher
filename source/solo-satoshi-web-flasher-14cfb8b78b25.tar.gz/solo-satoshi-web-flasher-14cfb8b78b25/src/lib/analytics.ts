/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 */

type MatomoCommand = [string, ...unknown[]]

declare global {
  interface Window {
    _paq?: MatomoCommand[]
  }
}

const productionHostname = 'flash.solosatoshi.com'
const trackerBaseUrl = 'https://solosatoshi.matomo.cloud/'
const trackerScriptUrl = 'https://cdn.matomo.cloud/solosatoshi.matomo.cloud/matomo.js'
const siteId = '5'

export type AnalyticsEvent =
  | { category: 'Navigation'; action: 'Shop hardware clicked'; name: 'desktop header' | 'mobile menu' }
  | { category: 'Compatibility'; action: 'Unsupported browser'; name: 'mobile' | 'desktop' }
  | { category: 'Firmware data'; action: 'Fallback used' | 'Load failed' }
  | { category: 'Flasher funnel'; action: 'Tool selected'; name: 'verified' | 'custom' | 'mujina' | 'seedsigner' }
  | { category: 'Flasher funnel'; action: 'Connection requested' | 'Connection completed' | 'Connection cancelled' | 'Connection failed' | 'Disconnected'; name: 'official' | 'custom' | 'mujina' }
  | { category: 'Flasher funnel'; action: 'Channel selected'; name: 'stable' | 'beta' }
  | { category: 'Flasher funnel'; action: 'Model selected' | 'Model auto-selected' | 'Board selected' | 'Firmware selected'; name: string }
  | { category: 'Flasher funnel'; action: 'Settings selected'; name: 'preserve' | 'reset' }
  | { category: 'Miner family'; action: 'Selected'; name: 'bitaxe' | 'bitforge' | 'nerdaxe' | 'nerdnos' }
  | { category: 'Flashing'; action: 'Started' | 'Completed' | 'Failed'; name: 'verified' | 'custom' }
  | { category: 'Flashing issue'; action: 'Download or verification failed' | 'Bootloader connection failed' | 'Installation failed' | 'Custom file rejected'; name: string }
  | { category: 'Support'; action: 'Issue report opened' | 'Issue report submitted' | 'Issue report failed' }
  | { category: 'Support'; action: 'Issue report abandoned'; name: 'idle' | 'error' }
  | { category: 'Help'; action: 'FAQ opened'; name: string }

export function initializeAnalytics() {
  if (window.location.hostname !== productionHostname || document.querySelector(`script[src="${trackerScriptUrl}"]`)) return

  const queue = window._paq = window._paq ?? []
  queue.push(['disableCookies'])
  queue.push(['setDoNotTrack', true])
  queue.push(['setTrackerUrl', `${trackerBaseUrl}matomo.php`])
  queue.push(['setSiteId', siteId])
  queue.push(['trackPageView'])

  const script = document.createElement('script')
  script.async = true
  script.src = trackerScriptUrl
  document.head.append(script)
}

export function trackAnalyticsEvent(event: AnalyticsEvent) {
  if (window.location.hostname !== productionHostname) return
  const command: MatomoCommand = ['trackEvent', event.category, event.action]
  if ('name' in event) command.push(event.name)
  window._paq?.push(command)
}
