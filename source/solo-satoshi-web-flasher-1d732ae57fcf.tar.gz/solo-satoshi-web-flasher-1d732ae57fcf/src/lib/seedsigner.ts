/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

export const SEEDSIGNER_REPOSITORY = 'SeedSigner/seedsigner'
export const SEEDSIGNER_RELEASES_URL = `https://github.com/${SEEDSIGNER_REPOSITORY}/releases`
export const SEEDSIGNER_LATEST_RELEASE_API = `https://api.github.com/repos/${SEEDSIGNER_REPOSITORY}/releases/latest`
export const SEEDSIGNER_PLUS_BOARD = 'pi02w' as const

const SHA256_PATTERN = /^[a-f0-9]{64}$/
const RELEASE_TAG_PATTERN = /^\d+\.\d+\.\d+$/
const MIN_IMAGE_SIZE = 16 * 1024 * 1024
const MAX_IMAGE_SIZE = 256 * 1024 * 1024

interface GitHubAsset {
  name: string
  size: number
  browser_download_url: string
}

interface GitHubRelease {
  tag_name: string
  html_url: string
  published_at: string
  draft: boolean
  prerelease: boolean
  assets: GitHubAsset[]
}

export interface SeedSignerPlusRelease {
  tag: string
  publishedAt: string
  releaseUrl: string
  image: GitHubAsset
  checksumManifest: GitHubAsset
  checksumSignature: GitHubAsset
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function parseAsset(value: unknown): GitHubAsset {
  if (!isRecord(value) || typeof value.name !== 'string' || typeof value.size !== 'number' ||
      typeof value.browser_download_url !== 'string') throw new Error('SeedSigner release contains an invalid asset.')
  return { name: value.name, size: value.size, browser_download_url: value.browser_download_url }
}

function parseGitHubRelease(value: unknown): GitHubRelease {
  if (!isRecord(value) || typeof value.tag_name !== 'string' || typeof value.html_url !== 'string' ||
      typeof value.published_at !== 'string' || typeof value.draft !== 'boolean' ||
      typeof value.prerelease !== 'boolean' || !Array.isArray(value.assets)) {
    throw new Error('SeedSigner release metadata is invalid.')
  }
  return {
    tag_name: value.tag_name,
    html_url: value.html_url,
    published_at: value.published_at,
    draft: value.draft,
    prerelease: value.prerelease,
    assets: value.assets.map(parseAsset),
  }
}

function requireOfficialAsset(release: GitHubRelease, name: string): GitHubAsset {
  const asset = release.assets.find((candidate) => candidate.name === name)
  const prefix = `https://github.com/${SEEDSIGNER_REPOSITORY}/releases/download/${release.tag_name}/`
  if (!asset || !asset.browser_download_url.startsWith(prefix)) throw new Error(`Official SeedSigner asset is missing: ${name}`)
  return asset
}

export function parseOfficialSeedSignerPlusRelease(value: unknown): SeedSignerPlusRelease {
  const release = parseGitHubRelease(value)
  if (release.draft || release.prerelease || !RELEASE_TAG_PATTERN.test(release.tag_name)) {
    throw new Error('SeedSigner release must be a stable semantic version.')
  }
  if (release.html_url !== `${SEEDSIGNER_RELEASES_URL}/tag/${release.tag_name}` || Number.isNaN(Date.parse(release.published_at))) {
    throw new Error('SeedSigner release provenance is invalid.')
  }

  const image = requireOfficialAsset(release, `seedsigner_os.${release.tag_name}.${SEEDSIGNER_PLUS_BOARD}.img`)
  if (!Number.isSafeInteger(image.size) || image.size < MIN_IMAGE_SIZE || image.size > MAX_IMAGE_SIZE) {
    throw new Error('SeedSigner+ image size is outside the allowed range.')
  }

  return {
    tag: release.tag_name,
    publishedAt: release.published_at,
    releaseUrl: release.html_url,
    image,
    checksumManifest: requireOfficialAsset(release, `seedsigner.${release.tag_name}.sha256.txt`),
    checksumSignature: requireOfficialAsset(release, `seedsigner.${release.tag_name}.sha256.txt.sig`),
  }
}

export function parseSeedSignerImageChecksum(manifest: string, imageName: string): string {
  for (const line of manifest.split(/\r?\n/)) {
    const match = line.trim().match(/^([a-fA-F0-9]{64})\s+\*?(.+)$/)
    if (match?.[2] === imageName) {
      const digest = match[1].toLowerCase()
      if (SHA256_PATTERN.test(digest)) return digest
    }
  }
  throw new Error(`The signed SeedSigner checksum manifest does not include ${imageName}.`)
}

export async function getOfficialSeedSignerPlusRelease(): Promise<SeedSignerPlusRelease> {
  const response = await fetch(SEEDSIGNER_LATEST_RELEASE_API, {
    headers: { Accept: 'application/vnd.github+json' },
  })
  if (!response.ok) throw new Error(`Official SeedSigner release request failed (${response.status}).`)
  return parseOfficialSeedSignerPlusRelease(await response.json())
}
