/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import './i18n/config'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
