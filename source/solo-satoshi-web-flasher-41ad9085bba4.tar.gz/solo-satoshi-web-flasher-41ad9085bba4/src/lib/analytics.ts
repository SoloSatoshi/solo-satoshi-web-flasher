/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Solo Satoshi LLC. See NOTICE.md for attribution.
 */

type MatomoCommand = [string, ...unknown[]]
declare global { interface Window { _paq?: MatomoCommand[] } }

const hostname = 'flash.solosatoshi.com'
const tracker = 'https://solosatoshi.matomo.cloud/'
const scriptUrl = 'https://cdn.matomo.cloud/solosatoshi.matomo.cloud/matomo.js'
const labelPattern = /^[a-zA-Z0-9 ._:+-]{1,100}$/
let initialized = false

function trackingAllowed() {
  return window.location.hostname === hostname
    && navigator.doNotTrack !== '1' && navigator.doNotTrack !== 'yes'
    && !(navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl
}

/** Only explicit labels/public selection tokens; never DOM text or form content. */
export function trackAnalyticsEvent(category: string, action: string, name: string) {
  try {
    if (!trackingAllowed() || !labelPattern.test(category) || !labelPattern.test(action) || !labelPattern.test(name)) return
    window._paq?.push(['trackEvent', category, action, name])
  } catch { /* Analytics must never interfere with USB or user actions. */ }
}

export function trackInteraction(event: Event) {
  try {
    if (!(event.target instanceof Element)) return
    if (event.type === 'click') {
      const element = event.target.closest('button[data-analytics], a[data-analytics], summary[data-analytics], input[type="file"][data-analytics]')
      if (!element || element.hasAttribute('disabled')) return
      const name = element.getAttribute('data-analytics') || ''
      const category = element.tagName === 'A' ? 'Link' : element.tagName === 'SUMMARY' ? 'Help' : 'Button'
      trackAnalyticsEvent(category, 'Clicked', name)
    } else if (event.type === 'change') {
      const element = event.target
      const name = element.getAttribute('data-analytics') || ''
      if (element instanceof HTMLSelectElement) {
        // Only selected public options are allowed, never a typed free-text value.
        const option = element.selectedOptions[0]
        if (option && option.value) trackAnalyticsEvent('Selection', 'Changed', `${name}:${option.value}`)
      } else if (element instanceof HTMLInputElement && element.type === 'checkbox') {
        trackAnalyticsEvent('Selection', 'Changed', `${name}:${element.checked ? 'on' : 'off'}`)
      }
    }
  } catch { /* Metrics are best-effort and cannot block application behavior. */ }
}

export function initializeAnalytics() {
  try {
    if (initialized || !trackingAllowed()) return
    const queue = window._paq = window._paq ?? []
    queue.push(['disableCookies'])
    queue.push(['HeatmapSessionRecording::disable'])
    queue.push(['HeatmapSessionRecording::disableCaptureKeystrokes'])
    queue.push(['setDoNotTrack', true])
    queue.push(['disableBrowserFeatureDetection'])
    queue.push(['disableCampaignParameters'])
    // Never forward query/hash parameters, arbitrary titles, or referrer paths.
    queue.push(['setCustomUrl', `https://${hostname}/`])
    queue.push(['setDocumentTitle', 'Solo Satoshi Web Flasher'])
    let referrer = ''
    try { if (document.referrer) referrer = new URL(document.referrer).origin } catch { /* Invalid referrer. */ }
    queue.push(['setReferrerUrl', referrer])
    queue.push(['setTrackerUrl', `${tracker}matomo.php`])
    queue.push(['setSiteId', '5'])
    queue.push(['trackPageView'])
    document.addEventListener('click', trackInteraction, true)
    document.addEventListener('change', trackInteraction, true)
    if (!document.querySelector(`script[src="${scriptUrl}"]`)) {
      const script = document.createElement('script')
      script.async = true
      script.src = scriptUrl
      document.head.append(script)
    }
    initialized = true
  } catch { /* A blocked tracker cannot break flashing or support. */ }
}
