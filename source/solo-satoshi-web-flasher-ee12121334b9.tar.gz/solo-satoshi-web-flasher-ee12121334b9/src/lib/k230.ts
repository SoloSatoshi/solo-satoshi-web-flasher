/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * K230 USB protocol and KDIMG format interoperability follows the public
 * specifications implemented by kendryte/k230_flash_py (MIT).
 */

import { sha256 as nobleSha256 } from '@noble/hashes/sha2.js'

export const K230_USB_VENDOR_ID = 0x29f1
export const K230_USB_PRODUCT_ID = 0x0230
export const K230_LOADER_ADDRESS = 0x80360000

const KDIMG_HEADER_MAGIC = 0x27cb8f93
const KDIMG_PART_MAGIC = 0x91df6da4
const KDIMG_HEADER_SIZE = 512
const KDIMG_PART_SIZE = 256
const MAX_PARTITIONS = 512
const MAX_KDIMG_SIZE = 512 * 1024 * 1024
const HASH_CHUNK_SIZE = 1024 * 1024
const PACKET_SIZE = 60
const HEADER_SIZE = 6
const MAX_COMMAND_DATA_SIZE = PACKET_SIZE - HEADER_SIZE
const COMMAND_FLAG_DEVICE_TO_HOST = 0x8000
const RESULT_OK = 1
const MEDIUM_SPI_NAND = 3
const COMMAND_NONE = 0
const COMMAND_REBOOT = 0x01
const COMMAND_DEVICE_PROBE = 0x10
const COMMAND_DEVICE_INFO = 0x11
const COMMAND_WRITE = 0x21
const REBOOT_MARK = 0x52626f74n

const LOADER_URL = 'https://raw.githubusercontent.com/kendryte/k230_flash_py/887c75fd6ab942f82b88260f24c8c2dc5228e646/src/k230_flash/loaders/loader_spi_nand.bin'
const LOADER_SHA256 = '685215d34c1567e39f919b8dfd462e276c167061293bbce74fcfd62d28bb9c1f'

export type K230Mode = 'bootrom' | 'uboot'

export type KdImagePartition = {
  name: string
  offset: number
  size: number
  eraseSize: number
  maxSize: number
  contentOffset: number
  contentSize: number
  writeSize: number
  expectedSha256: string
}

export type KdImage = {
  file: File
  version: number
  imageInfo: string
  chipInfo: string
  boardInfo: string
  partitions: KdImagePartition[]
  totalWriteBytes: number
}

export type K230FlashStage = 'loading' | 'starting-loader' | 'waiting-loader' | 'probing' | 'flashing' | 'restarting'

export type K230FlashCallbacks = {
  onStage: (stage: K230FlashStage) => void
  onProgress: (progress: number) => void
  onLog: (line: string) => void
}

type ClaimedDevice = {
  device: USBDevice
  interfaceNumber: number
  endpointIn: number
  endpointOut: number
}

export class K230ReconnectionError extends Error {
  constructor() {
    super('The K230 loader started, but the browser needs permission to reconnect to it.')
    this.name = 'K230ReconnectionError'
  }
}

function decodeString(bytes: Uint8Array) {
  const end = bytes.indexOf(0)
  return new TextDecoder().decode(end === -1 ? bytes : bytes.subarray(0, end)).trim()
}

function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')
}

const crcTable = Array.from({ length: 256 }, (_, value) => {
  let crc = value
  for (let bit = 0; bit < 8; bit += 1) crc = (crc & 1) !== 0 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1
  return crc >>> 0
})

export function crc32(bytes: Uint8Array) {
  let crc = 0xffffffff
  for (const byte of bytes) crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 0xff]
  return (crc ^ 0xffffffff) >>> 0
}

function readUint32(view: DataView, offset: number) {
  return view.getUint32(offset, true)
}

function safeNumber(value: bigint, label: string) {
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error(`${label} is too large for this browser.`)
  return Number(value)
}

export async function parseKdImage(file: File): Promise<KdImage> {
  if (!file.name.toLowerCase().endsWith('.kdimg')) throw new Error('Choose a .kdimg firmware image.')
  if (file.size < KDIMG_HEADER_SIZE) throw new Error('The KDIMG file is incomplete.')
  if (file.size > MAX_KDIMG_SIZE) throw new Error('The KDIMG file is larger than the supported Nano 3S image limit.')

  const header = new Uint8Array(await file.slice(0, KDIMG_HEADER_SIZE).arrayBuffer())
  const headerView = new DataView(header.buffer, header.byteOffset, header.byteLength)
  if (readUint32(headerView, 0) !== KDIMG_HEADER_MAGIC) throw new Error('The file is not a valid KDIMG image.')

  const expectedHeaderCrc = readUint32(headerView, 4)
  const crcHeader = header.slice()
  crcHeader.fill(0, 4, 8)
  if (crc32(crcHeader) !== expectedHeaderCrc) throw new Error('The KDIMG header checksum is invalid.')

  const version = readUint32(headerView, 12)
  if (version !== 1 && version !== 2) throw new Error(`KDIMG version ${version} is not supported.`)
  const partitionCount = readUint32(headerView, 16)
  const expectedTableCrc = readUint32(headerView, 20)
  if (partitionCount === 0 || partitionCount > MAX_PARTITIONS) throw new Error('The KDIMG partition count is invalid.')

  const tableSize = partitionCount * KDIMG_PART_SIZE
  if (KDIMG_HEADER_SIZE + tableSize > file.size) throw new Error('The KDIMG partition table is incomplete.')
  const table = new Uint8Array(await file.slice(KDIMG_HEADER_SIZE, KDIMG_HEADER_SIZE + tableSize).arrayBuffer())
  if (crc32(table) !== expectedTableCrc) throw new Error('The KDIMG partition-table checksum is invalid.')

  const partitions: KdImagePartition[] = []
  const names = new Set<string>()
  let totalWriteBytes = 0
  for (let index = 0; index < partitionCount; index += 1) {
    const base = index * KDIMG_PART_SIZE
    const view = new DataView(table.buffer, table.byteOffset + base, KDIMG_PART_SIZE)
    if (readUint32(view, 0) !== KDIMG_PART_MAGIC) throw new Error(`KDIMG partition ${index + 1} has an invalid header.`)

    const offset = readUint32(view, 4)
    const size = readUint32(view, 8)
    const eraseSize = readUint32(view, 12)
    const maxSize = readUint32(view, 16)
    const contentOffset = readUint32(view, version >= 2 ? 32 : 24)
    const contentSize = readUint32(view, version >= 2 ? 36 : 28)
    const hashOffset = version >= 2 ? 40 : 32
    const nameOffset = version >= 2 ? 72 : 64
    const expectedSha256 = bytesToHex(table.subarray(base + hashOffset, base + hashOffset + 32))
    const name = decodeString(table.subarray(base + nameOffset, base + nameOffset + 32))
    const writeSize = Math.max(contentSize, size)

    if (!name || names.has(name)) throw new Error(`KDIMG partition ${index + 1} has an invalid name.`)
    if (writeSize === 0 || maxSize === 0 || writeSize > maxSize) throw new Error(`KDIMG partition ${name} has an invalid declared size.`)
    if (contentOffset + contentSize > file.size) throw new Error(`KDIMG partition ${name} extends beyond the selected file.`)
    if (offset + writeSize > 0x1_0000_0000) throw new Error(`KDIMG partition ${name} has an invalid storage range.`)
    names.add(name)
    totalWriteBytes += writeSize
    partitions.push({ name, offset, size, eraseSize, maxSize, contentOffset, contentSize, writeSize, expectedSha256 })
  }

  const sortedPartitions = partitions.sort((a, b) => a.offset - b.offset)
  for (let index = 1; index < sortedPartitions.length; index += 1) {
    const previous = sortedPartitions[index - 1]
    const current = sortedPartitions[index]
    if (previous.offset + previous.maxSize > current.offset) throw new Error(`KDIMG partitions ${previous.name} and ${current.name} overlap.`)
  }

  return {
    file,
    version,
    imageInfo: decodeString(header.subarray(24, 56)),
    chipInfo: decodeString(header.subarray(56, 88)),
    boardInfo: decodeString(header.subarray(88, 152)),
    partitions: sortedPartitions,
    totalWriteBytes,
  }
}

export async function verifyKdImage(image: KdImage, onProgress: (progress: number) => void) {
  const total = image.partitions.reduce((sum, partition) => sum + partition.contentSize, 0)
  let verified = 0
  for (const partition of image.partitions) {
    const hash = nobleSha256.create()
    let read = 0
    while (read < partition.contentSize) {
      const length = Math.min(HASH_CHUNK_SIZE, partition.contentSize - read)
      const bytes = new Uint8Array(await image.file.slice(partition.contentOffset + read, partition.contentOffset + read + length).arrayBuffer())
      if (bytes.length !== length) throw new Error(`KDIMG partition ${partition.name} is incomplete.`)
      hash.update(bytes)
      read += bytes.length
      verified += bytes.length
      onProgress(total === 0 ? 100 : Math.round((verified / total) * 100))
    }
    const actual = bytesToHex(hash.digest())
    if (actual !== partition.expectedSha256) throw new Error(`KDIMG partition ${partition.name} failed SHA-256 verification.`)
  }
  onProgress(100)
}

export function supportsWebUsb() {
  return typeof navigator !== 'undefined' && 'usb' in navigator
}

export async function requestK230Device() {
  if (!supportsWebUsb()) throw new Error('WebUSB is not available in this browser.')
  return navigator.usb.requestDevice({ filters: [{ vendorId: K230_USB_VENDOR_ID, productId: K230_USB_PRODUCT_ID }] })
}

async function claimDevice(device: USBDevice): Promise<ClaimedDevice> {
  if (!device.opened) await device.open()
  if (!device.configuration) await device.selectConfiguration(device.configurations[0]?.configurationValue ?? 1)
  const interfaces = device.configuration?.interfaces ?? []
  for (const usbInterface of interfaces) {
    for (const alternate of usbInterface.alternates) {
      const endpointIn = alternate.endpoints.find((endpoint) => endpoint.type === 'bulk' && endpoint.direction === 'in')
      const endpointOut = alternate.endpoints.find((endpoint) => endpoint.type === 'bulk' && endpoint.direction === 'out')
      if (!endpointIn || !endpointOut) continue
      if (!usbInterface.claimed) await device.claimInterface(usbInterface.interfaceNumber)
      if (usbInterface.alternate.alternateSetting !== alternate.alternateSetting) {
        await device.selectAlternateInterface(usbInterface.interfaceNumber, alternate.alternateSetting)
      }
      return { device, interfaceNumber: usbInterface.interfaceNumber, endpointIn: endpointIn.endpointNumber, endpointOut: endpointOut.endpointNumber }
    }
  }
  throw new Error('The selected K230 device does not expose the required USB bulk endpoints.')
}

async function closeDevice(claimed: ClaimedDevice | null) {
  if (!claimed) return
  try {
    if (claimed.device.opened) await claimed.device.releaseInterface(claimed.interfaceNumber)
  } catch {
    // The device normally disappears while starting its loader or rebooting.
  }
  try {
    if (claimed.device.opened) await claimed.device.close()
  } catch {
    // The operating system may already have removed the old USB instance.
  }
}

async function controlIn(device: USBDevice, request: number, length: number) {
  const result = await device.controlTransferIn({ requestType: 'vendor', recipient: 'device', request, value: 0, index: 0 }, length)
  if (result.status !== 'ok' || !result.data) throw new Error(`K230 USB control request ${request} failed.`)
  return new Uint8Array(result.data.buffer, result.data.byteOffset, result.data.byteLength)
}

async function controlOut(device: USBDevice, request: number, value: number, index: number) {
  const result = await device.controlTransferOut({ requestType: 'vendor', recipient: 'device', request, value, index })
  if (result.status !== 'ok') throw new Error(`K230 USB control request ${request} failed.`)
}

async function detectMode(claimed: ClaimedDevice): Promise<K230Mode> {
  const info = decodeString(await controlIn(claimed.device, 0, 32))
  if (info.includes('Uboot Stage')) return 'uboot'
  if (info.includes('K230')) return 'bootrom'
  throw new Error(`The selected USB device did not identify as a flashable K230 (${info || 'no response'}).`)
}

export async function inspectK230Device(device: USBDevice) {
  const claimed = await claimDevice(device)
  try {
    return await detectMode(claimed)
  } finally {
    await closeDevice(claimed)
  }
}

async function loadSpiNandLoader() {
  const response = await fetch(LOADER_URL, { cache: 'force-cache' })
  if (!response.ok) throw new Error(`Unable to download the K230 SPI NAND loader (${response.status}).`)
  const bytes = new Uint8Array(await response.arrayBuffer())
  if (bytesToHex(nobleSha256(bytes)) !== LOADER_SHA256) throw new Error('The K230 SPI NAND loader failed SHA-256 verification.')
  return bytes
}

async function writeBulk(claimed: ClaimedDevice, bytes: Uint8Array) {
  const result = await claimed.device.transferOut(claimed.endpointOut, Uint8Array.from(bytes))
  if (result.status !== 'ok' || result.bytesWritten !== bytes.length) throw new Error('The K230 USB write did not complete.')
}

async function readBulk(claimed: ClaimedDevice, length: number) {
  const result = await claimed.device.transferIn(claimed.endpointIn, length)
  if (result.status !== 'ok' || !result.data) throw new Error('The K230 USB response was not received.')
  return new Uint8Array(result.data.buffer, result.data.byteOffset, result.data.byteLength)
}

async function startLoader(claimed: ClaimedDevice, loader: Uint8Array, onProgress: (progress: number) => void) {
  const high = (K230_LOADER_ADDRESS >>> 16) & 0xffff
  const low = K230_LOADER_ADDRESS & 0xffff
  await controlOut(claimed.device, 1, high, low)
  for (let offset = 0; offset < loader.length; offset += 1000) {
    await writeBulk(claimed, loader.subarray(offset, Math.min(offset + 1000, loader.length)))
    onProgress(Math.round((Math.min(offset + 1000, loader.length) / loader.length) * 100))
  }
  await controlOut(claimed.device, 4, high, low)
}

async function findReenumeratedDevice(serialNumber: string | null, timeoutMs = 15_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const devices = await navigator.usb.getDevices()
    const matches = devices.filter((device) => device.vendorId === K230_USB_VENDOR_ID && device.productId === K230_USB_PRODUCT_ID && (!serialNumber || device.serialNumber === serialNumber))
    for (const device of matches) {
      let claimed: ClaimedDevice | null = null
      try {
        claimed = await claimDevice(device)
        if (await detectMode(claimed) === 'uboot') return claimed
      } catch {
        // The device may still be disappearing from BootROM or enumerating.
      }
      await closeDevice(claimed)
    }
    await new Promise((resolve) => setTimeout(resolve, 150))
  }
  throw new K230ReconnectionError()
}

function createCommand(command: number, data: Uint8Array) {
  if (data.length > MAX_COMMAND_DATA_SIZE) throw new Error('K230 command data is too large.')
  const packet = new Uint8Array(PACKET_SIZE)
  const view = new DataView(packet.buffer)
  view.setUint16(0, command, true)
  view.setUint16(2, 0, true)
  view.setUint16(4, data.length, true)
  packet.set(data, HEADER_SIZE)
  return packet
}

async function sendCommand(claimed: ClaimedDevice, command: number, data: Uint8Array, expectedLength: number) {
  await writeBulk(claimed, createCommand(command, data))
  if (expectedLength === 0) return new Uint8Array()
  const response = await readBulk(claimed, PACKET_SIZE)
  if (response.length < HEADER_SIZE) throw new Error('The K230 returned an incomplete command response.')
  const view = new DataView(response.buffer, response.byteOffset, response.byteLength)
  const responseCommand = view.getUint16(0, true)
  const result = view.getUint16(2, true)
  const dataLength = view.getUint16(4, true)
  if (responseCommand !== (command | COMMAND_FLAG_DEVICE_TO_HOST)) throw new Error('The K230 returned a response for the wrong command.')
  if (result !== RESULT_OK && command !== COMMAND_NONE) {
    const detail = decodeString(response.subarray(HEADER_SIZE, HEADER_SIZE + dataLength))
    throw new Error(`The K230 rejected the command${detail ? `: ${detail}` : ''}.`)
  }
  if (dataLength !== expectedLength || HEADER_SIZE + dataLength > response.length) throw new Error('The K230 returned an unexpected response length.')
  return response.slice(HEADER_SIZE, HEADER_SIZE + dataLength)
}

async function probeSpiNand(claimed: ClaimedDevice) {
  await sendCommand(claimed, COMMAND_NONE, new Uint8Array(), 16)
  const chunks = await sendCommand(claimed, COMMAND_DEVICE_PROBE, Uint8Array.of(MEDIUM_SPI_NAND, 0xff), 16)
  const chunkView = new DataView(chunks.buffer, chunks.byteOffset, chunks.byteLength)
  const outputChunkSize = safeNumber(chunkView.getBigUint64(0, true), 'K230 transfer chunk size')
  if (outputChunkSize <= 0 || outputChunkSize > 16 * 1024 * 1024) throw new Error('The K230 returned an invalid transfer chunk size.')

  const information = await sendCommand(claimed, COMMAND_DEVICE_INFO, new Uint8Array(), 32)
  const infoView = new DataView(information.buffer, information.byteOffset, information.byteLength)
  const capacity = safeNumber(infoView.getBigUint64(0, true), 'SPI NAND capacity')
  const blockSize = safeNumber(infoView.getBigUint64(8, true), 'SPI NAND block size')
  if (capacity <= 0 || blockSize <= 0) throw new Error('The K230 returned invalid SPI NAND geometry.')
  return { outputChunkSize, capacity, blockSize }
}

function uint64Payload(values: bigint[]) {
  const bytes = new Uint8Array(values.length * 8)
  const view = new DataView(bytes.buffer)
  values.forEach((value, index) => view.setBigUint64(index * 8, value, true))
  return bytes
}

async function writePartition(claimed: ClaimedDevice, image: KdImage, partition: KdImagePartition, chunkSize: number, onChunk: (length: number) => void) {
  await sendCommand(claimed, COMMAND_NONE, new Uint8Array(), 16)
  const startResponse = await sendCommand(claimed, COMMAND_WRITE, uint64Payload([BigInt(partition.offset), BigInt(partition.writeSize), BigInt(partition.writeSize), 0n]), 8)
  if (startResponse.length !== 8) throw new Error(`The K230 did not initialize partition ${partition.name}.`)

  let written = 0
  while (written < partition.writeSize) {
    const length = Math.min(chunkSize, partition.writeSize - written)
    let chunk: Uint8Array
    if (written < partition.contentSize) {
      const contentLength = Math.min(length, partition.contentSize - written)
      const content = new Uint8Array(await image.file.slice(partition.contentOffset + written, partition.contentOffset + written + contentLength).arrayBuffer())
      if (content.length !== contentLength) throw new Error(`KDIMG partition ${partition.name} became unreadable.`)
      if (contentLength === length) chunk = content
      else {
        chunk = new Uint8Array(length).fill(0xff)
        chunk.set(content)
      }
    } else {
      chunk = new Uint8Array(length).fill(0xff)
    }
    await writeBulk(claimed, chunk)
    written += chunk.length
    onChunk(chunk.length)
  }
  if (partition.writeSize % chunkSize === 0) await writeBulk(claimed, new Uint8Array())

  const completion = await readBulk(claimed, PACKET_SIZE)
  if (completion.length < HEADER_SIZE) throw new Error(`The K230 did not confirm partition ${partition.name}.`)
  const view = new DataView(completion.buffer, completion.byteOffset, completion.byteLength)
  const command = view.getUint16(0, true)
  const result = view.getUint16(2, true)
  const messageLength = view.getUint16(4, true)
  if (HEADER_SIZE + messageLength > completion.length) throw new Error(`The K230 returned an incomplete write response for ${partition.name}.`)
  const message = decodeString(completion.subarray(HEADER_SIZE, HEADER_SIZE + messageLength))
  if (command !== (COMMAND_WRITE | COMMAND_FLAG_DEVICE_TO_HOST) || result !== RESULT_OK) {
    throw new Error(`The K230 reported a write failure for ${partition.name}${message ? `: ${message}` : ''}.`)
  }
}

export async function flashNano3s(initialDevice: USBDevice, image: KdImage, callbacks: K230FlashCallbacks) {
  let claimed: ClaimedDevice | null = null
  try {
    claimed = await claimDevice(initialDevice)
    let mode = await detectMode(claimed)
    callbacks.onLog(`Connected to K230 in ${mode === 'bootrom' ? 'BootROM' : 'loader'} mode.`)
    if (mode === 'bootrom') {
      callbacks.onStage('loading')
      const loader = await loadSpiNandLoader()
      callbacks.onLog(`Verified K230 SPI NAND loader (${LOADER_SHA256}).`)
      callbacks.onStage('starting-loader')
      await startLoader(claimed, loader, callbacks.onProgress)
      const serialNumber = claimed.device.serialNumber
      await closeDevice(claimed)
      claimed = null
      callbacks.onStage('waiting-loader')
      claimed = await findReenumeratedDevice(serialNumber)
      mode = 'uboot'
    }
    if (mode !== 'uboot') throw new Error('The K230 did not enter loader mode.')

    callbacks.onStage('probing')
    const { outputChunkSize, capacity, blockSize } = await probeSpiNand(claimed)
    callbacks.onLog(`SPI NAND: ${Math.round(capacity / 1024 / 1024)} MB; block size ${blockSize}; transfer chunk ${outputChunkSize}.`)
    for (const partition of image.partitions) {
      if (partition.offset % blockSize !== 0) throw new Error(`KDIMG partition ${partition.name} is not aligned to the device block size.`)
      if (partition.offset + partition.writeSize > capacity) throw new Error(`KDIMG partition ${partition.name} exceeds the Nano 3S SPI NAND capacity.`)
    }

    callbacks.onStage('flashing')
    let totalWritten = 0
    for (const partition of image.partitions) {
      callbacks.onLog(`Writing ${partition.name} at 0x${partition.offset.toString(16)} (${partition.writeSize} bytes).`)
      await writePartition(claimed, image, partition, outputChunkSize, (length) => {
        totalWritten += length
        callbacks.onProgress(Math.round((totalWritten / image.totalWriteBytes) * 100))
      })
    }

    callbacks.onStage('restarting')
    await sendCommand(claimed, COMMAND_NONE, new Uint8Array(), 16)
    try {
      await sendCommand(claimed, COMMAND_REBOOT, uint64Payload([REBOOT_MARK]), 0)
    } catch {
      // A successful reboot can remove the USB device before the transfer resolves.
    }
    callbacks.onProgress(100)
  } finally {
    await closeDevice(claimed)
  }
}
