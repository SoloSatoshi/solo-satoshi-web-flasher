/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import type { FirmwareImage, FirmwareManifest, FirmwareSource } from '../types'
import { TOUCH_BOARD, TOUCH_MODEL } from '../deviceCatalog'

const SHA256_PATTERN = /^[a-f0-9]{64}$/
const MIN_MINER_FACTORY_SIZE = 8 * 1024 * 1024
const MIN_TOUCH_FACTORY_SIZE = 1 * 1024 * 1024
const MAX_FACTORY_SIZE = 20 * 1024 * 1024
const APPROVED_REPOSITORIES = {
  bitaxe: ['bitaxeorg/ESP-Miner', 'bitaxeorg/BAP-GT-TOUCH'],
  nerdaxe: ['shufps/ESP-Miner-NerdQAxePlus'],
} as const
export const TOUCH_REPOSITORY = 'bitaxeorg/BAP-GT-TOUCH'
const FIRMWARE_ORIGIN = 'https://firmware.solosatoshi.com'
const MAX_MEMORY_CACHE_ENTRIES = 2
export const MAX_CUSTOM_FIRMWARE_SIZE = 32 * 1024 * 1024
const ESP_IMAGE_MAGIC = 0xe9
const ESP_PARTITION_TABLE_OFFSET = 0x8000
const ESP_PARTITION_ENTRY_MAGIC = [0xaa, 0x50] as const

interface FirmwareCacheEntry {
  progress: number
  listeners: Set<(progress: number) => void>
  promise: Promise<Uint8Array>
}

const firmwareCache = new Map<string, FirmwareCacheEntry>()

export const NVS_START = 0x9000
export const NVS_END = 0xf000

function isImage(value: unknown): value is FirmwareImage {
  if (!value || typeof value !== 'object') return false
  const image = value as Partial<FirmwareImage>
  const isTouchImage = image.sourceRepository === TOUCH_REPOSITORY
  const expectedTouchAsset = image.releaseTag === 'v1.0' ? 'esp-display.bin' : `esp-display-${image.releaseTag}.bin`
  return (
    (image.family === 'bitaxe' || image.family === 'nerdaxe') &&
    (image.channel === 'stable' || image.channel === 'beta') &&
    typeof image.id === 'string' && typeof image.model === 'string' &&
    typeof image.board === 'string' && typeof image.releaseTag === 'string' &&
    typeof image.assetName === 'string' && typeof image.size === 'number' &&
    image.size >= (image.sourceRepository === TOUCH_REPOSITORY ? MIN_TOUCH_FACTORY_SIZE : MIN_MINER_FACTORY_SIZE) && image.size <= MAX_FACTORY_SIZE &&
    typeof image.sha256 === 'string' && SHA256_PATTERN.test(image.sha256) &&
    typeof image.downloadUrl === 'string' && isApprovedFirmwareUrl(image.downloadUrl) &&
    typeof image.sourceRepository === 'string' && APPROVED_REPOSITORIES[image.family].some((repository) => repository === image.sourceRepository) &&
    (!isTouchImage || (image.family === 'bitaxe' && image.model === TOUCH_MODEL && image.board === TOUCH_BOARD && image.assetName === expectedTouchAsset)) &&
    typeof image.releaseUrl === 'string' && image.releaseUrl.startsWith(`https://github.com/${image.sourceRepository}/releases/`)
  )
}

function isApprovedFirmwareUrl(value: string): boolean {
  try {
    return new URL(value).origin === FIRMWARE_ORIGIN
  } catch {
    return false
  }
}

function isSource(value: unknown): value is FirmwareSource {
  if (!value || typeof value !== 'object') return false
  const source = value as Partial<FirmwareSource>
  return (
    (source.family === 'bitaxe' || source.family === 'nerdaxe') &&
    (source.channel === 'stable' || source.channel === 'beta') &&
    typeof source.repository === 'string' && APPROVED_REPOSITORIES[source.family].some((repository) => repository === source.repository) &&
    typeof source.releaseTag === 'string' && typeof source.publishedAt === 'string' &&
    typeof source.releaseUrl === 'string' && source.releaseUrl.startsWith(`https://github.com/${source.repository}/releases/`) &&
    typeof source.sourceArchiveUrl === 'string' && isApprovedFirmwareUrl(source.sourceArchiveUrl)
  )
}

export function parseManifest(value: unknown): FirmwareManifest {
  if (!value || typeof value !== 'object') throw new Error('Firmware manifest is invalid.')
  const input = value as Record<string, unknown>
  const normalized = input.schemaVersion === 1 ? {
    ...input,
    schemaVersion: 2,
    sources: Array.isArray(input.sources) ? input.sources.map((source) => ({ ...(source as object), channel: 'stable' })) : input.sources,
    firmware: Array.isArray(input.firmware) ? input.firmware.map((image) => ({ ...(image as object), channel: 'stable' })) : input.firmware,
  } : input
  const manifest = normalized as Partial<FirmwareManifest>
  if (manifest.schemaVersion !== 2 || typeof manifest.generatedAt !== 'string' ||
    !Array.isArray(manifest.sources) || !manifest.sources.every(isSource) || !Array.isArray(manifest.firmware) ||
    manifest.firmware.length === 0 || !manifest.firmware.every(isImage)) {
    throw new Error('Firmware manifest is invalid or empty.')
  }
  return manifest as FirmwareManifest
}

export async function loadManifest(): Promise<{ manifest: FirmwareManifest; fallback: boolean }> {
  const configuredUrl = import.meta.env.VITE_FIRMWARE_MANIFEST_URL as string | undefined
  const remoteUrl = configuredUrl || 'https://firmware.solosatoshi.com/firmware-index.json'
  try {
    // The R2 object has a five-minute max-age. Reuse that browser and edge
    // cache instead of creating a unique cache key for every page load.
    const response = await fetch(remoteUrl)
    if (!response.ok) throw new Error(`Firmware service returned ${response.status}.`)
    return { manifest: parseManifest(await response.json()), fallback: false }
  } catch (remoteError) {
    const response = await fetch(`${import.meta.env.BASE_URL}firmware-index.json`, { cache: 'no-store' })
    if (!response.ok) throw remoteError
    return { manifest: parseManifest(await response.json()), fallback: true }
  }
}

async function fetchAndVerify(image: FirmwareImage, onProgress: (progress: number) => void): Promise<Uint8Array> {
  // Firmware URLs contain the release and filename, and the release workflow
  // serves them as immutable. The SHA-256 check below still authenticates bytes
  // returned from either the network or the browser's HTTP cache.
  const response = await fetch(image.downloadUrl, { cache: 'force-cache' })
  if (!response.ok) throw new Error(`Firmware download failed (${response.status}).`)
  const contentLength = Number(response.headers.get('content-length'))
  let bytes: Uint8Array
  if (response.body && contentLength > 0) {
    const reader = response.body.getReader()
    const chunks: Uint8Array[] = []
    let received = 0
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      chunks.push(value)
      received += value.length
      onProgress(Math.min(100, Math.round((received / contentLength) * 100)))
    }
    bytes = new Uint8Array(received)
    let offset = 0
    for (const chunk of chunks) {
      bytes.set(chunk, offset)
      offset += chunk.length
    }
  } else {
    bytes = new Uint8Array(await response.arrayBuffer())
  }
  if (bytes.length !== image.size) throw new Error(`Firmware size check failed. Expected ${image.size} bytes, received ${bytes.length}.`)
  const digest = await sha256(bytes)
  if (digest !== image.sha256) throw new Error('Firmware security check failed. The downloaded file does not match GitHub.')
  onProgress(100)
  return bytes
}

function getFirmwareEntry(image: FirmwareImage): FirmwareCacheEntry {
  const cached = firmwareCache.get(image.sha256)
  if (cached) return cached

  while (firmwareCache.size >= MAX_MEMORY_CACHE_ENTRIES) {
    const oldestKey = firmwareCache.keys().next().value
    if (oldestKey === undefined) break
    firmwareCache.delete(oldestKey)
  }

  const entry: FirmwareCacheEntry = {
    progress: 0,
    listeners: new Set(),
    promise: Promise.resolve(new Uint8Array()),
  }
  entry.promise = fetchAndVerify(image, (progress) => {
    entry.progress = progress
    for (const listener of entry.listeners) listener(progress)
  }).catch((error) => {
    // A failed or interrupted response must never remain in the verified cache.
    firmwareCache.delete(image.sha256)
    throw error
  })
  firmwareCache.set(image.sha256, entry)
  return entry
}

export async function downloadAndVerify(image: FirmwareImage, onProgress: (progress: number) => void): Promise<Uint8Array> {
  const entry = getFirmwareEntry(image)
  entry.listeners.add(onProgress)
  onProgress(entry.progress)
  try {
    return await entry.promise
  } finally {
    entry.listeners.delete(onProgress)
  }
}

export async function prefetchFirmware(image: FirmwareImage): Promise<void> {
  await getFirmwareEntry(image).promise
}

export async function sha256(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(bytes).buffer)
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('')
}

export function createFlashSegments(firmware: Uint8Array, keepSettings: boolean) {
  if (!keepSettings) return [{ data: firmware, address: 0 }]
  if (firmware.length <= NVS_END) throw new Error('Firmware image is too small to preserve settings safely.')
  return [
    { data: firmware.slice(0, NVS_START), address: 0 },
    { data: firmware.slice(NVS_END), address: NVS_END },
  ]
}

export function validateCustomFirmware(firmware: Uint8Array) {
  if (firmware.length === 0) throw new Error('The selected firmware file is empty.')
  if (firmware.length > MAX_CUSTOM_FIRMWARE_SIZE) throw new Error('The selected firmware file is larger than 32 MB.')
  if (firmware[0] !== ESP_IMAGE_MAGIC) throw new Error('The selected file is not a bootable ESP binary image for address 0x0.')
  if (firmware.length <= ESP_PARTITION_TABLE_OFFSET + 1 || firmware[ESP_PARTITION_TABLE_OFFSET] !== ESP_PARTITION_ENTRY_MAGIC[0] || firmware[ESP_PARTITION_TABLE_OFFSET + 1] !== ESP_PARTITION_ENTRY_MAGIC[1]) {
    throw new Error('The selected file is not a merged ESP32-S3 factory image with a partition table at 0x8000.')
  }
}
