/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

interface BrowserEnvironment {
  userAgent: string
  isSecureContext: boolean
  hasWebSerial: boolean
  platform?: string
  maxTouchPoints?: number
}

export function isMobileFlashingDevice(userAgent: string, platform = '', maxTouchPoints = 0): boolean {
  return /Android|iPhone|iPad|iPod|Mobile/i.test(userAgent)
    || (/Mac/i.test(platform || userAgent) && maxTouchPoints > 1)
}

export function isCompatibleFlashingBrowser({ userAgent, isSecureContext, hasWebSerial, platform, maxTouchPoints }: BrowserEnvironment): boolean {
  const isFirefox = /Firefox\/|FxiOS\//i.test(userAgent)
  const isSafari = /Safari\//i.test(userAgent) && !/(Chrome|Chromium|CriOS|Edg|Brave)\//i.test(userAgent)
  const isMobile = isMobileFlashingDevice(userAgent, platform, maxTouchPoints)
  return isSecureContext && hasWebSerial && !isFirefox && !isSafari && !isMobile
}

export function supportsWebSerial(): boolean {
  return isCompatibleFlashingBrowser({
    userAgent: navigator.userAgent,
    isSecureContext: window.isSecureContext,
    hasWebSerial: 'serial' in navigator && typeof navigator.serial?.requestPort === 'function',
    platform: navigator.platform,
    maxTouchPoints: navigator.maxTouchPoints,
  })
}
