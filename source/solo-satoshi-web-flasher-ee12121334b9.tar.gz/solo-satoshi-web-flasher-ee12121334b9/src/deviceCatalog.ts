/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import type { FirmwareFamily } from './types'

export const familyLabels: Record<FirmwareFamily, string> = {
  bitaxe: 'Bitaxe',
  nerdaxe: 'NerdAxe',
}

export const TOUCH_BOARD = 'GT-TOUCH'
export const TOUCH_MODEL = 'Bitaxe Turbo Touch — Screen Only'

export const bitaxeBoardNames: Record<string, string> = {
  '102': 'Bitaxe Max',
  '201': 'Bitaxe Ultra',
  '202': 'Bitaxe Ultra',
  '203': 'Bitaxe Ultra',
  '204': 'Bitaxe Ultra',
  '205': 'Bitaxe Ultra',
  '207': 'Bitaxe Ultra',
  '302': 'Bitaxe Hex',
  '303': 'Bitaxe Hex',
  '400': 'Bitaxe Supra',
  '401': 'Bitaxe Supra',
  '402': 'Bitaxe Supra',
  '403': 'Bitaxe Supra',
  '600': 'Bitaxe Gamma',
  '601': 'Bitaxe Gamma',
  '602': 'Bitaxe Gamma',
  '603': 'Bitaxe Gamma',
  '650': 'Bitaxe Gamma Duo',
  '701': 'Bitaxe SupraHex',
  '702': 'Bitaxe SupraHex',
  '801': 'Bitaxe Gamma Turbo',
  '1201': 'Naja Duo',
  '1300': 'GammaHex',
}

export function friendlyModel(family: FirmwareFamily, board: string): string {
  if (family === 'bitaxe') return bitaxeBoardNames[board] ?? `Bitaxe board ${board}`

  const names: Record<string, string> = {
    'NerdQAxe++': 'NerdQAxe++',
    NerdQX: 'NerdQX',
    'NerdQAxe+': 'NerdQAxe+',
    NerdAxe: 'NerdAxe',
    NerdAxeGamma: 'NerdAxe Gamma',
    'NerdOCTAXE+': 'NerdOCTAXE+',
    'NerdOCTAXE-Gamma': 'NerdOCTAXE Gamma',
    'NerdHaxe-Gamma': 'NerdHaxe Gamma',
    NerdEKO: 'NerdEKO',
    Q1370: 'Q1370',
    Q1373: 'Q1373',
  }
  return names[board] ?? board
}
