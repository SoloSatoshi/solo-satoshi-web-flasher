/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { supportedLanguages } from '../i18n/config'

export default function LanguageSelector() {
  const { i18n, t } = useTranslation()
  const language = i18n.resolvedLanguage?.split('-')[0] ?? 'en'

  useEffect(() => {
    document.documentElement.lang = language
  }, [language])

  return (
    <label className="language-control">
      <span>{t('common.language')}:</span>
      <select className="language-select" value={language} onChange={(event) => void i18n.changeLanguage(event.target.value)} aria-label={t('common.language')}>
        {supportedLanguages.map((option) => <option value={option.value} key={option.value}>{option.label}</option>)}
      </select>
    </label>
  )
}
