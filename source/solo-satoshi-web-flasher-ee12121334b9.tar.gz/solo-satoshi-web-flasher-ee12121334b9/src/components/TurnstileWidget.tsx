import { useEffect, useRef } from 'react'

type TurnstileApi = {
  render: (container: HTMLElement, options: Record<string, unknown>) => string
  remove: (widgetId: string) => void
}

declare global {
  interface Window {
    turnstile?: TurnstileApi
  }
}

let turnstileLoader: Promise<TurnstileApi> | null = null

function loadTurnstile() {
  if (window.turnstile) return Promise.resolve(window.turnstile)
  if (turnstileLoader) return turnstileLoader

  turnstileLoader = new Promise<TurnstileApi>((resolve, reject) => {
    const script = document.createElement('script')
    script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'
    script.async = true
    script.defer = true
    script.onload = () => window.turnstile ? resolve(window.turnstile) : reject(new Error('Turnstile did not initialize.'))
    script.onerror = () => reject(new Error('Turnstile could not load.'))
    document.head.append(script)
  }).catch((error) => {
    turnstileLoader = null
    throw error
  })

  return turnstileLoader
}

type TurnstileWidgetProps = {
  siteKey: string
  language: string
  onToken: (token: string) => void
  onError: () => void
}

export default function TurnstileWidget({ siteKey, language, onToken, onError }: TurnstileWidgetProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let disposed = false
    let widgetId: string | undefined

    void loadTurnstile().then((turnstile) => {
      if (disposed || !containerRef.current) return
      widgetId = turnstile.render(containerRef.current, {
        sitekey: siteKey,
        action: 'issue-report',
        appearance: 'interaction-only',
        size: 'flexible',
        theme: 'light',
        language: language === 'tlh' ? 'en' : language,
        callback: onToken,
        'expired-callback': () => onToken(''),
        'timeout-callback': () => onToken(''),
        'error-callback': () => { onToken(''); onError() },
      })
    }).catch(onError)

    return () => {
      disposed = true
      if (widgetId && window.turnstile) window.turnstile.remove(widgetId)
    }
  }, [language, onError, onToken, siteKey])

  return <div className="turnstile-widget" ref={containerRef} />
}
