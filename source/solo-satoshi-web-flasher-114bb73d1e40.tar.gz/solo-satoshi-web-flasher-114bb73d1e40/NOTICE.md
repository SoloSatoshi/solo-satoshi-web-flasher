# Licensing and attribution

Copyright © 2026 Solo Satoshi.

This application is distributed under the GNU General Public License version
3 only. See `LICENSE` and `LICENSE-SCOPE.md`. No trademark license is granted;
see `TRADEMARKS.md`.

Portions of the flashing workflow, hardware-selection approach, and initial
language catalog were adapted from these GPL-3.0 projects:

- [bitaxeorg/bitaxe-web-flasher](https://github.com/bitaxeorg/bitaxe-web-flasher)
- [shufps/nerdqaxe-web-flasher](https://github.com/shufps/nerdqaxe-web-flasher)

Copyright in those upstream works remains with their respective authors and
contributors. Solo Satoshi's modifications are identified by this application's
distinct source distribution and release history. The complete GPL-covered
source for the deployed version is published with the application.

It discovers and mirrors unmodified GPL-3.0 firmware from:

- [bitaxeorg/ESP-Miner](https://github.com/bitaxeorg/ESP-Miner)
- [bitaxeorg/BAP-GT-TOUCH](https://github.com/bitaxeorg/BAP-GT-TOUCH)
- [shufps/ESP-Miner-NerdQAxePlus](https://github.com/shufps/ESP-Miner-NerdQAxePlus)

Each mirrored firmware release is published with the corresponding tagged
source archive. The application and release pages link to source code and
license information.

Runtime components retain their own licenses. Copies required for distribution
are included under `public/licenses/` and summarized on `public/licenses.html`.

The locally hosted Manrope and Newsreader typefaces are distributed under the
SIL Open Font License version 1.1. Their license notices are included under
`public/licenses/`.
