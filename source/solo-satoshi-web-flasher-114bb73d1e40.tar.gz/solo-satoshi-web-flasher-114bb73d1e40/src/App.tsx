/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { lazy, Suspense, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { useTranslation } from 'react-i18next'
import { CheckCircle2, ChevronRight, CircleAlert, Cpu, ExternalLink, FileUp, GitFork, Menu, RefreshCw, Send, ShieldCheck, Usb, X } from 'lucide-react'
import { siDiscord, siFacebook, siInstagram, siReddit, siTiktok, siX, siYoutube } from 'simple-icons'
import './App.css'
import LanguageSelector from './components/LanguageSelector'
import TurnstileWidget from './components/TurnstileWidget'
import { familyLabels, TOUCH_BOARD, TOUCH_MODEL } from './deviceCatalog'
import { getChannelSources, getCompatibleReleaseSources, getLatestModelImages } from './lib/compatibility'
import { isMobileFlashingDevice, supportsWebSerial } from './lib/browserCompatibility'
import { downloadAndVerify, loadManifest, MAX_CUSTOM_FIRMWARE_SIZE, prefetchFirmware, sha256, TOUCH_REPOSITORY, validateCustomFirmware } from './lib/firmware'
import { BootloaderConnectionError, flashFirmware, requestMinerPort } from './lib/flasher'
import type { FirmwareFamily, FirmwareImage, FirmwareManifest, FlashStatus, ReleaseChannel } from './types'

type FlasherTool = 'verified' | 'mujina' | 'custom'
type FlashSource = 'official' | 'custom'
type LocalFirmware = { name: string; bytes: Uint8Array; digest: string }
type PostFlashStage = 'written' | 'restarting' | 'disconnected' | 'complete'
type IssueReportStatus = 'idle' | 'sending' | 'sent' | 'error'
type PageViewState = { scrollY?: number; activeTool?: FlasherTool; openFaqs?: number[] }

const postFlashStages: PostFlashStage[] = ['written', 'restarting', 'disconnected', 'complete']
const issueReportEndpoint = import.meta.env.VITE_ISSUE_REPORT_URL as string | undefined
const turnstileSiteKey = import.meta.env.VITE_TURNSTILE_SITE_KEY as string | undefined
const mujinaEnabled = import.meta.env.VITE_ENABLE_MUJINA === 'true'
const MujinaTool = mujinaEnabled ? lazy(() => import('#mujina-ui')) : null
const pageViewStateKey = 'soloSatoshiFlasherView'

function readPageViewState(): PageViewState {
  const state = window.history.state as Record<string, unknown> | null
  const view = state?.[pageViewStateKey]
  return view && typeof view === 'object' ? view as PageViewState : {}
}

function savePageViewState(next: Partial<PageViewState>) {
  const state = window.history.state as Record<string, unknown> | null
  window.history.replaceState({
    ...(state ?? {}),
    [pageViewStateKey]: { ...readPageViewState(), ...next },
  }, '')
}

const socialLinks = [
  { label: 'YouTube', href: 'https://www.youtube.com/@solo.satoshi', icon: siYoutube },
  { label: 'X', href: 'https://twitter.com/SoloSatoshi', icon: siX },
  { label: 'TikTok', href: 'https://tiktok.com/@solo.satoshi', icon: siTiktok },
  { label: 'Facebook', href: 'https://www.facebook.com/people/Solo-Satoshi/61575323724787/', icon: siFacebook },
  { label: 'Instagram', href: 'https://www.instagram.com/solosatoshi_/', icon: siInstagram },
  { label: 'Reddit', href: 'https://www.reddit.com/r/SoloSatoshi/', icon: siReddit },
  { label: 'Discord', href: 'https://discord.gg/solosatoshi', icon: siDiscord },
]

function HeroBolt() {
  return (
    <div className="hero-bolt" aria-hidden="true">
      <div className="bolt-halo" />
      <svg className="bolt-orbits" viewBox="0 0 360 380" role="presentation">
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-one" cx="180" cy="190" rx="165" ry="120" />
          <circle className="orbit-ball" r="6">
            <animateMotion dur="2.4s" repeatCount="indefinite" path="M 345 190 A 165 120 0 1 1 15 190 A 165 120 0 1 1 345 190" />
          </circle>
        </g>
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-two" cx="180" cy="190" rx="130" ry="175" />
          <circle className="orbit-ball orbit-ball-secondary" r="5">
            <animateMotion begin="-1.2s" dur="2.4s" repeatCount="indefinite" path="M 310 190 A 130 175 0 1 1 50 190 A 130 175 0 1 1 310 190" />
          </circle>
        </g>
      </svg>
      <svg className="bolt-mark" viewBox="0 0 260 360" role="presentation">
        <defs>
          <linearGradient id="bolt-gradient" x1="35" y1="30" x2="230" y2="330" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#f7931a" />
            <stop offset="0.3" stopColor="#eb4b55" />
            <stop offset="0.62" stopColor="#c71e82" />
            <stop offset="1" stopColor="#54205a" />
          </linearGradient>
          <linearGradient id="bolt-highlight" x1="65" y1="40" x2="180" y2="300" gradientUnits="userSpaceOnUse">
            <stop stopColor="#ffe8f3" stopOpacity="0.9" />
            <stop offset="0.55" stopColor="#f8a8d3" stopOpacity="0.5" />
            <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="bolt-shadow" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-body" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-highlight" d="M151 16 72 181h62l-21 120 78-140h-72z" />
      </svg>
    </div>
  )
}

function App() {
  const { t, i18n } = useTranslation()
  const copy = (key: string) => t(`site.${key}`)
  const formatDate = (date: string) => new Intl.DateTimeFormat(i18n.resolvedLanguage, { dateStyle: 'medium' }).format(new Date(date))
  const initialStatus: FlashStatus = { stage: 'idle', message: copy('ready'), progress: 0 }
  const [manifest, setManifest] = useState<FirmwareManifest | null>(null)
  const [manifestError, setManifestError] = useState('')
  const [usingFallback, setUsingFallback] = useState(false)
  const [family, setFamily] = useState<FirmwareFamily>('bitaxe')
  const [familyConfirmed, setFamilyConfirmed] = useState(false)
  const [channel, setChannel] = useState<ReleaseChannel>('stable')
  const [channelConfirmed, setChannelConfirmed] = useState(false)
  const [minerPort, setMinerPort] = useState<SerialPort | null>(null)
  const [selectedModel, setSelectedModel] = useState('')
  const [selectedReleaseTag, setSelectedReleaseTag] = useState('')
  const [selectedBoard, setSelectedBoard] = useState('')
  const [keepSettings, setKeepSettings] = useState(false)
  const [settingsAdvanced, setSettingsAdvanced] = useState(false)
  const [status, setStatus] = useState<FlashStatus>(initialStatus)
  const [logs, setLogs] = useState<string[]>([])
  const [activeTool, setActiveTool] = useState<FlasherTool>(() => {
    const savedTool = readPageViewState().activeTool
    return savedTool === 'mujina' && !mujinaEnabled ? 'verified' : savedTool ?? 'verified'
  })
  const [activeFlashSource, setActiveFlashSource] = useState<FlashSource | null>(null)
  const [customFirmware, setCustomFirmware] = useState<LocalFirmware | null>(null)
  const [customFirmwareError, setCustomFirmwareError] = useState('')
  const [bootloaderRecovery, setBootloaderRecovery] = useState(false)
  const [postFlashStage, setPostFlashStage] = useState<PostFlashStage | null>(null)
  const [issueDescription, setIssueDescription] = useState('')
  const [issueReportStatus, setIssueReportStatus] = useState<IssueReportStatus>('idle')
  const [turnstileToken, setTurnstileToken] = useState('')
  const [turnstileError, setTurnstileError] = useState(false)
  const [turnstileSession, setTurnstileSession] = useState(0)
  const [issueDialogOpen, setIssueDialogOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [openFaqs, setOpenFaqs] = useState<number[]>(() => readPageViewState().openFaqs ?? [])
  const issueDialogRef = useRef<HTMLDialogElement>(null)
  const mobileNavRef = useRef<HTMLDivElement>(null)
  const handleTurnstileError = useCallback(() => setTurnstileError(true), [])

  useLayoutEffect(() => {
    const previousScrollRestoration = window.history.scrollRestoration
    const savedScrollY = readPageViewState().scrollY ?? 0
    let hashTarget: HTMLElement | null = null
    try {
      hashTarget = window.location.hash ? document.getElementById(decodeURIComponent(window.location.hash.slice(1))) : null
    } catch { /* Ignore malformed URL fragments and restore the saved position. */ }
    let saveFrame = 0

    window.history.scrollRestoration = 'manual'
    document.documentElement.classList.add('restoring-scroll')
    if (!hashTarget) window.scrollTo(0, savedScrollY)
    const restoreFrame = window.requestAnimationFrame(() => {
      if (hashTarget) hashTarget.scrollIntoView({ behavior: 'auto', block: 'start' })
      else window.scrollTo(0, savedScrollY)
      document.documentElement.classList.remove('restoring-scroll')
    })
    const saveScroll = () => {
      window.cancelAnimationFrame(saveFrame)
      saveFrame = window.requestAnimationFrame(() => savePageViewState({ scrollY: window.scrollY }))
    }
    const saveScrollNow = () => savePageViewState({ scrollY: window.scrollY })

    window.addEventListener('scroll', saveScroll, { passive: true })
    window.addEventListener('pagehide', saveScrollNow)
    return () => {
      window.cancelAnimationFrame(restoreFrame)
      window.cancelAnimationFrame(saveFrame)
      window.removeEventListener('scroll', saveScroll)
      window.removeEventListener('pagehide', saveScrollNow)
      document.documentElement.classList.remove('restoring-scroll')
      window.history.scrollRestoration = previousScrollRestoration
    }
  }, [])

  useEffect(() => savePageViewState({ activeTool }), [activeTool])
  useEffect(() => savePageViewState({ openFaqs }), [openFaqs])

  useEffect(() => {
    if (!mobileMenuOpen) return

    function closeOnEscape(event: KeyboardEvent) {
      if (event.key === 'Escape') setMobileMenuOpen(false)
    }

    function closeOutsideMenu(event: PointerEvent) {
      if (!mobileNavRef.current?.contains(event.target as Node)) setMobileMenuOpen(false)
    }

    document.addEventListener('keydown', closeOnEscape)
    document.addEventListener('pointerdown', closeOutsideMenu)
    return () => {
      document.removeEventListener('keydown', closeOnEscape)
      document.removeEventListener('pointerdown', closeOutsideMenu)
    }
  }, [mobileMenuOpen])

  useEffect(() => {
    loadManifest().then(({ manifest: value, fallback }) => {
      setManifest(value)
      setUsingFallback(fallback)
    }).catch((error: unknown) => setManifestError(error instanceof Error ? error.message : copy('manifestLoadFailed')))
  // The manifest is language-independent and should load only once.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    setStatus((current) => current.stage === 'idle' ? initialStatus : current)
  // Refresh idle copy when the visitor changes language.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.resolvedLanguage])

  const channelSources = useMemo(() => getChannelSources(manifest, family, channel), [channel, family, manifest])
  const modelImages = useMemo(() => getLatestModelImages(manifest, family, channel, channelSources), [channel, channelSources, family, manifest])
  const modelOptions = useMemo(() => modelImages.filter((image, index, images) => images.findIndex((candidate) => candidate.model === image.model) === index), [modelImages])
  const boardOptions = useMemo(() => modelImages.filter((image) => image.model === selectedModel), [modelImages, selectedModel])
  const activeBoard = modelImages.some((image) => image.board === selectedBoard) ? selectedBoard : undefined
  const releaseSources = useMemo(() => getCompatibleReleaseSources(manifest, family, channel, activeBoard, channelSources), [activeBoard, channel, channelSources, family, manifest])
  const selectedSource = channel === 'beta' ? releaseSources[0] : releaseSources.find((item) => item.releaseTag === selectedReleaseTag)
  const selected = manifest?.firmware.find((image) =>
    image.family === family && image.channel === channel && image.board === activeBoard &&
    image.sourceRepository === selectedSource?.repository && image.releaseTag === selectedSource?.releaseTag
  )
  const isTouchDisplay = selectedModel === TOUCH_MODEL || selected?.sourceRepository === TOUCH_REPOSITORY
  const betaAvailable = manifest?.sources.some((item) => item.family === family && item.channel === 'beta') ?? false
  const isBusy = ['downloading', 'connecting', 'flashing'].includes(status.stage)
  const serialAvailable = supportsWebSerial()
  const mobileDevice = isMobileFlashingDevice(navigator.userAgent, navigator.platform, navigator.maxTouchPoints)
  const supportedHardware = useMemo(() => {
    const stableImages = manifest?.firmware.filter((image) => image.channel === 'stable' && image.model !== TOUCH_MODEL) ?? []
    const summarize = (targetFamily: FirmwareFamily) => {
      const images = stableImages.filter((image) => image.family === targetFamily)
      return {
        boards: [...new Set(images.map((image) => image.board))],
      }
    }
    return { bitaxe: summarize('bitaxe'), nerdaxe: summarize('nerdaxe') }
  }, [manifest])
  const latestStableRelease = useCallback((repository: string) => manifest?.sources
    .filter((source) => source.channel === 'stable' && source.repository === repository)
    .sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt))[0], [manifest])

  useEffect(() => {
    if (!selected) return
    // Download and verify the exact selected image while the visitor reviews
    // the final settings. startFlash shares this in-flight or completed work.
    void prefetchFirmware(selected).catch(() => undefined)
  }, [selected])

  async function connectMiner(source: FlashSource) {
    if (!serialAvailable) return
    if (minerPort) {
      setMinerPort(null)
      setFamilyConfirmed(false)
      setChannelConfirmed(false)
      setSelectedModel('')
      setSelectedBoard('')
      setSelectedReleaseTag('')
      setKeepSettings(false)
      setSettingsAdvanced(false)
      setCustomFirmware(null)
      setCustomFirmwareError('')
      setBootloaderRecovery(false)
      setPostFlashStage(null)
      setActiveFlashSource(null)
      setStatus(initialStatus)
      return
    }
    try {
      setActiveFlashSource(source)
      setStatus({ stage: 'connecting', message: copy('chooseUsb'), progress: 0 })
      setMinerPort(await requestMinerPort())
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotFoundError') {
        setStatus(initialStatus)
        return
      }
      if (error instanceof Error) setLogs([error.message])
      setStatus({ stage: 'error', message: copy('usbFailed'), progress: 0 })
    }
  }

  function selectTool(tool: FlasherTool) {
    if (isBusy || (tool === 'mujina' && !mujinaEnabled)) return
    setActiveTool(tool)
    setActiveFlashSource(null)
    setLogs([])
    setBootloaderRecovery(false)
    setPostFlashStage(null)
    setStatus(initialStatus)
  }

  async function startFlash(image: FirmwareImage) {
    if (!serialAvailable || !minerPort) return
    setActiveFlashSource('official')
    setLogs([])
    setBootloaderRecovery(false)
    setPostFlashStage(null)
    try {
      setStatus({ stage: 'downloading', message: copy('downloading'), progress: 0 })
      const firmware = await downloadAndVerify(image, (progress) => setStatus({ stage: 'downloading', message: copy('downloading'), progress }))
      await flashFirmware(minerPort, firmware, keepSettings, {
        expectedChip: image.sourceRepository === TOUCH_REPOSITORY ? 'ESP32-S3' : undefined,
        onConnecting: () => setStatus({ stage: 'connecting', message: copy('connectingDevice'), progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: copy('installing'), progress }),
        onWrittenAndVerified: () => {
          setPostFlashStage('written')
          setStatus({ stage: 'flashing', message: copy('firmwareWrittenVerified'), progress: 100 })
        },
        onRestarting: () => {
          setPostFlashStage('restarting')
          setStatus({ stage: 'flashing', message: copy('restartingDevice'), progress: 100 })
        },
        onDisconnected: () => {
          setPostFlashStage('disconnected')
          setStatus({ stage: 'flashing', message: copy('usbDisconnectDetected'), progress: 100 })
        },
        onRestartComplete: () => setPostFlashStage('complete'),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: copy('flashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      const needsBootloader = error instanceof BootloaderConnectionError
      setBootloaderRecovery(needsBootloader)
      setStatus({ stage: 'error', message: copy(needsBootloader ? 'bootloaderFailed' : 'flashFailed'), progress: 0 })
    }
  }

  async function chooseCustomFirmware(file?: File) {
    setCustomFirmware(null)
    setCustomFirmwareError('')
    setActiveFlashSource(null)
    setBootloaderRecovery(false)
    setPostFlashStage(null)
    setStatus(initialStatus)
    if (!file) return
    try {
      if (!file.name.toLowerCase().endsWith('.bin')) throw new Error(copy('customFileTypeError'))
      const bytes = new Uint8Array(await file.arrayBuffer())
      if (bytes.length === 0) throw new Error(copy('customEmptyError'))
      if (bytes.length > MAX_CUSTOM_FIRMWARE_SIZE) throw new Error(copy('customTooLargeError'))
      try {
        validateCustomFirmware(bytes)
      } catch {
        throw new Error(copy('customHeaderError'))
      }
      setCustomFirmware({ name: file.name, bytes, digest: await sha256(bytes) })
    } catch (error) {
      setCustomFirmwareError(error instanceof Error ? error.message : copy('customInvalid'))
    }
  }

  async function startCustomFlash() {
    if (!serialAvailable || !minerPort || !customFirmware) return
    setActiveFlashSource('custom')
    setLogs([])
    setBootloaderRecovery(false)
    setPostFlashStage(null)
    try {
      await flashFirmware(minerPort, customFirmware.bytes, false, {
        expectedChip: 'ESP32-S3',
        onConnecting: () => setStatus({ stage: 'connecting', message: copy('connectingDevice'), progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: copy('installingCustom'), progress }),
        onWrittenAndVerified: () => {
          setPostFlashStage('written')
          setStatus({ stage: 'flashing', message: copy('firmwareWrittenVerified'), progress: 100 })
        },
        onRestarting: () => {
          setPostFlashStage('restarting')
          setStatus({ stage: 'flashing', message: copy('restartingDevice'), progress: 100 })
        },
        onDisconnected: () => {
          setPostFlashStage('disconnected')
          setStatus({ stage: 'flashing', message: copy('usbDisconnectDetected'), progress: 100 })
        },
        onRestartComplete: () => setPostFlashStage('complete'),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: copy('flashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      const needsBootloader = error instanceof BootloaderConnectionError
      setBootloaderRecovery(needsBootloader)
      setStatus({ stage: 'error', message: copy(needsBootloader ? 'bootloaderFailed' : 'flashFailed'), progress: 0 })
    }
  }

  function renderPostFlashVerification() {
    if (!postFlashStage) return null
    const completedSteps = postFlashStage === 'written' ? 1 : postFlashStage === 'restarting' ? 1 : postFlashStage === 'disconnected' ? 3 : 4
    return (
      <ol className="post-flash-verification" aria-label={copy('postFlashVerification')}>
        {postFlashStages.map((step, index) => {
          const complete = index < completedSteps
          const active = !complete && index === completedSteps
          return (
            <li className={complete ? 'complete' : active ? 'active' : ''} key={step}>
              <span aria-hidden="true">{complete ? <CheckCircle2 size={17} /> : active ? <RefreshCw className="spin" size={16} /> : index + 1}</span>
              <strong>{copy(`postFlash${step[0].toUpperCase()}${step.slice(1)}`)}</strong>
            </li>
          )
        })}
      </ol>
    )
  }

  function openIssueReport() {
    setIssueReportStatus('idle')
    setTurnstileToken('')
    setTurnstileError(false)
    setTurnstileSession((current) => current + 1)
    setIssueDialogOpen(true)
    issueDialogRef.current?.showModal()
  }

  function closeIssueReport() {
    if (issueReportStatus === 'sending') return
    issueDialogRef.current?.close()
  }

  async function submitIssueReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const description = issueDescription.trim()
    if (description.length < 10 || description.length > 4000 || !issueReportEndpoint || !turnstileToken) {
      setIssueReportStatus('error')
      return
    }
    setIssueReportStatus('sending')
    try {
      const response = await fetch(issueReportEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, website: form.get('website'), turnstileToken }),
      })
      if (!response.ok) throw new Error(`Issue report failed with status ${response.status}.`)
      setIssueDescription('')
      setIssueReportStatus('sent')
    } catch {
      setIssueReportStatus('error')
      setTurnstileToken('')
      setTurnstileSession((current) => current + 1)
    }
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}>
          <img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" />
          <span className="brand-name">SOLO SATOSHI</span>
        </a>
        <nav className="desktop-nav" aria-label={copy('pageNavigation')}>
          <a className="nav-secondary" href="https://www.solosatoshi.com/shop" target="_blank" rel="noopener noreferrer">{copy('navShop')}</a>
          <a href="#how-it-works">{copy('navGuide')}</a>
          <a className="nav-secondary" href="https://github.com/SoloSatoshi" target="_blank" rel="noopener noreferrer">{copy('navGithub')} <GitFork size={15} /></a>
          <button className="report-issue-link" type="button" onClick={openIssueReport}>{copy('reportIssue')}</button>
          <LanguageSelector />
        </nav>
        <div className="mobile-nav" ref={mobileNavRef}>
          <button
            className="mobile-menu-toggle"
            type="button"
            aria-label={copy('pageNavigation')}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-navigation"
            onClick={() => setMobileMenuOpen((open) => !open)}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          {mobileMenuOpen && <nav className="mobile-menu-panel" id="mobile-navigation" aria-label={copy('pageNavigation')}>
            <a href="https://www.solosatoshi.com/shop" target="_blank" rel="noopener noreferrer" onClick={() => setMobileMenuOpen(false)}>{copy('navShop')} <ExternalLink size={15} /></a>
            <a href="#how-it-works" onClick={() => setMobileMenuOpen(false)}>{copy('navGuide')}</a>
            <a href="https://github.com/SoloSatoshi" target="_blank" rel="noopener noreferrer" onClick={() => setMobileMenuOpen(false)}>{copy('navGithub')} <GitFork size={15} /></a>
            <button className="report-issue-link" type="button" onClick={() => {
              setMobileMenuOpen(false)
              openIssueReport()
            }}>{copy('reportIssue')}</button>
            <LanguageSelector onLanguageChange={() => setMobileMenuOpen(false)} />
          </nav>}
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <h1><span className="headline-line">{copy('heroLineOne')}</span>{' '}<span className="headline-line"><span>{copy('heroWith')} </span><br className="headline-browser-break" aria-hidden="true" /><span className="headline-accent">{copy('heroVerified')}</span></span></h1>
            <p className="hero-summary">{copy('heroSummary')}</p>
          </div>

          <HeroBolt />
        </section>

        <section className="installer" id="installer" aria-labelledby="installer-title">
          <div className="installer-heading">
            <div>
              <p className="section-label">{copy('installerLabel')}</p>
              <h2 id="installer-title">{copy('installerTitle')}</h2>
            </div>
            <div className="verified-mark">
              {activeTool === 'verified' ? <ShieldCheck size={17} /> : activeTool === 'mujina' ? <Cpu size={17} /> : <FileUp size={17} />}
              <span>{activeTool === 'verified' ? copy('verifiedFiles') : activeTool === 'mujina' ? copy('mujinaLocalBadge') : copy('customLocalBadge')}</span>
            </div>
          </div>

          {!serialAvailable ? (
            <section className="compatibility-panel" role="alert" aria-labelledby="compatibility-title">
              <div className="compatibility-icon"><CircleAlert size={22} /></div>
              <div className="compatibility-copy">
                <h3 id="compatibility-title">{t(`errors.${mobileDevice ? 'mobileCompatibility' : 'browserCompatibility'}.title`)}</h3>
                <p>{t(`errors.${mobileDevice ? 'mobileCompatibility' : 'browserCompatibility'}.description`)}</p>
                {!mobileDevice && <div className="browser-links" aria-label={t('errors.browserCompatibility.title')}>
                  <a href="https://www.google.com/chrome/" target="_blank" rel="noopener noreferrer">Google Chrome <ExternalLink size={14} /></a>
                  <a href="https://www.microsoft.com/edge/download" target="_blank" rel="noopener noreferrer">Microsoft Edge <ExternalLink size={14} /></a>
                  <a href="https://brave.com/download/" target="_blank" rel="noopener noreferrer">Brave <ExternalLink size={14} /></a>
                </div>}
              </div>
            </section>
          ) : (<>
          <div className="tool-tabs" role="tablist" aria-label={copy('toolNavigation')}>
            <button type="button" role="tab" aria-selected={activeTool === 'verified'} className={activeTool === 'verified' ? 'active' : ''} disabled={isBusy} onClick={() => selectTool('verified')}><ShieldCheck size={17} />{copy('verifiedTab')}</button>
            {mujinaEnabled && <button type="button" role="tab" aria-selected={activeTool === 'mujina'} className={activeTool === 'mujina' ? 'active mujina-tab' : 'mujina-tab'} disabled={isBusy} onClick={() => selectTool('mujina')}><Cpu size={17} />{copy('mujinaTab')}<small>{copy('beta')}</small></button>}
            <button type="button" role="tab" aria-selected={activeTool === 'custom'} className={activeTool === 'custom' ? 'active' : ''} disabled={isBusy} onClick={() => selectTool('custom')}><FileUp size={17} />{copy('advancedTab')}</button>
          </div>

          {activeTool === 'verified' && <div className="installer-layout" role="tabpanel">
            <aside className="process-rail" aria-label={copy('processLabel')}>
              <ol>
                <li className={minerPort ? 'complete' : 'active'} aria-current={!minerPort ? 'step' : undefined}><span>1</span><div><strong>{copy('stepsConnect')}</strong><small>{copy('stepsConnectNote')}</small></div></li>
                <li className={!minerPort ? 'locked' : familyConfirmed ? 'complete' : 'active'} aria-current={minerPort && !familyConfirmed ? 'step' : undefined}><span>2</span><div><strong>{copy('stepsFamily')}</strong><small>{copy('stepsFamilyNote')}</small></div></li>
                <li className={!familyConfirmed ? 'locked' : channelConfirmed ? 'complete' : 'active'} aria-current={familyConfirmed && !channelConfirmed ? 'step' : undefined}><span>3</span><div><strong>{copy('stepsChannel')}</strong><small>{copy('stepsChannelNote')}</small></div></li>
                <li className={!channelConfirmed ? 'locked' : selectedModel ? 'complete' : 'active'} aria-current={channelConfirmed && !selectedModel ? 'step' : undefined}><span>4</span><div><strong>{copy('stepsModel')}</strong><small>{copy('stepsModelNote')}</small></div></li>
                <li className={!selectedModel ? 'locked' : activeBoard ? 'complete' : 'active'} aria-current={selectedModel && !activeBoard ? 'step' : undefined}><span>5</span><div><strong>{copy('stepsBoard')}</strong><small>{copy('stepsBoardNote')}</small></div></li>
                <li className={!activeBoard ? 'locked' : selected ? 'complete' : 'active'} aria-current={activeBoard && !selected ? 'step' : undefined}><span>6</span><div><strong>{copy('stepsVersion')}</strong><small>{copy('stepsVersionNote')}</small></div></li>
                <li className={!selected ? 'locked' : settingsAdvanced || status.stage !== 'idle' ? 'complete' : 'active'} aria-current={selected && !settingsAdvanced && status.stage === 'idle' ? 'step' : undefined}><span>7</span><div><strong>{copy('stepsSettings')}</strong><small>{copy('stepsSettingsNote')}</small></div></li>
                <li className={!selected || (!settingsAdvanced && status.stage === 'idle') ? 'locked' : 'active'} aria-current={selected && (settingsAdvanced || status.stage !== 'idle') ? 'step' : undefined}><span>8</span><div><strong>{copy('stepsInstall')}</strong><small>{copy('stepsInstallNote')}</small></div></li>
              </ol>
            </aside>

            <div className="flasher-panel">
              <section className="flow-stage connect-stage" aria-label={copy('connectLabel')}>
                <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={() => void connectMiner('official')}>
                  {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                  {minerPort ? t('hero.disconnect') : t('hero.connect')}
                </button>
                <p className="stage-note">{copy('connectNote')}</p>
              </section>

              <section className={`flow-stage family-stage ${!minerPort ? 'locked' : ''}`} aria-label={copy('familyLabel')} aria-disabled={!minerPort}>
                {manifestError ? (
                  <div className="browser-warning"><CircleAlert size={20} /><div><strong>{copy('firmwareUnavailable')}</strong><span>{copy('manifestLoadFailed')}</span></div></div>
                ) : (
                  <fieldset className="field-group">
                    <legend>{copy('stepsFamily')}</legend>
                    <div className="family-tabs">
                      {(Object.keys(familyLabels) as FirmwareFamily[]).map((key) => (
                        <button type="button" className={`${familyConfirmed && family === key ? 'active' : ''} family-${key}`} aria-pressed={familyConfirmed && family === key} onClick={() => { const hasPrerelease = manifest?.sources.some((item) => item.family === key && item.channel === 'beta') ?? true; setFamily(key); setFamilyConfirmed(true); setChannel('stable'); setChannelConfirmed(!hasPrerelease); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!minerPort || isBusy} key={key}>
                          <img className="family-wordmark" src={`${import.meta.env.BASE_URL}device-logos/${key}-wordmark.webp`} alt={familyLabels[key]} width={key === 'bitaxe' ? 370 : 520} height={key === 'bitaxe' ? 150 : 112} decoding="async" />
                        </button>
                      ))}
                    </div>
                  </fieldset>
                )}
              </section>

              <section className={`flow-stage channel-stage ${!familyConfirmed ? 'locked' : ''}`} aria-label={copy('channelLabel')} aria-disabled={!familyConfirmed}>
                  <fieldset className="field-group">
                    <legend>{copy('stepsChannel')}</legend>
                    <div className="channel-tabs">
                      <button type="button" className={channelConfirmed && channel === 'stable' ? 'active' : ''} aria-pressed={channelConfirmed && channel === 'stable'} onClick={() => { setChannel('stable'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('latestReleases')} <small>{copy('recommended')}</small></button>
                      {betaAvailable ? <button type="button" className={channelConfirmed && channel === 'beta' ? 'active beta' : 'beta'} aria-pressed={channelConfirmed && channel === 'beta'} onClick={() => { setChannel('beta'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('prereleases')} <small>{copy('betaReleases')}</small></button> : <button type="button" className="unavailable" disabled>{copy('noPrereleases')}</button>}
                    </div>
                  </fieldset>
                  {channel === 'beta' && <div className="beta-warning"><CircleAlert size={20} /><div><strong>{copy('prereleaseTitle')}</strong><span>{copy('prereleaseWarning')}</span></div></div>}
              </section>

              <section className={`flow-stage model-stage ${!channelConfirmed ? 'locked' : ''}`} aria-label={copy('modelLabel')} aria-disabled={!channelConfirmed}>
                    <div className="field-group">
                      <label htmlFor="model">{copy('stepsModel')}</label>
                      <select id="model" value={selectedModel} onChange={(event) => {
                        const model = event.target.value
                        setSelectedModel(model)
                        setSelectedBoard(family === 'nerdaxe' ? modelImages.find((image) => image.model === model)?.board ?? '' : '')
                        setSelectedReleaseTag('')
                        setKeepSettings(false)
                        setSettingsAdvanced(false)
                        setStatus(initialStatus)
                      }} disabled={!manifest || !channelConfirmed || isBusy}>
                        <option value="" disabled>{t('hero.selectDevice')}</option>
                        {modelOptions.map((image) => <option value={image.model} key={image.model}>{image.model}</option>)}
                      </select>
                      {isTouchDisplay && <div className="screen-only-warning"><CircleAlert size={19} /><div><strong>{copy('touchScreenOnlyTitle')}</strong><span>{copy('touchScreenOnlyWarning')}</span></div></div>}
                    </div>
              </section>

              <section className={`flow-stage board-stage ${!selectedModel ? 'locked' : ''}`} aria-label={copy('boardLabel')} aria-disabled={!selectedModel}>
                    {family === 'bitaxe' ? (
                      <div className="field-group">
                        <label htmlFor="board">{copy('boardVersion')}</label>
                        <select id="board" value={selectedBoard} onChange={(event) => { setSelectedBoard(event.target.value); setSelectedReleaseTag(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!selectedModel || isBusy}>
                          <option value="" disabled>{t('hero.selectBoard')}</option>
                          {boardOptions.map((image) => <option value={image.board} key={image.board}>{image.board === TOUCH_BOARD ? copy('touchBoardVersion') : image.board}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!selectedModel ? 'disabled' : ''}`}><span>{copy('boardMatch')}</span><strong>{selectedBoard || copy('selectModelFirst')}</strong><small>{copy('boardAuto')}</small></div>
                    )}
              </section>

              <section className={`flow-stage version-stage ${!activeBoard ? 'locked' : ''}`} aria-label={copy('versionLabel')} aria-disabled={!activeBoard}>
                    {channel === 'stable' ? (
                      <div className="field-group">
                        <label htmlFor="version">{copy('stepsVersion')}</label>
                        <select id="version" value={selectedReleaseTag} onChange={(event) => { setSelectedReleaseTag(event.target.value); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!activeBoard || isBusy}>
                          <option value="" disabled>{t('hero.selectFirmware')}</option>
                          {releaseSources.map((item, index) => <option value={item.releaseTag} key={item.releaseTag}>{item.releaseTag}{index === 0 ? `  •  ${copy('latest')}` : ''}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!activeBoard ? 'disabled' : ''}`}><span>{copy('stepsVersion')}</span><strong>{selected?.releaseTag ?? copy('selectModel')}</strong>{selectedSource && <small>{formatDate(selectedSource.publishedAt)}</small>}</div>
                    )}
              </section>

              <section className={`flow-stage settings-stage ${!selected ? 'locked' : ''}`} aria-label={copy('settingsLabel')} aria-disabled={!selected}>
                  <label className={`settings-row ${!selected ? 'disabled' : ''}`}>
                    <span className="settings-copy"><strong>{isTouchDisplay ? copy('preserveTouchSettings') : t('hero.keepConfig')}</strong><small>{isTouchDisplay ? copy('preserveTouchSettingsNote') : copy('keepSettingsNote')}</small></span>
                    <span className="switch"><input type="checkbox" checked={keepSettings} onChange={(event) => { setKeepSettings(event.target.checked); if (event.target.checked) setSettingsAdvanced(true) }} disabled={!selected || isBusy} /><i /></span>
                  </label>
              </section>

              <section className={`flow-stage install-stage ${!selected ? 'locked' : ''}`} aria-label={copy('installLabel')} aria-disabled={!selected}>
                  {selected && <p className="firmware-preparation-note">{copy('firmwarePreparationNote')}</p>}
                  {activeFlashSource === 'official' && status.stage !== 'idle' && (
                    <div className={`status-panel ${status.stage}`} role="status">
                      <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{['downloading', 'flashing'].includes(status.stage) && <strong>{status.progress}%</strong>}</div>
                      {['downloading', 'flashing'].includes(status.stage) && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                      {renderPostFlashVerification()}
                      {status.stage === 'complete' && <p>{copy(isTouchDisplay ? 'disconnectTouchAfterRestart' : 'disconnectAfterRestart')}</p>}
                    </div>
                  )}

                  {selected && !isTouchDisplay && <div className="bootloader-hint"><CircleAlert size={18} /><span>{copy('bootloaderHint')}</span></div>}
                  <button className="flash-button" type="button" disabled={!minerPort || !selected || !serialAvailable || isBusy} onClick={() => selected && startFlash(selected)}><Usb size={19} /> {isBusy ? t('hero.flashing') : bootloaderRecovery && status.stage === 'error' ? copy('retryFlashing') : isTouchDisplay ? copy('flashTouchFirmware') : t('hero.startFlashing')} <ChevronRight size={18} /></button>
                  <p className="button-note">{!minerPort ? copy('connectToUnlock') : !selected ? copy('completeSelections') : copy(isTouchDisplay ? 'keepTouchConnected' : 'keepConnected')}</p>
                  {usingFallback && <p className="fallback-note">{copy('fallbackManifest')}</p>}
                  {activeFlashSource === 'official' && logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
              </section>
            </div>
          </div>}

          {MujinaTool && activeTool === 'mujina' && <Suspense fallback={<div className="custom-firmware"><p>Loading private staging tool…</p></div>}><MujinaTool onOpenAdvanced={() => selectTool('custom')} /></Suspense>}
          {activeTool === 'custom' && <section className="custom-firmware" role="tabpanel" aria-labelledby="custom-firmware-title">
            <div className="custom-firmware-copy">
              <p className="section-label">{copy('customLabel')}</p>
              <h3 id="custom-firmware-title">{copy('customTitle')}</h3>
              <p>{copy('customDescription')}</p>
              <div className="custom-warning"><CircleAlert size={19} /><span>{copy('customWarning')}</span></div>
            </div>
            <div className="custom-firmware-controls">
              <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={() => void connectMiner('custom')}>
                {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                {minerPort ? t('hero.disconnect') : t('hero.connect')}
              </button>
              <p className="stage-note">{copy('connectNote')}</p>
              <label className={`custom-file-button ${!minerPort || isBusy ? 'disabled' : ''}`}>
                <FileUp size={18} />
                <span>{customFirmware ? copy('customReplace') : copy('customChoose')}</span>
                <input type="file" accept=".bin,application/octet-stream" disabled={!minerPort || isBusy} onChange={(event) => void chooseCustomFirmware(event.target.files?.[0])} />
              </label>
              {customFirmware && (
                <div className="custom-file-details">
                  <strong>{customFirmware.name}</strong>
                  <span>{(customFirmware.bytes.length / 1024 / 1024).toFixed(2)} MB</span>
                  <code>SHA-256 {customFirmware.digest}</code>
                </div>
              )}
              {customFirmwareError && <p className="custom-file-error" role="alert">{customFirmwareError}</p>}
              {activeFlashSource === 'custom' && status.stage !== 'idle' && (
                <div className={`status-panel ${status.stage}`} role="status">
                  <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{status.stage === 'flashing' && <strong>{status.progress}%</strong>}</div>
                  {status.stage === 'flashing' && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                  {renderPostFlashVerification()}
                  {status.stage === 'complete' && <p>{copy('disconnectAfterRestart')}</p>}
                </div>
              )}
              {customFirmware && <div className="bootloader-hint"><CircleAlert size={18} /><span>{copy('bootloaderHint')}</span></div>}
              <button className="flash-button custom-flash-button" type="button" disabled={!minerPort || !customFirmware || !serialAvailable || isBusy} onClick={() => void startCustomFlash()}><Usb size={19} /> {isBusy ? t('hero.flashing') : bootloaderRecovery && status.stage === 'error' ? copy('retryFlashing') : t('hero.startFlashing')} <ChevronRight size={18} /></button>
              <p className="button-note">{!minerPort ? copy('customConnectFirst') : copy('customLocalOnly')}</p>
              {activeFlashSource === 'custom' && logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
            </div>
          </section>}
          </>)}
        </section>

        <section className="preflight" id="how-it-works">
          <div className="preflight-intro">
            <p className="section-label">{copy('beforeConnecting')}</p>
            <h2>{copy('threeChecks')}</h2>
            <p>{copy('checksIntro')}</p>
          </div>
          <ol className="preflight-list">
            <li><span>1</span><div><strong>{copy('dataCable')}</strong><p>{copy('dataCableNote')}</p></div></li>
            <li><span>2</span><div><strong>{copy('matchBoard')}</strong><p>{copy('matchBoardNote')}</p></div></li>
            <li><span>3</span><div><strong>{copy('stablePower')}</strong><p>{copy('stablePowerNote')}</p></div></li>
          </ol>
        </section>

        <section className="provenance">
          <div className="provenance-icon"><ShieldCheck size={23} /></div>
          <div><p className="section-label">{copy('verifiable')}</p><h2>{copy('provenanceTitle')}</h2><p>{copy('provenanceText')}</p></div>
          <div className="source-links">{selected && <a href={selected.releaseUrl} target="_blank" rel="noopener noreferrer">{copy('viewRelease')}<ExternalLink size={14} /></a>}{selectedSource && <a href={selectedSource.sourceArchiveUrl} target="_blank" rel="noopener noreferrer">{copy('downloadSource')}<ExternalLink size={14} /></a>}</div>
        </section>

        <section className="device-support" id="supported-devices" aria-labelledby="support-title">
          <div className="support-heading"><p className="section-label">{copy('deviceSupport')}</p><h2 id="support-title">{copy('supportTitle')}</h2><p>{copy('supportText')}</p></div>
          <div className="support-list">
            <article><h3>Bitaxe</h3><div className="support-copy"><p>{copy('bitaxeModels')}</p>{supportedHardware.bitaxe.boards.length > 0 && <p className="support-board-list"><strong>{copy('boardVersion')}:</strong> {supportedHardware.bitaxe.boards.join(', ')}</p>}{latestStableRelease('bitaxeorg/ESP-Miner') && <a className="support-release" href={latestStableRelease('bitaxeorg/ESP-Miner')!.releaseUrl} target="_blank" rel="noopener noreferrer"><span>{copy('latest')}: {latestStableRelease('bitaxeorg/ESP-Miner')!.releaseTag}</span><time dateTime={latestStableRelease('bitaxeorg/ESP-Miner')!.publishedAt}>{formatDate(latestStableRelease('bitaxeorg/ESP-Miner')!.publishedAt)}</time><ExternalLink size={13} /></a>}</div></article>
            <article><h3>NerdAxe</h3><div className="support-copy"><p>{copy('nerdaxeModels')}</p>{supportedHardware.nerdaxe.boards.length > 0 && <p className="support-board-list"><strong>{copy('boardVersion')}:</strong> {supportedHardware.nerdaxe.boards.join(', ')}</p>}{latestStableRelease('shufps/ESP-Miner-NerdQAxePlus') && <a className="support-release" href={latestStableRelease('shufps/ESP-Miner-NerdQAxePlus')!.releaseUrl} target="_blank" rel="noopener noreferrer"><span>{copy('latest')}: {latestStableRelease('shufps/ESP-Miner-NerdQAxePlus')!.releaseTag}</span><time dateTime={latestStableRelease('shufps/ESP-Miner-NerdQAxePlus')!.publishedAt}>{formatDate(latestStableRelease('shufps/ESP-Miner-NerdQAxePlus')!.publishedAt)}</time><ExternalLink size={13} /></a>}</div></article>
            <article><h3>{copy('touchSupportTitle')}</h3><div className="support-copy"><p>{copy('touchSupportText')}</p>{latestStableRelease('bitaxeorg/BAP-GT-TOUCH') && <a className="support-release" href={latestStableRelease('bitaxeorg/BAP-GT-TOUCH')!.releaseUrl} target="_blank" rel="noopener noreferrer"><span>{copy('latest')}: {latestStableRelease('bitaxeorg/BAP-GT-TOUCH')!.releaseTag}</span><time dateTime={latestStableRelease('bitaxeorg/BAP-GT-TOUCH')!.publishedAt}>{formatDate(latestStableRelease('bitaxeorg/BAP-GT-TOUCH')!.publishedAt)}</time><ExternalLink size={13} /></a>}</div></article>
            {mujinaEnabled && <article><h3>{copy('nanoSupportTitle')}</h3><p>{copy('nanoSupportText')}</p></article>}
          </div>
        </section>

        <section className="faq" id="faq" aria-labelledby="faq-title">
          <div><p className="section-label">{copy('questions')}</p><h2 id="faq-title">{copy('faqTitle')}</h2></div>
          <div className="faq-list">
            {Array.from({ length: 14 }, (_, index) => index + 1).filter((faqNumber) => mujinaEnabled || ![1, 2, 3, 5, 6, 11].includes(faqNumber)).map((faqNumber) => (
              <details
                id={`faq-${faqNumber}`}
                open={openFaqs.includes(faqNumber)}
                onToggle={(event) => {
                  const isOpen = event.currentTarget.open
                  setOpenFaqs((current) => isOpen
                    ? current.includes(faqNumber) ? current : [...current, faqNumber]
                    : current.filter((number) => number !== faqNumber))
                }}
                key={faqNumber}
              >
                <summary>{copy(`faq${faqNumber}q`)}</summary>
                <p>{copy(`faq${faqNumber}a`)}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="legal-notice" aria-labelledby="legal-title">
          <div>
            <p className="section-label">{copy('policies')}</p>
            <h2 id="legal-title">{copy('legalTitle')}</h2>
          </div>
          <div className="legal-copy">
            <p>{copy('legalText')}</p>
            <nav aria-label={copy('policies')}>
              <a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacyPolicy')}</a>
              <a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('termsService')}</a>
              <a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licensesSource')}</a>
            </nav>
          </div>
        </section>

      </main>

      <footer className="site-footer">
        <div className="footer-row">
          <a className="brand footer-brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}><img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" /><span className="brand-name">SOLO SATOSHI</span></a>
          <span className="footer-copyright">{copy('rights')}</span>
          <nav className="social-links" aria-label={copy('socialLabel')}>
            {socialLinks.map(({ label, href, icon }) => (
              <a href={href} target="_blank" rel="me noopener noreferrer" aria-label={`${label} (${copy('opensNewTab')})`} title={label} key={label}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d={icon.path} /></svg>
              </a>
            ))}
          </nav>
          <nav className="footer-policies" aria-label={copy('footerPolicies')}><button type="button" onClick={openIssueReport}>{copy('reportIssue')}</button><a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacy')}</a><a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('terms')}</a><a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licenses')}</a></nav>
        </div>
      </footer>
      <dialog className="issue-dialog" ref={issueDialogRef} onCancel={(event) => { if (issueReportStatus === 'sending') event.preventDefault() }} onClose={() => { setIssueDialogOpen(false); setTurnstileToken(''); setTurnstileError(false); if (issueReportStatus !== 'sent') setIssueReportStatus('idle') }}>
        <div className="issue-dialog-heading">
          <div><p className="section-label">{copy('reportLabel')}</p><h2>{copy('reportTitle')}</h2></div>
          <button className="issue-dialog-close" type="button" onClick={closeIssueReport} disabled={issueReportStatus === 'sending'} aria-label={copy('closeReport')}><X size={20} /></button>
        </div>
        {issueReportStatus === 'sent' ? (
          <div className="issue-report-success" role="status"><CheckCircle2 size={28} /><h3>{copy('reportSuccessTitle')}</h3><p>{copy('reportSuccessText')}</p><button type="button" onClick={closeIssueReport}>{copy('closeReport')}</button></div>
        ) : (
          <form className="issue-report-form" onSubmit={(event) => void submitIssueReport(event)}>
            <p>{copy('reportDescription')}</p>
            <label htmlFor="issue-description">{copy('issueDescriptionLabel')}</label>
            <textarea id="issue-description" value={issueDescription} onChange={(event) => { setIssueDescription(event.target.value); if (issueReportStatus === 'error') setIssueReportStatus('idle') }} minLength={10} maxLength={4000} placeholder={copy('issueDescriptionPlaceholder')} required autoFocus />
            <label className="bot-trap" aria-hidden="true">Website<input name="website" type="text" tabIndex={-1} autoComplete="off" /></label>
            <small>{copy('issuePrivacyNote')}</small>
            {issueDialogOpen && turnstileSiteKey ? <TurnstileWidget key={turnstileSession} siteKey={turnstileSiteKey} language={i18n.resolvedLanguage || 'en'} onToken={setTurnstileToken} onError={handleTurnstileError} /> : null}
            {(turnstileError || !turnstileSiteKey) && <p className="issue-report-error" role="alert">{copy('reportVerificationError')}</p>}
            {issueReportStatus === 'error' && <p className="issue-report-error" role="alert">{copy('reportError')}</p>}
            <div className="issue-dialog-actions"><button type="button" onClick={closeIssueReport} disabled={issueReportStatus === 'sending'}>{copy('cancel')}</button><button type="submit" disabled={issueReportStatus === 'sending' || issueDescription.trim().length < 10 || !turnstileToken}><Send size={17} />{copy(issueReportStatus === 'sending' ? 'sendingReport' : 'sendReport')}</button></div>
          </form>
        )}
      </dialog>
    </div>
  )
}

export default App
