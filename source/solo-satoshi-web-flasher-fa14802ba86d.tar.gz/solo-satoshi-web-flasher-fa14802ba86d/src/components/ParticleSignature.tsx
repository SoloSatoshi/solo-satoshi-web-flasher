import { useEffect, useRef } from 'react'

interface Particle {
  x: number
  y: number
  targetX: number
  targetY: number
  velocityX: number
  velocityY: number
  radius: number
  depth: number
  phase: number
}

export default function ParticleSignature({ compact = false }: { compact?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const context = canvas.getContext('2d', { alpha: true })
    if (!context) return
    const surface: HTMLCanvasElement = canvas
    const drawingContext: CanvasRenderingContext2D = context

    const particles: Particle[] = []
    const pointer = { x: -10_000, y: -10_000, active: false }
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let width = 0
    let height = 0
    let frame = 0
    let visible = true
    let resizeTimer = 0
    let particleGradient: string | CanvasGradient = '#d51b8b'
    let haloGradient: string | CanvasGradient = 'rgba(213, 27, 139, .12)'

    function buildParticles() {
      const bounds = surface.getBoundingClientRect()
      width = Math.max(1, Math.round(bounds.width))
      height = Math.max(1, Math.round(bounds.height))
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 2)
      surface.width = Math.round(width * pixelRatio)
      surface.height = Math.round(height * pixelRatio)
      drawingContext.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0)
      particleGradient = drawingContext.createLinearGradient(width * .06, height * .82, width * .94, height * .16)
      particleGradient.addColorStop(0, '#35163f')
      particleGradient.addColorStop(.28, '#74285f')
      particleGradient.addColorStop(.5, '#d51b8b')
      particleGradient.addColorStop(.7, '#eb4b55')
      particleGradient.addColorStop(.86, '#ff5b72')
      particleGradient.addColorStop(1, '#f26a21')
      haloGradient = drawingContext.createLinearGradient(width * .06, height * .82, width * .94, height * .16)
      haloGradient.addColorStop(0, 'rgba(53, 22, 63, .12)')
      haloGradient.addColorStop(.5, 'rgba(213, 27, 139, .12)')
      haloGradient.addColorStop(1, 'rgba(242, 106, 33, .14)')

      const mask = document.createElement('canvas')
      mask.width = width
      mask.height = height
      const maskContext = mask.getContext('2d', { willReadFrequently: true })
      if (!maskContext) return
      const fontSize = compact ? Math.min(105, width / 6.75) : Math.min(172, width / 6.75)
      maskContext.fillStyle = '#fff'
      maskContext.font = `800 ${fontSize}px "Manrope Variable", sans-serif`
      const measuredWidth = maskContext.measureText('SOLO SATOSHI').width
      const horizontalScale = Math.min(1, (width * .97) / measuredWidth)
      maskContext.textAlign = 'center'
      maskContext.textBaseline = 'middle'
      maskContext.save()
      maskContext.translate(width / 2, height / 2 + fontSize * .075)
      maskContext.scale(horizontalScale, 1)
      maskContext.fillText('SOLO SATOSHI', 0, 0)
      maskContext.restore()
      const pixels = maskContext.getImageData(0, 0, width, height).data
      const sampleGap = compact ? 2 : width >= 900 ? 2 : width >= 620 ? 3 : 4
      const next: Particle[] = []

      for (let y = 0; y < height; y += sampleGap) {
        for (let x = 0; x < width; x += sampleGap) {
          if (pixels[(y * width + x) * 4 + 3] < 100) continue
          const depth = Math.random()
          next.push({
            x,
            y,
            targetX: x,
            targetY: y,
            velocityX: 0,
            velocityY: 0,
            radius: (compact && width < 620 ? .48 : .38) + depth * .82,
            depth,
            phase: Math.random() * Math.PI * 2,
          })
        }
      }
      particles.splice(0, particles.length, ...next)
      draw(0)
    }

    function draw(time: number) {
      drawingContext.clearRect(0, 0, width, height)
      drawingContext.globalCompositeOperation = 'source-over'

      if (!reduceMotion) {
        const repulsionSpread = Math.min(112, width * .13)
        const repulsionReach = repulsionSpread * 3.25
        for (const particle of particles) {
          const spring = .021 + particle.depth * .014
          const floatScale = 1.5 + particle.depth * 2.8
          const floatingX = (
            Math.sin(time * .0022 + particle.phase) +
            Math.cos(time * .0013 + particle.phase * 1.73) * .46
          ) * floatScale
          const floatingY = (
            Math.cos(time * .00255 + particle.phase * 1.31) +
            Math.sin(time * .00145 + particle.phase * .77) * .42
          ) * floatScale
          particle.velocityX += (particle.targetX + floatingX - particle.x) * spring
          particle.velocityY += (particle.targetY + floatingY - particle.y) * spring

          if (pointer.active) {
            const deltaX = particle.x - pointer.x
            const deltaY = particle.y - pointer.y
            const distanceSquared = deltaX * deltaX + deltaY * deltaY
            if (distanceSquared < repulsionReach * repulsionReach) {
              const distance = Math.max(1, Math.sqrt(distanceSquared))
              const force = Math.exp(-distanceSquared / (2 * repulsionSpread * repulsionSpread)) * (2.35 + particle.depth * 3.15)
              particle.velocityX += (deltaX / distance) * force - (deltaY / distance) * force * .16
              particle.velocityY += (deltaY / distance) * force + (deltaX / distance) * force * .16
            }
          }

          const shimmer = Math.sin(time * .0042 + particle.phase) * .012 * particle.depth
          particle.velocityX += shimmer
          particle.velocityY -= shimmer * .55
          particle.velocityX *= .88
          particle.velocityY *= .88
          particle.x += particle.velocityX
          particle.y += particle.velocityY
        }
      }

      drawingContext.fillStyle = haloGradient
      for (let index = 0; index < particles.length; index += 9) {
        const particle = particles[index]
        const halo = particle.radius * 4.2
        drawingContext.beginPath()
        drawingContext.arc(particle.x, particle.y, halo, 0, Math.PI * 2)
        drawingContext.fill()
      }

      drawingContext.fillStyle = particleGradient
      for (const particle of particles) {
        const pulse = reduceMotion ? 1 : .82 + Math.sin(time * .005 + particle.phase) * .18
        const radius = particle.radius * pulse
        drawingContext.beginPath()
        drawingContext.arc(particle.x, particle.y, radius, 0, Math.PI * 2)
        drawingContext.fill()
      }
      drawingContext.globalCompositeOperation = 'source-over'
    }

    function animate(time: number) {
      if (!visible) {
        frame = 0
        return
      }
      draw(time)
      frame = window.requestAnimationFrame(animate)
    }

    function updatePointer(event: PointerEvent) {
      const bounds = surface.getBoundingClientRect()
      pointer.x = event.clientX - bounds.left
      pointer.y = event.clientY - bounds.top
      pointer.active = true
    }

    function clearPointer() {
      pointer.active = false
    }

    const resizeObserver = new ResizeObserver(() => {
      window.clearTimeout(resizeTimer)
      resizeTimer = window.setTimeout(buildParticles, 100)
    })
    const visibilityObserver = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting
      if (visible && !reduceMotion && frame === 0) frame = window.requestAnimationFrame(animate)
    }, { rootMargin: '160px' })

    surface.addEventListener('pointermove', updatePointer)
    surface.addEventListener('pointerleave', clearPointer)
    surface.addEventListener('pointercancel', clearPointer)
    resizeObserver.observe(surface)
    visibilityObserver.observe(surface)
    void document.fonts.ready.then(() => {
      buildParticles()
      if (!reduceMotion && frame === 0) frame = window.requestAnimationFrame(animate)
    })

    return () => {
      window.cancelAnimationFrame(frame)
      window.clearTimeout(resizeTimer)
      resizeObserver.disconnect()
      visibilityObserver.disconnect()
      surface.removeEventListener('pointermove', updatePointer)
      surface.removeEventListener('pointerleave', clearPointer)
      surface.removeEventListener('pointercancel', clearPointer)
    }
  }, [compact])

  return (
    <section className={`particle-signature${compact ? ' compatibility-particles' : ''}`} aria-label="Interactive Solo Satoshi particle artwork">
      <canvas ref={canvasRef} role="img" aria-label="Solo Satoshi formed from interactive particles" />
    </section>
  )
}
