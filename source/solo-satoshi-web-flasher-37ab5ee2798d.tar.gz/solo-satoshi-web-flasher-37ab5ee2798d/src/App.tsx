import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { CheckCircle2, ChevronRight, CircleAlert, ExternalLink, GitFork, RefreshCw, ShieldCheck, Usb } from 'lucide-react'
import { siDiscord, siFacebook, siInstagram, siReddit, siTiktok, siX, siYoutube } from 'simple-icons/icons'
import './App.css'
import LanguageSelector from './components/LanguageSelector'
import { familyLabels } from './deviceCatalog'
import { getChannelSources, getCompatibleReleaseSources, getLatestModelImages } from './lib/compatibility'
import { supportsWebSerial } from './lib/browserCompatibility'
import { downloadAndVerify, loadManifest } from './lib/firmware'
import { flashFirmware, requestMinerPort } from './lib/flasher'
import type { FirmwareFamily, FirmwareImage, FirmwareManifest, FlashStatus, ReleaseChannel } from './types'

const socialLinks = [
  { label: 'YouTube', href: 'https://www.youtube.com/@solo.satoshi', icon: siYoutube },
  { label: 'X', href: 'https://twitter.com/SoloSatoshi', icon: siX },
  { label: 'TikTok', href: 'https://tiktok.com/@solo.satoshi', icon: siTiktok },
  { label: 'Facebook', href: 'https://www.facebook.com/people/Solo-Satoshi/61575323724787/', icon: siFacebook },
  { label: 'Instagram', href: 'https://www.instagram.com/solosatoshi_/', icon: siInstagram },
  { label: 'Reddit', href: 'https://www.reddit.com/r/SoloSatoshi/', icon: siReddit },
  { label: 'Discord', href: 'https://discord.gg/solosatoshi', icon: siDiscord },
]

function App() {
  const { t, i18n } = useTranslation()
  const copy = (key: string) => t(`site.${key}`)
  const formatDate = (date: string) => new Intl.DateTimeFormat(i18n.resolvedLanguage, { dateStyle: 'medium' }).format(new Date(date))
  const initialStatus: FlashStatus = { stage: 'idle', message: copy('ready'), progress: 0 }
  const [manifest, setManifest] = useState<FirmwareManifest | null>(null)
  const [manifestError, setManifestError] = useState('')
  const [usingFallback, setUsingFallback] = useState(false)
  const [family, setFamily] = useState<FirmwareFamily>('bitaxe')
  const [familyConfirmed, setFamilyConfirmed] = useState(false)
  const [channel, setChannel] = useState<ReleaseChannel>('stable')
  const [channelConfirmed, setChannelConfirmed] = useState(false)
  const [minerPort, setMinerPort] = useState<SerialPort | null>(null)
  const [selectedModel, setSelectedModel] = useState('')
  const [selectedReleaseTag, setSelectedReleaseTag] = useState('')
  const [selectedBoard, setSelectedBoard] = useState('')
  const [keepSettings, setKeepSettings] = useState(false)
  const [settingsAdvanced, setSettingsAdvanced] = useState(false)
  const [status, setStatus] = useState<FlashStatus>(initialStatus)
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    loadManifest().then(({ manifest: value, fallback }) => {
      setManifest(value)
      setUsingFallback(fallback)
    }).catch((error: unknown) => setManifestError(error instanceof Error ? error.message : copy('manifestLoadFailed')))
  // The manifest is language-independent and should load only once.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    setStatus((current) => current.stage === 'idle' ? initialStatus : current)
  // Refresh idle copy when the visitor changes language.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.resolvedLanguage])

  const channelSources = useMemo(() => getChannelSources(manifest, family, channel), [channel, family, manifest])
  const modelImages = useMemo(() => getLatestModelImages(manifest, family, channel, channelSources), [channel, channelSources, family, manifest])
  const modelOptions = useMemo(() => modelImages.filter((image, index, images) => images.findIndex((candidate) => candidate.model === image.model) === index), [modelImages])
  const boardOptions = useMemo(() => modelImages.filter((image) => image.model === selectedModel), [modelImages, selectedModel])
  const activeBoard = modelImages.some((image) => image.board === selectedBoard) ? selectedBoard : undefined
  const releaseSources = useMemo(() => getCompatibleReleaseSources(manifest, family, channel, activeBoard, channelSources), [activeBoard, channel, channelSources, family, manifest])
  const selectedSource = channel === 'beta' ? releaseSources[0] : releaseSources.find((item) => item.releaseTag === selectedReleaseTag)
  const selected = manifest?.firmware.find((image) =>
    image.family === family && image.channel === channel && image.board === activeBoard && image.releaseTag === selectedSource?.releaseTag
  )
  const betaAvailable = manifest?.sources.some((item) => item.family === family && item.channel === 'beta') ?? false
  const isBusy = ['downloading', 'connecting', 'flashing'].includes(status.stage)
  const serialAvailable = supportsWebSerial()

  async function connectMiner() {
    if (minerPort) {
      setMinerPort(null)
      setFamilyConfirmed(false)
      setChannelConfirmed(false)
      setSelectedModel('')
      setSelectedBoard('')
      setSelectedReleaseTag('')
      setKeepSettings(false)
      setSettingsAdvanced(false)
      setStatus(initialStatus)
      return
    }
    try {
      setStatus({ stage: 'connecting', message: copy('chooseUsb'), progress: 0 })
      setMinerPort(await requestMinerPort())
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotFoundError') {
        setStatus(initialStatus)
        return
      }
      if (error instanceof Error) setLogs([error.message])
      setStatus({ stage: 'error', message: copy('usbFailed'), progress: 0 })
    }
  }

  async function startFlash(image: FirmwareImage) {
    if (!minerPort) return
    setLogs([])
    try {
      setStatus({ stage: 'downloading', message: copy('downloading'), progress: 0 })
      const firmware = await downloadAndVerify(image, (progress) => setStatus({ stage: 'downloading', message: copy('downloading'), progress }))
      await flashFirmware(minerPort, firmware, keepSettings, {
        onConnecting: () => setStatus({ stage: 'connecting', message: copy('connectingDevice'), progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: copy('installing'), progress }),
        onRestarting: () => setStatus({ stage: 'flashing', message: copy('restartingDevice'), progress: 100 }),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: copy('flashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      setStatus({ stage: 'error', message: copy('flashFailed'), progress: 0 })
    }
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}>
          <img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" />
          <span className="brand-name">SOLO SATOSHI</span>
        </a>
        <nav aria-label={copy('pageNavigation')}>
          <a href="https://www.solosatoshi.com/shop" target="_blank" rel="noopener noreferrer">{copy('navShop')}</a>
          {serialAvailable && <a href="#how-it-works">{copy('navGuide')}</a>}
          <a href="https://github.com/SoloSatoshi" target="_blank" rel="noopener noreferrer">{copy('navGithub')} <GitFork size={15} /></a>
          <LanguageSelector />
        </nav>
      </header>

      {!serialAvailable ? (
        <main className="compatibility-gate">
          <section className="compatibility-card" role="alert" aria-labelledby="compatibility-title">
            <div className="compatibility-icon"><CircleAlert size={28} /></div>
            <div>
              <strong id="compatibility-title">{t('errors.browserCompatibility.title')}</strong>
              <p>{t('errors.browserCompatibility.description')}</p>
              <div className="browser-links" aria-label={t('errors.browserCompatibility.title')}>
                <a href="https://www.google.com/chrome/" target="_blank" rel="noopener noreferrer">Google Chrome <ExternalLink size={14} /></a>
                <a href="https://www.microsoft.com/edge/download" target="_blank" rel="noopener noreferrer">Microsoft Edge <ExternalLink size={14} /></a>
                <a href="https://brave.com/download/" target="_blank" rel="noopener noreferrer">Brave <ExternalLink size={14} /></a>
              </div>
            </div>
          </section>
        </main>
      ) : (
        <>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <h1><span className="headline-line">{copy('heroLineOne')}</span>{' '}<span className="headline-line"><span>{copy('heroWith')} </span><span className="headline-accent">{copy('heroVerified')}</span></span></h1>
            <p className="hero-summary">{copy('heroSummary')}</p>
          </div>

          <div className="hero-bolt" aria-hidden="true">
            <div className="bolt-halo" />
            <svg className="bolt-orbits" viewBox="0 0 360 380" role="presentation">
              <g transform="rotate(-18 180 190)">
                <ellipse className="orbit-line orbit-line-one" cx="180" cy="190" rx="165" ry="120" />
                <circle className="orbit-ball" r="6">
                  <animateMotion dur="2.4s" repeatCount="indefinite" path="M 345 190 A 165 120 0 1 1 15 190 A 165 120 0 1 1 345 190" />
                </circle>
              </g>
              <g transform="rotate(-18 180 190)">
                <ellipse className="orbit-line orbit-line-two" cx="180" cy="190" rx="130" ry="175" />
                <circle className="orbit-ball orbit-ball-secondary" r="5">
                  <animateMotion begin="-1.2s" dur="2.4s" repeatCount="indefinite" path="M 310 190 A 130 175 0 1 1 50 190 A 130 175 0 1 1 310 190" />
                </circle>
              </g>
            </svg>
            <svg className="bolt-mark" viewBox="0 0 260 360" role="presentation">
              <defs>
                <linearGradient id="bolt-gradient" x1="35" y1="30" x2="230" y2="330" gradientUnits="userSpaceOnUse">
                  <stop offset="0" stopColor="#f7931a" />
                  <stop offset="0.3" stopColor="#eb4b55" />
                  <stop offset="0.62" stopColor="#c71e82" />
                  <stop offset="1" stopColor="#54205a" />
                </linearGradient>
                <linearGradient id="bolt-highlight" x1="65" y1="40" x2="180" y2="300" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#fff4dd" stopOpacity="0.9" />
                  <stop offset="0.55" stopColor="#f8a8d3" stopOpacity="0.5" />
                  <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path className="bolt-shadow" d="M151 16 47 197h74l-19 147 111-199h-76z" />
              <path className="bolt-body" d="M151 16 47 197h74l-19 147 111-199h-76z" />
              <path className="bolt-highlight" d="M151 16 72 181h62l-21 120 78-140h-72z" />
            </svg>
          </div>
        </section>

        <section className="installer" id="installer" aria-labelledby="installer-title">
          <div className="installer-heading">
            <div>
              <p className="section-label">{copy('installerLabel')}</p>
              <h2 id="installer-title">{copy('installerTitle')}</h2>
            </div>
            <div className="verified-mark"><ShieldCheck size={17} /><span>{copy('verifiedFiles')}</span></div>
          </div>

          <div className="installer-layout">
            <aside className="process-rail" aria-label={copy('processLabel')}>
              <ol>
                <li className={minerPort ? 'complete' : 'active'} aria-current={!minerPort ? 'step' : undefined}><span>1</span><div><strong>{copy('stepsConnect')}</strong><small>{copy('stepsConnectNote')}</small></div></li>
                <li className={!minerPort ? 'locked' : familyConfirmed ? 'complete' : 'active'} aria-current={minerPort && !familyConfirmed ? 'step' : undefined}><span>2</span><div><strong>{copy('stepsFamily')}</strong><small>{copy('stepsFamilyNote')}</small></div></li>
                <li className={!familyConfirmed ? 'locked' : channelConfirmed ? 'complete' : 'active'} aria-current={familyConfirmed && !channelConfirmed ? 'step' : undefined}><span>3</span><div><strong>{copy('stepsChannel')}</strong><small>{copy('stepsChannelNote')}</small></div></li>
                <li className={!channelConfirmed ? 'locked' : selectedModel ? 'complete' : 'active'} aria-current={channelConfirmed && !selectedModel ? 'step' : undefined}><span>4</span><div><strong>{copy('stepsModel')}</strong><small>{copy('stepsModelNote')}</small></div></li>
                <li className={!selectedModel ? 'locked' : activeBoard ? 'complete' : 'active'} aria-current={selectedModel && !activeBoard ? 'step' : undefined}><span>5</span><div><strong>{copy('stepsBoard')}</strong><small>{copy('stepsBoardNote')}</small></div></li>
                <li className={!activeBoard ? 'locked' : selected ? 'complete' : 'active'} aria-current={activeBoard && !selected ? 'step' : undefined}><span>6</span><div><strong>{copy('stepsVersion')}</strong><small>{copy('stepsVersionNote')}</small></div></li>
                <li className={!selected ? 'locked' : settingsAdvanced || status.stage !== 'idle' ? 'complete' : 'active'} aria-current={selected && !settingsAdvanced && status.stage === 'idle' ? 'step' : undefined}><span>7</span><div><strong>{copy('stepsSettings')}</strong><small>{copy('stepsSettingsNote')}</small></div></li>
                <li className={!selected || (!settingsAdvanced && status.stage === 'idle') ? 'locked' : 'active'} aria-current={selected && (settingsAdvanced || status.stage !== 'idle') ? 'step' : undefined}><span>8</span><div><strong>{copy('stepsInstall')}</strong><small>{copy('stepsInstallNote')}</small></div></li>
              </ol>
            </aside>

            <div className="flasher-panel">
              <section className="flow-stage connect-stage" aria-label={copy('connectLabel')}>
                <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={connectMiner}>
                  {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                  {minerPort ? t('hero.disconnect') : t('hero.connect')}
                </button>
                <p className="stage-note">{copy('connectNote')}</p>
              </section>

              <section className={`flow-stage family-stage ${!minerPort ? 'locked' : ''}`} aria-label={copy('familyLabel')} aria-disabled={!minerPort}>
                {manifestError ? (
                  <div className="browser-warning"><CircleAlert size={20} /><div><strong>{copy('firmwareUnavailable')}</strong><span>{copy('manifestLoadFailed')}</span></div></div>
                ) : (
                  <fieldset className="field-group">
                    <legend>{copy('stepsFamily')}</legend>
                    <div className="family-tabs">
                      {(Object.keys(familyLabels) as FirmwareFamily[]).map((key) => (
                        <button type="button" className={`${familyConfirmed && family === key ? 'active' : ''} family-${key}`} aria-pressed={familyConfirmed && family === key} onClick={() => { const hasPrerelease = manifest?.sources.some((item) => item.family === key && item.channel === 'beta') ?? true; setFamily(key); setFamilyConfirmed(true); setChannel('stable'); setChannelConfirmed(!hasPrerelease); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!minerPort || isBusy} key={key}>
                          <img className="family-wordmark" src={`${import.meta.env.BASE_URL}device-logos/${key}-wordmark.webp`} alt={familyLabels[key]} width={key === 'bitaxe' ? 370 : 520} height={key === 'bitaxe' ? 150 : 112} decoding="async" />
                        </button>
                      ))}
                    </div>
                  </fieldset>
                )}
              </section>

              <section className={`flow-stage channel-stage ${!familyConfirmed ? 'locked' : ''}`} aria-label={copy('channelLabel')} aria-disabled={!familyConfirmed}>
                  <fieldset className="field-group">
                    <legend>{copy('stepsChannel')}</legend>
                    <div className="channel-tabs">
                      <button type="button" className={channelConfirmed && channel === 'stable' ? 'active' : ''} aria-pressed={channelConfirmed && channel === 'stable'} onClick={() => { setChannel('stable'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('latestReleases')} <small>{copy('recommended')}</small></button>
                      {betaAvailable ? <button type="button" className={channelConfirmed && channel === 'beta' ? 'active beta' : 'beta'} aria-pressed={channelConfirmed && channel === 'beta'} onClick={() => { setChannel('beta'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('prereleases')} <small>{copy('betaReleases')}</small></button> : <button type="button" className="unavailable" disabled>{copy('noPrereleases')}</button>}
                    </div>
                  </fieldset>
                  {channel === 'beta' && <div className="beta-warning"><CircleAlert size={20} /><div><strong>{copy('prereleaseTitle')}</strong><span>{copy('prereleaseWarning')}</span></div></div>}
              </section>

              <section className={`flow-stage model-stage ${!channelConfirmed ? 'locked' : ''}`} aria-label={copy('modelLabel')} aria-disabled={!channelConfirmed}>
                    <div className="field-group">
                      <label htmlFor="model">{copy('stepsModel')}</label>
                      <select id="model" value={selectedModel} onChange={(event) => {
                        const model = event.target.value
                        setSelectedModel(model)
                        setSelectedBoard(family === 'nerdaxe' ? modelImages.find((image) => image.model === model)?.board ?? '' : '')
                        setSelectedReleaseTag('')
                        setKeepSettings(false)
                        setSettingsAdvanced(false)
                        setStatus(initialStatus)
                      }} disabled={!manifest || !channelConfirmed || isBusy}>
                        <option value="" disabled>{t('hero.selectDevice')}</option>
                        {modelOptions.map((image) => <option value={image.model} key={image.model}>{image.model}</option>)}
                      </select>
                    </div>
              </section>

              <section className={`flow-stage board-stage ${!selectedModel ? 'locked' : ''}`} aria-label={copy('boardLabel')} aria-disabled={!selectedModel}>
                    {family === 'bitaxe' ? (
                      <div className="field-group">
                        <label htmlFor="board">{copy('boardVersion')}</label>
                        <select id="board" value={selectedBoard} onChange={(event) => { setSelectedBoard(event.target.value); setSelectedReleaseTag(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!selectedModel || isBusy}>
                          <option value="" disabled>{t('hero.selectBoard')}</option>
                          {boardOptions.map((image) => <option value={image.board} key={image.board}>{image.board}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!selectedModel ? 'disabled' : ''}`}><span>{copy('boardMatch')}</span><strong>{selectedBoard || copy('selectModelFirst')}</strong><small>{copy('boardAuto')}</small></div>
                    )}
              </section>

              <section className={`flow-stage version-stage ${!activeBoard ? 'locked' : ''}`} aria-label={copy('versionLabel')} aria-disabled={!activeBoard}>
                    {channel === 'stable' ? (
                      <div className="field-group">
                        <label htmlFor="version">{copy('stepsVersion')}</label>
                        <select id="version" value={selectedReleaseTag} onChange={(event) => { setSelectedReleaseTag(event.target.value); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!activeBoard || isBusy}>
                          <option value="" disabled>{t('hero.selectFirmware')}</option>
                          {releaseSources.map((item, index) => <option value={item.releaseTag} key={item.releaseTag}>{item.releaseTag}{index === 0 ? `  •  ${copy('latest')}` : ''}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!activeBoard ? 'disabled' : ''}`}><span>{copy('stepsVersion')}</span><strong>{selected?.releaseTag ?? copy('selectModel')}</strong>{selectedSource && <small>{formatDate(selectedSource.publishedAt)}</small>}</div>
                    )}
              </section>

              <section className={`flow-stage settings-stage ${!selected ? 'locked' : ''}`} aria-label={copy('settingsLabel')} aria-disabled={!selected}>
                  <label className={`settings-row ${!selected ? 'disabled' : ''}`}>
                    <span className="settings-copy"><strong>{t('hero.keepConfig')}</strong><small>{copy('keepSettingsNote')}</small></span>
                    <span className="switch"><input type="checkbox" checked={keepSettings} onChange={(event) => { setKeepSettings(event.target.checked); if (event.target.checked) setSettingsAdvanced(true) }} disabled={!selected || isBusy} /><i /></span>
                  </label>
              </section>

              <section className={`flow-stage install-stage ${!selected ? 'locked' : ''}`} aria-label={copy('installLabel')} aria-disabled={!selected}>
                  {status.stage !== 'idle' && (
                    <div className={`status-panel ${status.stage}`} role="status">
                      <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{['downloading', 'flashing'].includes(status.stage) && <strong>{status.progress}%</strong>}</div>
                      {['downloading', 'flashing'].includes(status.stage) && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                      {status.stage === 'complete' && <p>{copy('disconnectAfterRestart')}</p>}
                    </div>
                  )}

                  <button className="flash-button" type="button" disabled={!minerPort || !selected || !serialAvailable || isBusy} onClick={() => selected && startFlash(selected)}><Usb size={19} /> {isBusy ? t('hero.flashing') : t('hero.startFlashing')} <ChevronRight size={18} /></button>
                  <p className="button-note">{!minerPort ? copy('connectToUnlock') : !selected ? copy('completeSelections') : copy('keepConnected')}</p>
                  {usingFallback && <p className="fallback-note">{copy('fallbackManifest')}</p>}
                  {logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
              </section>
            </div>
          </div>
        </section>

        <section className="preflight" id="how-it-works">
          <div className="preflight-intro">
            <p className="section-label">{copy('beforeConnecting')}</p>
            <h2>{copy('threeChecks')}</h2>
            <p>{copy('checksIntro')}</p>
          </div>
          <ol className="preflight-list">
            <li><span>1</span><div><strong>{copy('dataCable')}</strong><p>{copy('dataCableNote')}</p></div></li>
            <li><span>2</span><div><strong>{copy('matchBoard')}</strong><p>{copy('matchBoardNote')}</p></div></li>
            <li><span>3</span><div><strong>{copy('stablePower')}</strong><p>{copy('stablePowerNote')}</p></div></li>
          </ol>
        </section>

        <section className="provenance">
          <div className="provenance-icon"><ShieldCheck size={23} /></div>
          <div><p className="section-label">{copy('verifiable')}</p><h2>{copy('provenanceTitle')}</h2><p>{copy('provenanceText')}</p></div>
          <div className="source-links">{selected && <a href={selected.releaseUrl} target="_blank" rel="noopener noreferrer">{copy('viewRelease')}<ExternalLink size={14} /></a>}{selectedSource && <a href={selectedSource.sourceArchiveUrl} target="_blank" rel="noopener noreferrer">{copy('downloadSource')}<ExternalLink size={14} /></a>}</div>
        </section>

        <section className="device-support" aria-labelledby="support-title">
          <div className="support-heading"><p className="section-label">{copy('deviceSupport')}</p><h2 id="support-title">{copy('supportTitle')}</h2><p>{copy('supportText')}</p></div>
          <div className="support-list">
            <article><h3>Bitaxe</h3><p>{copy('bitaxeModels')}</p></article>
            <article><h3>NerdAxe</h3><p>{copy('nerdaxeModels')}</p></article>
          </div>
        </section>

        <section className="faq" id="faq" aria-labelledby="faq-title">
          <div><p className="section-label">{copy('questions')}</p><h2 id="faq-title">{copy('faqTitle')}</h2></div>
          <div className="faq-list">
            <details><summary>{copy('faq1q')}</summary><p>{copy('faq1a')}</p></details>
            <details><summary>{copy('faq2q')}</summary><p>{copy('faq2a')}</p></details>
            <details><summary>{copy('faq3q')}</summary><p>{copy('faq3a')}</p></details>
            <details><summary>{copy('faq4q')}</summary><p>{copy('faq4a')}</p></details>
            <details><summary>{copy('faq5q')}</summary><p>{copy('faq5a')}</p></details>
            <details><summary>{copy('faq6q')}</summary><p>{copy('faq6a')}</p></details>
            <details><summary>{copy('faq7q')}</summary><p>{copy('faq7a')}</p></details>
          </div>
        </section>

        <section className="legal-notice" aria-labelledby="legal-title">
          <div>
            <p className="section-label">{copy('policies')}</p>
            <h2 id="legal-title">{copy('legalTitle')}</h2>
          </div>
          <div className="legal-copy">
            <p>{copy('legalText')}</p>
            <nav aria-label={copy('policies')}>
              <a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacyPolicy')}</a>
              <a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('termsService')}</a>
              <a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licensesSource')}</a>
            </nav>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <a className="brand footer-brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}><img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" /><span className="brand-name">SOLO SATOSHI</span></a>
          <nav className="social-links" aria-label={copy('socialLabel')}>
            {socialLinks.map(({ label, href, icon }) => (
              <a href={href} target="_blank" rel="me noopener noreferrer" aria-label={`${label} (${copy('opensNewTab')})`} title={label} key={label}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d={icon.path} /></svg>
              </a>
            ))}
          </nav>
        </div>
        <div className="footer-bottom">
          <span>{copy('rights')}</span>
          <nav aria-label={copy('footerPolicies')}><a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacy')}</a><a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('terms')}</a><a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licenses')}</a></nav>
        </div>
      </footer>
        </>
      )}
    </div>
  )
}

export default App
