import { ESPLoader, Transport } from 'esptool-js'
import type { IEspLoaderTerminal } from 'esptool-js/lib/types/loaderTerminal.js'
import { createFlashSegments } from './firmware'

interface FlashCallbacks {
  onConnecting: (message: string) => void
  onProgress: (progress: number) => void
  onRestarting: (message: string) => void
  onLog: (line: string) => void
}

const sleep = (milliseconds: number) => new Promise((resolve) => window.setTimeout(resolve, milliseconds))

async function restartMiner(transport: Transport): Promise<void> {
  // Match the explicit reset pulse used by the upstream Bitaxe and NerdAxe
  // flashers. DTR must be released so GPIO0 stays high for a normal boot, then
  // RTS briefly pulls EN low before releasing it again.
  await transport.setDTR(false)
  await transport.setRTS(true)
  await sleep(100)
  await transport.setRTS(false)
  await sleep(500)
}

export function supportsWebSerial(): boolean {
  return 'serial' in navigator
}

export function requestMinerPort(): Promise<SerialPort> {
  if (!supportsWebSerial()) throw new Error('Web Serial is not supported in this browser.')
  return navigator.serial.requestPort()
}

export async function flashFirmware(port: SerialPort, firmware: Uint8Array, keepSettings: boolean, callbacks: FlashCallbacks): Promise<string> {
  const transport = new Transport(port, false)
  const terminal: IEspLoaderTerminal = {
    clean: () => undefined,
    write: (data) => callbacks.onLog(data),
    writeLine: (data) => callbacks.onLog(data),
  }
  const loader = new ESPLoader({ transport, baudrate: 460800, romBaudrate: 115200, terminal, debugLogging: false })
  try {
    callbacks.onConnecting('Connecting to the miner…')
    const chip = await loader.main('default_reset')
    callbacks.onConnecting(`Connected to ${chip}. Writing firmware…`)
    const segments = createFlashSegments(firmware, keepSettings)
    const totalBytes = segments.reduce((sum, segment) => sum + segment.data.length, 0)
    const completedBefore = segments.map((_, index) => segments.slice(0, index).reduce((sum, segment) => sum + segment.data.length, 0))
    await loader.writeFlash({
      fileArray: segments, flashMode: 'keep', flashFreq: 'keep', flashSize: 'keep', eraseAll: false, compress: true,
      reportProgress: (fileIndex, written) => {
        const complete = completedBefore[fileIndex] + written
        callbacks.onProgress(Math.min(100, Math.round((complete / totalBytes) * 100)))
      },
    })
    callbacks.onProgress(100)
    callbacks.onRestarting('Firmware installed. Restarting the miner automatically…')
    await restartMiner(transport)
    return chip
  } finally {
    try { await transport.disconnect() } catch { /* Reset may close the port first. */ }
  }
}
