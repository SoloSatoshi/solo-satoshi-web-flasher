import type { FirmwareImage, FirmwareManifest, FirmwareSource } from '../types'

const SHA256_PATTERN = /^[a-f0-9]{64}$/
const MIN_FACTORY_SIZE = 8 * 1024 * 1024
const MAX_FACTORY_SIZE = 20 * 1024 * 1024
const APPROVED_REPOSITORIES = {
  bitaxe: 'bitaxeorg/ESP-Miner',
  nerdaxe: 'shufps/ESP-Miner-NerdQAxePlus',
} as const
const FIRMWARE_ORIGIN = 'https://firmware.solosatoshi.com'

export const NVS_START = 0x9000
export const NVS_END = 0xf000

function isImage(value: unknown): value is FirmwareImage {
  if (!value || typeof value !== 'object') return false
  const image = value as Partial<FirmwareImage>
  return (
    (image.family === 'bitaxe' || image.family === 'nerdaxe') &&
    (image.channel === 'stable' || image.channel === 'beta') &&
    typeof image.id === 'string' && typeof image.model === 'string' &&
    typeof image.board === 'string' && typeof image.releaseTag === 'string' &&
    typeof image.assetName === 'string' && typeof image.size === 'number' &&
    image.size >= MIN_FACTORY_SIZE && image.size <= MAX_FACTORY_SIZE &&
    typeof image.sha256 === 'string' && SHA256_PATTERN.test(image.sha256) &&
    typeof image.downloadUrl === 'string' && isApprovedFirmwareUrl(image.downloadUrl) &&
    image.sourceRepository === APPROVED_REPOSITORIES[image.family] &&
    typeof image.releaseUrl === 'string' && image.releaseUrl.startsWith(`https://github.com/${image.sourceRepository}/releases/`)
  )
}

function isApprovedFirmwareUrl(value: string): boolean {
  try {
    return new URL(value).origin === FIRMWARE_ORIGIN
  } catch {
    return false
  }
}

function isSource(value: unknown): value is FirmwareSource {
  if (!value || typeof value !== 'object') return false
  const source = value as Partial<FirmwareSource>
  return (
    (source.family === 'bitaxe' || source.family === 'nerdaxe') &&
    (source.channel === 'stable' || source.channel === 'beta') &&
    source.repository === APPROVED_REPOSITORIES[source.family] &&
    typeof source.releaseTag === 'string' && typeof source.publishedAt === 'string' &&
    typeof source.releaseUrl === 'string' && source.releaseUrl.startsWith(`https://github.com/${source.repository}/releases/`) &&
    typeof source.sourceArchiveUrl === 'string' && isApprovedFirmwareUrl(source.sourceArchiveUrl)
  )
}

export function parseManifest(value: unknown): FirmwareManifest {
  if (!value || typeof value !== 'object') throw new Error('Firmware manifest is invalid.')
  const input = value as Record<string, unknown>
  const normalized = input.schemaVersion === 1 ? {
    ...input,
    schemaVersion: 2,
    sources: Array.isArray(input.sources) ? input.sources.map((source) => ({ ...(source as object), channel: 'stable' })) : input.sources,
    firmware: Array.isArray(input.firmware) ? input.firmware.map((image) => ({ ...(image as object), channel: 'stable' })) : input.firmware,
  } : input
  const manifest = normalized as Partial<FirmwareManifest>
  if (manifest.schemaVersion !== 2 || typeof manifest.generatedAt !== 'string' ||
    !Array.isArray(manifest.sources) || !manifest.sources.every(isSource) || !Array.isArray(manifest.firmware) ||
    manifest.firmware.length === 0 || !manifest.firmware.every(isImage)) {
    throw new Error('Firmware manifest is invalid or empty.')
  }
  return manifest as FirmwareManifest
}

export async function loadManifest(): Promise<{ manifest: FirmwareManifest; fallback: boolean }> {
  const configuredUrl = import.meta.env.VITE_FIRMWARE_MANIFEST_URL as string | undefined
  const remoteUrl = configuredUrl || 'https://firmware.solosatoshi.com/firmware-index.json'
  try {
    const response = await fetch(`${remoteUrl}?t=${Date.now()}`, { cache: 'no-store' })
    if (!response.ok) throw new Error(`Firmware service returned ${response.status}.`)
    return { manifest: parseManifest(await response.json()), fallback: false }
  } catch (remoteError) {
    const response = await fetch(`${import.meta.env.BASE_URL}firmware-index.json`, { cache: 'no-store' })
    if (!response.ok) throw remoteError
    return { manifest: parseManifest(await response.json()), fallback: true }
  }
}

export async function downloadAndVerify(image: FirmwareImage, onProgress: (progress: number) => void): Promise<Uint8Array> {
  const response = await fetch(image.downloadUrl, { cache: 'no-store' })
  if (!response.ok) throw new Error(`Firmware download failed (${response.status}).`)
  const contentLength = Number(response.headers.get('content-length'))
  let bytes: Uint8Array
  if (response.body && contentLength > 0) {
    const reader = response.body.getReader()
    const chunks: Uint8Array[] = []
    let received = 0
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      chunks.push(value)
      received += value.length
      onProgress(Math.min(100, Math.round((received / contentLength) * 100)))
    }
    bytes = new Uint8Array(received)
    let offset = 0
    for (const chunk of chunks) {
      bytes.set(chunk, offset)
      offset += chunk.length
    }
  } else {
    bytes = new Uint8Array(await response.arrayBuffer())
  }
  if (bytes.length !== image.size) throw new Error(`Firmware size check failed. Expected ${image.size} bytes, received ${bytes.length}.`)
  const digest = await sha256(bytes)
  if (digest !== image.sha256) throw new Error('Firmware security check failed. The downloaded file does not match GitHub.')
  onProgress(100)
  return bytes
}

export async function sha256(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(bytes).buffer)
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('')
}

export function createFlashSegments(firmware: Uint8Array, keepSettings: boolean) {
  if (!keepSettings) return [{ data: firmware, address: 0 }]
  if (firmware.length <= NVS_END) throw new Error('Firmware image is too small to preserve settings safely.')
  return [
    { data: firmware.slice(0, NVS_START), address: 0 },
    { data: firmware.slice(NVS_END), address: NVS_END },
  ]
}
