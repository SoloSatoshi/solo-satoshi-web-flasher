/* SPDX-License-Identifier: GPL-3.0-only; Copyright (C) 2026 Solo Satoshi LLC. */
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { useTranslation } from 'react-i18next'
import { analyticsAllowed, chooseConsent, getConsent, initializeConsent, subscribeConsent } from '../lib/consent'
import { initializeAnalytics } from '../lib/analytics'
export default function AnalyticsPreferences() {
  const { t } = useTranslation()
  const state = useSyncExternalStore(subscribeConsent, getConsent)
  const [open, setOpen] = useState(false)
  const trigger = useRef<HTMLButtonElement>(null)
  useEffect(() => { initializeAnalytics(); void initializeConsent() }, [])
  const show = open || (state.ready && !state.blocked && !state.choice && state.policy === 'opt-in')
  const choose = (choice: 'accepted' | 'declined') => { chooseConsent(choice); setOpen(false); if (open) trigger.current?.focus() }
  return <>
    <button type="button" ref={trigger} className="analytics-preferences-link" onClick={() => setOpen(!open)} aria-expanded={show} aria-controls="analytics-preferences">{t('site.analyticsPreferences')}</button>
    {show && <section id="analytics-preferences" className="analytics-preferences" aria-labelledby="analytics-preferences-title">
      <h2 id="analytics-preferences-title">{t('site.analyticsTitle')}</h2>
      <p>{t('site.analyticsDescription')}</p>
      {open && <p role="status">{t(analyticsAllowed() ? 'site.analyticsOn' : 'site.analyticsOff')}</p>}
      {state.blocked && <p role="status">{t('site.analyticsSignal')}</p>}
      <div className="analytics-preferences-actions">
        <button type="button" disabled={state.blocked} onClick={() => choose('accepted')}>{t('site.analyticsAccept')}</button>
        <button type="button" onClick={() => choose('declined')}>{t('site.analyticsDecline')}</button>
        <a href={`${import.meta.env.BASE_URL}privacy.html#cookies`}>{t('site.privacyPolicy')}</a>
        {open && <button type="button" onClick={() => { setOpen(false); trigger.current?.focus() }}>{t('site.analyticsClose')}</button>}
      </div>
    </section>}
  </>
}
