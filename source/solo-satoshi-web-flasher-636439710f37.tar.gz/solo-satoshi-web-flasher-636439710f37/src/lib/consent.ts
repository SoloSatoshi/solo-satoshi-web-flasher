/* SPDX-License-Identifier: GPL-3.0-only; Copyright (C) 2026 Solo Satoshi LLC. */
export const consentKey = 'soloSatoshiFlasherAnalytics'
const version = 1
const lifetime = 180 * 24 * 60 * 60 * 1000
export type ConsentState = { ready: boolean; policy: 'opt-in' | 'us-default'; choice: 'accepted' | 'declined' | null; blocked: boolean }
let state: ConsentState = { ready: false, policy: 'opt-in', choice: null, blocked: false }
let started = false
const listeners = new Set<() => void>()
export function privacyBlocked() {
  return navigator.doNotTrack === '1' || navigator.doNotTrack === 'yes' || Boolean((navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl)
}
export function readConsent(now = Date.now()): ConsentState['choice'] {
  try {
    const saved = JSON.parse(localStorage.getItem(consentKey) || 'null')
    if (saved?.version === version && ['accepted', 'declined'].includes(saved.choice) && typeof saved.date === 'number' && now >= saved.date && now - saved.date < lifetime) return saved.choice
  } catch { /* Storage may be disabled. Remain opt-in. */ }
  return null
}
export function getConsent() { return state }
export function subscribeConsent(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener) } }
function notify(next: ConsentState) { state = next; for (const listener of listeners) listener() }
export function analyticsAllowed() {
  return window.location.hostname === 'flash.solosatoshi.com' && !privacyBlocked() && state.ready && state.choice !== 'declined' && (state.choice === 'accepted' || state.policy === 'us-default')
}
export function chooseConsent(choice: 'accepted' | 'declined') {
  if (choice !== 'accepted' && choice !== 'declined') return
  try { localStorage.setItem(consentKey, JSON.stringify({ choice, date: Date.now(), version })) } catch { /* Keep choice in memory. */ }
  notify({ ...state, ready: true, choice, blocked: privacyBlocked() })
}
export async function initializeConsent() {
  if (started) return
  started = true
  window.addEventListener('storage', event => {
    if (event.key === consentKey || event.key === null) notify({ ...state, choice: readConsent(), blocked: privacyBlocked() })
  })
  const choice = readConsent(), blocked = privacyBlocked()
  if (choice || blocked || window.location.hostname !== 'flash.solosatoshi.com') {
    notify({ ready: true, policy: 'opt-in', choice, blocked }); return
  }
  let policy: ConsentState['policy'] = 'opt-in'
  try {
    const response = await fetch('https://consent.solosatoshi.com/policy', { method: 'GET', credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer', signal: AbortSignal.timeout(2000) })
    const data = response.ok ? await response.json() : null
    if (data?.version === version && data.policy === 'us-default') policy = 'us-default'
  } catch { /* Unavailable or unknown location fails closed. */ }
  notify({ ready: true, policy, choice: state.choice ?? readConsent(), blocked: privacyBlocked() })
}
