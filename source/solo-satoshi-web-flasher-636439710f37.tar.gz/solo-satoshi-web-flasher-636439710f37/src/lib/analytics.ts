/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Solo Satoshi LLC. See NOTICE.md for attribution.
 */

import { analyticsAllowed, subscribeConsent } from './consent'
const labelPattern = /^[a-zA-Z0-9 ._:+-]{1,100}$/
let initialized = false
let frame: HTMLIFrameElement | null = null
let ready = false
let pending: string[][] = []
function sendEvent(event: string[]) {
  if (!frame || !analyticsAllowed()) return
  if (ready) frame.contentWindow?.postMessage({ type: 'ss-analytics-event', event }, '*')
  else if (pending.length < 50) pending.push(event)
}
function syncAnalytics() {
  try {
  if (!analyticsAllowed()) {
    frame?.remove(); frame = null; ready = false; pending = []; return
  }
  if (frame) return
  const next = document.createElement('iframe')
  next.hidden = true
  next.title = 'Optional analytics'
  next.setAttribute('sandbox', 'allow-scripts')
  next.setAttribute('allow', "camera 'none'; microphone 'none'; geolocation 'none'; usb 'none'; serial 'none'")
  next.referrerPolicy = 'no-referrer'
  next.src = new URL('analytics.html', window.location.href).href
  next.onload = () => { if (next === frame && analyticsAllowed()) next.contentWindow?.postMessage({ type: 'ss-analytics-init' }, '*') }
  frame = next
  document.body.append(next)
  } catch { frame?.remove(); frame = null; ready = false; pending = [] }
}
/** Only explicit labels/public selection tokens; never DOM text or form content. */
export function trackAnalyticsEvent(category: string, action: string, name: string) {
  try {
    if (!analyticsAllowed() || !labelPattern.test(category) || !labelPattern.test(action) || !labelPattern.test(name)) return
    sendEvent([category, action, name])
  } catch { /* Analytics must never interfere with USB or user actions. */ }
}

export function trackInteraction(event: Event) {
  try {
    if (!(event.target instanceof Element)) return
    if (event.type === 'click') {
      const element = event.target.closest('button[data-analytics], a[data-analytics], summary[data-analytics], input[type="file"][data-analytics]')
      if (!element || element.hasAttribute('disabled')) return
      const name = element.getAttribute('data-analytics') || ''
      const category = element.tagName === 'A' ? 'Link' : element.tagName === 'SUMMARY' ? 'Help' : 'Button'
      trackAnalyticsEvent(category, 'Clicked', name)
    } else if (event.type === 'change') {
      const element = event.target
      const name = element.getAttribute('data-analytics') || ''
      if (element instanceof HTMLSelectElement) {
        // Only selected public options are allowed, never a typed free-text value.
        const option = element.selectedOptions[0]
        if (option && option.value) trackAnalyticsEvent('Selection', 'Changed', `${name}:${option.value}`)
      } else if (element instanceof HTMLInputElement && element.type === 'checkbox') {
        trackAnalyticsEvent('Selection', 'Changed', `${name}:${element.checked ? 'on' : 'off'}`)
      }
    }
  } catch { /* Metrics are best-effort and cannot block application behavior. */ }
}

export function initializeAnalytics() {
  if (initialized) return
  initialized = true
  subscribeConsent(syncAnalytics)
  document.addEventListener('visibilitychange', syncAnalytics)
  document.addEventListener('click', trackInteraction, true)
  document.addEventListener('change', trackInteraction, true)
  window.addEventListener('message', event => {
    if (!frame || event.source !== frame.contentWindow || event.data?.type !== 'ss-analytics-ready' || !analyticsAllowed()) return
    ready = true
    for (const item of pending) sendEvent(item)
    pending = []
  })
  syncAnalytics()
}
