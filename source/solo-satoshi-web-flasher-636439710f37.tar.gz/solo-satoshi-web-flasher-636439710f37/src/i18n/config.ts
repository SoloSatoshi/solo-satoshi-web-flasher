/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import i18n from 'i18next'
import type { BackendModule } from 'i18next'
import LanguageDetector from 'i18next-browser-languagedetector'
import { initReactI18next } from 'react-i18next'
import en from './locales/en.json'

export const supportedLanguages = [
  { value: 'en', label: 'English' },
  { value: 'de', label: 'Deutsch' },
  { value: 'it', label: 'Italiano' },
  { value: 'tlh', label: 'Klingon' },
  { value: 'pt', label: 'Portuguese' },
  { value: 'ru', label: 'Русский' },
  { value: 'tr', label: 'Türkçe' },
  { value: 'sk', label: 'Slovenský' },
  { value: 'ro', label: 'Română' },
] as const

const localeLoaders = import.meta.glob<typeof en>('./locales/*.json', { import: 'default' })
const lazyLocales: BackendModule = {
  type: 'backend',
  init() {},
  read(language, _namespace, callback) {
    const load = localeLoaders[`./locales/${language}.json`]
    if (!load) { callback(null, {}); return }
    load().then(resource => callback(null, resource)).catch(error => callback(error, false))
  },
}

export const i18nReady = i18n
  .use(lazyLocales)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: { en: { translation: en } },
    partialBundledLanguages: true,
    react: { useSuspense: false },
    fallbackLng: 'en',
    supportedLngs: supportedLanguages.map(({ value }) => value),
    nonExplicitSupportedLngs: true,
    interpolation: { escapeValue: false },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
      lookupLocalStorage: 'soloSatoshiFlasherLanguage',
    },
  })

export default i18n
