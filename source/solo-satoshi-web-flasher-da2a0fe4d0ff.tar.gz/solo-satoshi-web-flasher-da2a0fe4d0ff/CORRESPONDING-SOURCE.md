# Corresponding source build guide

This archive contains the preferred source form for the Solo Satoshi Web
Flasher browser application distributed at https://flash.solosatoshi.com/.

## Build requirements

- Node.js 22
- npm

## Build

```bash
npm ci
npm run build
```

The production files are written to `dist/`. The firmware manifest URL defaults
to the public Solo Satoshi firmware service and can be set at build time with
the `VITE_FIRMWARE_MANIFEST_URL` environment variable.

Production also supplies `VITE_ISSUE_REPORT_URL` and the public
`VITE_TURNSTILE_SITE_KEY` for the optional issue-report form. These are browser
configuration, not server credentials. Without them, the support form cannot
submit. The application exposes verified releases and advanced custom flashing;
experimental tools are not exposed in this production application.

The adjacent `version.json` identifies the source commit, versioned filename,
and SHA-256 of this archive. `latest.tar.gz` and that versioned archive contain
identical bytes. The bundled firmware manifest matches the deployed fallback
manifest at packaging time; the live firmware service may subsequently update.

The application is licensed under GNU GPL version 3 only. See `LICENSE`,
`LICENSE-SCOPE.md`, `NOTICE.md`, and `TRADEMARKS.md`.

The archive is limited to the GPL-covered browser application and the files
needed to build it. Separate website content, internal quality checks,
deployment automation, infrastructure configuration, credentials, development
history, and business materials are not part of this source package.
