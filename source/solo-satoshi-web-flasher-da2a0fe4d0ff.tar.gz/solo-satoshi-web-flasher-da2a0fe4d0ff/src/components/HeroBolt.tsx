/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Solo Satoshi LLC. See NOTICE.md for attribution.
 */

export default function HeroBolt() {
  return (
    <div className="hero-bolt" aria-hidden="true">
      <div className="bolt-halo" />
      <svg className="bolt-orbits" viewBox="0 0 360 380" role="presentation">
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-one" cx="180" cy="190" rx="165" ry="120" />
          <circle className="orbit-ball" r="6">
            <animateMotion dur="2.4s" repeatCount="indefinite" path="M 345 190 A 165 120 0 1 1 15 190 A 165 120 0 1 1 345 190" />
          </circle>
        </g>
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-two" cx="180" cy="190" rx="130" ry="175" />
          <circle className="orbit-ball orbit-ball-secondary" r="5">
            <animateMotion begin="-1.2s" dur="2.4s" repeatCount="indefinite" path="M 310 190 A 130 175 0 1 1 50 190 A 130 175 0 1 1 310 190" />
          </circle>
        </g>
      </svg>
      <svg className="bolt-mark" viewBox="0 0 260 360" role="presentation">
        <defs>
          <linearGradient id="bolt-gradient" x1="35" y1="30" x2="230" y2="330" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#f7931a" />
            <stop offset="0.3" stopColor="#eb4b55" />
            <stop offset="0.62" stopColor="#c71e82" />
            <stop offset="1" stopColor="#54205a" />
          </linearGradient>
          <linearGradient id="bolt-highlight" x1="65" y1="40" x2="180" y2="300" gradientUnits="userSpaceOnUse">
            <stop stopColor="#ffe8f3" stopOpacity="0.9" />
            <stop offset="0.55" stopColor="#f8a8d3" stopOpacity="0.5" />
            <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="bolt-shadow" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-body" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-highlight" d="M151 16 72 181h62l-21 120 78-140h-72z" />
      </svg>
    </div>
  )
}
