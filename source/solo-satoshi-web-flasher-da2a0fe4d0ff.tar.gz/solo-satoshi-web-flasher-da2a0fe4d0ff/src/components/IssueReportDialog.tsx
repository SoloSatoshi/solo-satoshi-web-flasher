/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Solo Satoshi LLC. See NOTICE.md for attribution.
 */

import { useCallback, useImperativeHandle, useRef, useState } from 'react'
import type { FormEvent, Ref } from 'react'
import { useTranslation } from 'react-i18next'
import { CheckCircle2, Send, X } from 'lucide-react'
import TurnstileWidget from './TurnstileWidget'

type IssueReportStatus = 'idle' | 'sending' | 'sent' | 'error'
const issueReportEndpoint = import.meta.env.VITE_ISSUE_REPORT_URL as string | undefined
const turnstileSiteKey = import.meta.env.VITE_TURNSTILE_SITE_KEY as string | undefined

export type IssueReportHandle = { open: () => void }

export default function IssueReportDialog({ ref }: { ref: Ref<IssueReportHandle> }) {
  const { t, i18n } = useTranslation()
  const copy = (key: string) => t(`site.${key}`)
  const [issueEmail, setIssueEmail] = useState('')
  const [issueDescription, setIssueDescription] = useState('')
  const [issueReportStatus, setIssueReportStatus] = useState<IssueReportStatus>('idle')
  const [turnstileToken, setTurnstileToken] = useState('')
  const [turnstileError, setTurnstileError] = useState(false)
  const [turnstileSession, setTurnstileSession] = useState(0)
  const [issueDialogOpen, setIssueDialogOpen] = useState(false)
  const issueDialogRef = useRef<HTMLDialogElement>(null)
  const sendingRef = useRef(false)
  const handleTurnstileError = useCallback(() => {
    setTurnstileError(true)
  }, [])

  useImperativeHandle(ref, () => ({ open() {
    if (sendingRef.current || issueDialogRef.current?.open) return
    setIssueReportStatus('idle')
    setTurnstileToken('')
    setTurnstileError(false)
    setTurnstileSession((current) => current + 1)
    setIssueDialogOpen(true)
    issueDialogRef.current?.showModal()
  } }), [])

  function closeIssueReport() {
    if (sendingRef.current) return
    issueDialogRef.current?.close()
  }

  async function submitIssueReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (sendingRef.current) return
    const form = new FormData(event.currentTarget)
    const email = issueEmail.trim()
    const description = issueDescription.trim()
    if (!event.currentTarget.checkValidity() || email.length > 254 || description.length < 10 || description.length > 4000 || !issueReportEndpoint || !turnstileToken) {
      setIssueReportStatus('error')
      return
    }
    sendingRef.current = true
    setIssueReportStatus('sending')
    try {
      const response = await fetch(issueReportEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, description, website: form.get('website'), turnstileToken }),
        signal: AbortSignal.timeout(30_000),
      })
      if (!response.ok) throw new Error(`Issue report failed with status ${response.status}.`)
      if ((await response.json()).ok !== true) throw new Error('Issue report delivery was not confirmed.')
      setIssueEmail('')
      setIssueDescription('')
      setIssueReportStatus('sent')
    } catch {
      setIssueReportStatus('error')
      setTurnstileToken('')
      setTurnstileSession((current) => current + 1)
    } finally {
      sendingRef.current = false
    }
  }

  return (
      <dialog className="issue-dialog" ref={issueDialogRef} onCancel={(event) => { if (sendingRef.current) event.preventDefault() }} onClose={() => { setIssueDialogOpen(false); setTurnstileToken(''); setTurnstileError(false); if (issueReportStatus !== 'sent') { setIssueReportStatus('idle') } }}>
        <div className="issue-dialog-heading">
          <div><p className="section-label">{copy('reportLabel')}</p><h2>{copy('reportTitle')}</h2></div>
          <button className="issue-dialog-close" type="button" onClick={closeIssueReport} disabled={issueReportStatus === 'sending'} aria-label={copy('closeReport')}><X size={20} /></button>
        </div>
        {issueReportStatus === 'sent' ? (
          <div className="issue-report-success" role="status"><CheckCircle2 size={28} /><h3>{copy('reportSuccessTitle')}</h3><p>{copy('reportSuccessText')}</p><button type="button" onClick={closeIssueReport}>{copy('closeReport')}</button></div>
        ) : (
          <form className="issue-report-form" onSubmit={(event) => void submitIssueReport(event)}>
            <p>{copy('reportDescription')}</p>
            <label htmlFor="issue-email">{copy('issueEmailLabel')}</label>
            <input id="issue-email" type="email" value={issueEmail} onChange={(event) => { setIssueEmail(event.target.value); if (issueReportStatus === 'error') setIssueReportStatus('idle') }} maxLength={254} placeholder={copy('issueEmailPlaceholder')} autoComplete="email" inputMode="email" required autoFocus />
            <small>{copy('issueEmailNote')}</small>
            <label htmlFor="issue-description">{copy('issueDescriptionLabel')}</label>
            <textarea id="issue-description" value={issueDescription} onChange={(event) => { setIssueDescription(event.target.value); if (issueReportStatus === 'error') setIssueReportStatus('idle') }} minLength={10} maxLength={4000} placeholder={copy('issueDescriptionPlaceholder')} required />
            <label className="bot-trap" aria-hidden="true">Website<input name="website" type="text" tabIndex={-1} autoComplete="off" /></label>
            <small>{copy('issuePrivacyNote')}</small>
            {issueDialogOpen && turnstileSiteKey ? <TurnstileWidget key={turnstileSession} siteKey={turnstileSiteKey} language={i18n.resolvedLanguage || 'en'} onToken={setTurnstileToken} onError={handleTurnstileError} /> : null}
            {(turnstileError || !turnstileSiteKey) && <p className="issue-report-error" role="alert">{copy('reportVerificationError')}</p>}
            {issueReportStatus === 'error' && <p className="issue-report-error" role="alert">{copy('reportError')}</p>}
            <div className="issue-dialog-actions"><button type="button" onClick={closeIssueReport} disabled={issueReportStatus === 'sending'}>{copy('cancel')}</button><button type="submit" disabled={issueReportStatus === 'sending' || !issueEmail.trim() || issueDescription.trim().length < 10 || !turnstileToken}><Send size={17} />{copy(issueReportStatus === 'sending' ? 'sendingReport' : 'sendReport')}</button></div>
          </form>
        )}
      </dialog>
  )
}
