/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { useEffect, useState } from 'react'
import { CheckCircle2, CircleAlert, RefreshCw } from 'lucide-react'
import type { FlashStatus } from './types'
import { isDiagnosticOrigin } from './lib/flashProgress'

function StepElapsed({ copy }: { copy: (key: string) => string }) {
  const [elapsed, setElapsed] = useState(0)
  useEffect(() => {
    const started = Date.now()
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000)
    return () => window.clearInterval(timer)
  }, [])
  return <p className="flash-progress-detail" aria-live="off">{copy('flashStepElapsed')} {elapsed}s · {copy('flashStayConnected')}</p>
}

export function FlashProgress({ status, copy }: { status: FlashStatus; copy: (key: string) => string }) {
  const busy = ['downloading', 'connecting', 'flashing'].includes(status.stage)
  return <>
    <div className="status-title">
      {status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}
      <span>{status.message}</span>
      {busy && <strong>{status.indeterminate ? copy('flashWorking') : `${status.progress}%`}</strong>}
    </div>
    {busy && <>
      {status.indeterminate
        ? <div className="progress-track progress-working" role="progressbar" aria-label={copy('progressLabel')} aria-valuetext={status.message} />
        : <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')} aria-valuetext={status.message} />}
      {typeof window !== 'undefined' && isDiagnosticOrigin(window.location.origin)
        ? <StepElapsed key={status.message} copy={copy} />
        : <p className="flash-progress-detail">{copy('flashStayConnected')}</p>}
    </>}
  </>
}
