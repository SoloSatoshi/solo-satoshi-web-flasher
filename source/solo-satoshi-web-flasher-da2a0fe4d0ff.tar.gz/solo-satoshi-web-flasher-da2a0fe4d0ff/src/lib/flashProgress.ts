/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

const clampPercent = (value: number) => Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0))

export const isDiagnosticOrigin = (origin: string) => import.meta.env.DEV && /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)

/** Production receives only explicit user-facing statuses, never library output. */
export function createFlashLog(diagnostics: boolean, append: (line: string) => void) {
  let previous = ''
  let progressBucket = -1
  const status = (message: string) => {
    if (message !== previous) append(message)
    previous = message
  }
  return {
    status,
    raw: (line: string) => { if (diagnostics) append(line) },
    progress: (message: string, percent: number) => {
      const bucket = Math.floor(clampPercent(percent) / 10)
      if (bucket > progressBucket) status(`${message}: ${bucket * 10}%`)
      progressBucket = Math.max(progressBucket, bucket)
    },
  }
}

export const POST_FLASH_PROGRESS = { verified: 92, restarting: 96, disconnected: 98, complete: 100 } as const
export const downloadProgress = (percent: number) => Math.round(clampPercent(percent) * 0.15)
export const installProgress = (percent: number) => 20 + Math.round(clampPercent(percent) * 0.7)

/** esptool reports compressed bytes; weight each segment by its original size. */
export function writeProgress(lengths: number[], fileIndex: number, written: number, compressedTotal: number): number {
  const total = lengths.reduce((sum, length) => sum + length, 0)
  if (!total || !lengths[fileIndex] || compressedTotal <= 0 || !Number.isFinite(compressedTotal)) return 0
  const before = lengths.slice(0, fileIndex).reduce((sum, length) => sum + length, 0)
  const fraction = clampPercent(written / compressedTotal * 100) / 100
  return clampPercent(Math.round((before + lengths[fileIndex] * fraction) / total * 100))
}
