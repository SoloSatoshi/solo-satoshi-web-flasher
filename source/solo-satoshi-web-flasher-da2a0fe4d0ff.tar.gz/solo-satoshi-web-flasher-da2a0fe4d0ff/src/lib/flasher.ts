/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import type { Transport } from 'esptool-js'
import type { IEspLoaderTerminal } from 'esptool-js/lib/types/loaderTerminal.js'
import { md5 } from '@noble/hashes/legacy.js'
import { createFlashSegments } from './firmware'
import { supportsWebSerial } from './browserCompatibility'
import { writeProgress } from './flashProgress'

export type FlashOperation = 'preparing' | 'erasing' | 'writing' | 'finishing' | 'verifying'

interface FlashCallbacks {
  expectedChip?: string
  speedTrial?: boolean
  performanceDiagnostics?: boolean
  onConnecting: (message: string) => void
  onProgress: (progress: number) => void
  onOperation?: (operation: FlashOperation) => void
  onWrittenAndVerified: () => void
  onRestarting: (message: string) => void
  onDisconnected: () => void
  onRestartComplete: () => void
  onLog: (line: string) => void
}

const sleep = (milliseconds: number) => new Promise((resolve) => window.setTimeout(resolve, milliseconds))
const FLASH_BAUD_RATE = 921600
const FAST_TRIAL_BAUD_RATE = 1500000
const fastTrialDisabled = new WeakSet<SerialPort>()
const bytesToHex = (bytes: Uint8Array) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')

export class BootloaderConnectionError extends Error {
  readonly originalError: unknown

  constructor(originalError: unknown) {
    super(originalError instanceof Error ? originalError.message : 'The miner did not respond in bootloader mode.')
    this.name = 'BootloaderConnectionError'
    this.originalError = originalError
  }
}

export class IncompatibleChipError extends Error {
  constructor(chip: string, expectedChip: string) {
    super(`Connected chip ${chip} does not match required chip ${expectedChip}.`)
    this.name = 'IncompatibleChipError'
  }
}

async function restartMiner(transport: Transport): Promise<void> {
  // Match the explicit reset pulse used by the upstream Bitaxe and NerdAxe
  // flashers. DTR must be released so GPIO0 stays high for a normal boot, then
  // RTS briefly pulls EN low before releasing it again.
  await transport.setDTR(false)
  await transport.setRTS(true)
  await sleep(100)
  await transport.setRTS(false)
  await sleep(500)
}

export function requestMinerPort(): Promise<SerialPort> {
  if (!supportsWebSerial()) throw new Error('Web Serial is not supported in this browser.')
  return navigator.serial.requestPort()
}

export async function flashFirmware(port: SerialPort, firmware: Uint8Array, keepSettings: boolean, callbacks: FlashCallbacks): Promise<string> {
  const started = performance.now()
  const diagnostics = callbacks.performanceDiagnostics === true
  const requestedBaud = callbacks.speedTrial && !fastTrialDisabled.has(port) ? FAST_TRIAL_BAUD_RATE : FLASH_BAUD_RATE
  const perf = (message: string) => { if (diagnostics) callbacks.onLog(`[PERF +${((performance.now() - started) / 1000).toFixed(3)} s] ${message}`) }
  let phase = 'connecting'
  let phaseStarted = started
  const timings = new Map<string, number>()
  const finishPhase = () => {
    const elapsed = performance.now() - phaseStarted
    timings.set(phase, (timings.get(phase) || 0) + elapsed)
    perf(`${phase}: ${(elapsed / 1000).toFixed(3)} s.`)
  }
  const nextPhase = (next: string) => { finishPhase(); phase = next; phaseStarted = performance.now() }
  const { ESPLoader, Transport } = await import('esptool-js')
  const transport = new Transport(port, false)
  let operation: FlashOperation | undefined
  const setOperation = (next: FlashOperation) => {
    if (operation !== next) { if (diagnostics) nextPhase(next); callbacks.onOperation?.(next) }
    operation = next
  }
  const log = (data: string) => {
    // These messages occur at actual library operations, not timed guesses.
    if (/^Compressed \d+ bytes|^Erasing flash/.test(data)) setOperation('erasing')
    if (/^File\s+md5:/.test(data)) setOperation('verifying')
    callbacks.onLog(data)
  }
  const terminal: IEspLoaderTerminal = {
    clean: () => undefined,
    write: log,
    writeLine: log,
  }
  // Connect at the ROM-safe speed, then let esptool-js negotiate the faster
  // transfer rate. The library automatically returns to the ROM rate when the
  // chip or serial transport does not respond after the switch.
  const makeLoader = (baudrate: number) => new ESPLoader({ transport, baudrate, romBaudrate: 115200, terminal, debugLogging: false })
  let loader = makeLoader(requestedBaud)
  try {
    perf(`ESP firmware speed trial. Requested ${requestedBaud} baud; compressed transfer; device MD5 verification retained.`)
    callbacks.onConnecting('Connecting to the miner…')
    let chip: string
    try {
      try {
        chip = await loader.main('default_reset')
      } catch (error) {
        if (requestedBaud !== FAST_TRIAL_BAUD_RATE) throw error
        fastTrialDisabled.add(port)
        perf(`Fast connection unsuccessful. Reconnecting at ${FLASH_BAUD_RATE} baud before any flash writes.`)
        await transport.disconnect()
        loader = makeLoader(FLASH_BAUD_RATE)
        chip = await loader.main('default_reset')
      }
    } catch (error) {
      throw new BootloaderConnectionError(error)
    }
    if (callbacks.expectedChip && loader.chip.CHIP_NAME.toUpperCase() !== callbacks.expectedChip.toUpperCase()) {
      throw new IncompatibleChipError(loader.chip.CHIP_NAME, callbacks.expectedChip)
    }

    perf(`Actual transport rate: ${transport.baudrate} baud. Baud is not a guarantee of native USB throughput.`)
    if (callbacks.speedTrial && requestedBaud === FAST_TRIAL_BAUD_RATE && transport.baudrate !== FAST_TRIAL_BAUD_RATE) {
      fastTrialDisabled.add(port)
      perf('Library selected a safe fallback rate. Faster trial disabled for the rest of this page session.')
    }
    callbacks.onConnecting(`Connected to ${chip}. Writing firmware…`)
    setOperation('preparing')
    const segments = createFlashSegments(firmware, keepSettings)
    const lengths = segments.map((segment) => segment.data.length)
    perf(`Image ${firmware.length} bytes; writing ${lengths.reduce((sum, length) => sum + length, 0)} bytes in ${segments.length} segment(s); preserve settings=${keepSettings}.`)
    let progressSegment = -1
    let progressBucket = -1
    let transferStarted = performance.now()
    await loader.writeFlash({
      fileArray: segments, flashMode: 'keep', flashFreq: 'keep', flashSize: 'keep', eraseAll: false, compress: true,
      calculateMD5Hash: (image) => bytesToHex(md5(image)),
      reportProgress: (fileIndex, written, total) => {
        if (progressSegment !== fileIndex) { progressSegment = fileIndex; progressBucket = -1; transferStarted = performance.now() }
        setOperation('writing')
        const bucket = Math.floor(written / total * 10)
        if (bucket > progressBucket) {
          progressBucket = bucket
          const seconds = (performance.now() - transferStarted) / 1000
          perf(`Segment ${fileIndex + 1}: ${written}/${total} compressed bytes; ${seconds.toFixed(3)} s; ${seconds > 0 ? (written / 1024 / seconds).toFixed(1) : '0'} KiB/s observed.`)
        }
        callbacks.onProgress(writeProgress(lengths, fileIndex, written, total))
        // All compressed bytes have been sent, but writeFlash still awaits
        // the device's finish acknowledgement before starting its MD5 check.
        if (total > 0 && written >= total) setOperation('finishing')
      },
    })
    callbacks.onProgress(100)
    callbacks.onWrittenAndVerified()
    if (diagnostics) nextPhase('restart/disconnect')
    callbacks.onRestarting('Firmware installed. Restarting the miner automatically…')
    await restartMiner(transport)
    try { await transport.disconnect() } catch { /* Reset may close the port first. */ }
    callbacks.onDisconnected()
    // Give the application firmware time to leave the ROM bootloader and begin
    // normal startup before telling the visitor the restart sequence is done.
    await sleep(1500)
    callbacks.onRestartComplete()
    if (diagnostics) {
      finishPhase()
      perf(`Complete. Total USB flash workflow: ${((performance.now() - started) / 1000).toFixed(3)} s. Stage totals: ${[...timings].map(([name, ms]) => `${name}=${(ms / 1000).toFixed(3)} s`).join(', ')}.`)
    }
    return chip
  } catch (error) {
    if (callbacks.speedTrial) fastTrialDisabled.add(port)
    if (diagnostics) {
      finishPhase()
      perf('Run failed. No automatic rewrite attempted; next attempt uses the standard rate. See preceding error and stage timing.')
    }
    throw error
  } finally {
    try { await transport.disconnect() } catch { /* Reset may close the port first. */ }
  }
}
