/*
 * Production-safe Mujina module.
 * Unsupported device operations fail closed in this build.
 */

import type { K230FlashCallbacks, K230Mode, KdImage } from './mujinaTypes'

function unavailable(): never {
  throw new Error('Mujina is not available in this production build.')
}

export async function parseKdImage(_file: File): Promise<KdImage> {
  return unavailable()
}

export async function verifyKdImage(_image: KdImage, _onProgress: (progress: number) => void): Promise<void> {
  unavailable()
}

export async function requestK230Device(): Promise<USBDevice> {
  return unavailable()
}

export async function inspectK230Device(_device: USBDevice): Promise<K230Mode> {
  return unavailable()
}

export async function flashNano3s(_device: USBDevice, _image: KdImage, _callbacks: K230FlashCallbacks): Promise<void> {
  unavailable()
}
