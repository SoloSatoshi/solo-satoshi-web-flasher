/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import type { FirmwareImage, FirmwareManifest, FirmwareSource } from '../types'
import { TOUCH_BOARD, TOUCH_MODEL } from '../deviceCatalog'

const SHA256_PATTERN = /^[a-f0-9]{64}$/
const MIN_MINER_FACTORY_SIZE = 8 * 1024 * 1024
const MIN_NERDNOS_FACTORY_SIZE = 2 * 1024 * 1024
const MIN_TOUCH_FACTORY_SIZE = 1 * 1024 * 1024
const MAX_FACTORY_SIZE = 20 * 1024 * 1024
// Bound network stalls before any USB writes; slow firmware links get three minutes.
const MANIFEST_TIMEOUT_MS = 15_000
const FIRMWARE_TIMEOUT_MS = 180_000
const APPROVED_REPOSITORIES = {
  bitaxe: ['bitaxeorg/ESP-Miner', 'bitaxeorg/BAP-GT-TOUCH'],
  bitforge: ['WantClue/forge-os'],
  nerdaxe: ['shufps/ESP-Miner-NerdQAxePlus'],
  nerdnos: ['WantClue/NerdMiner_v2'],
} as const
export const TOUCH_REPOSITORY = 'bitaxeorg/BAP-GT-TOUCH'
const FIRMWARE_ORIGIN = 'https://firmware.solosatoshi.com'
const DEVELOPMENT_ORIGIN = import.meta.env.DEV ? windowOrigin() : ''
function windowOrigin() { return typeof window === 'undefined' ? '' : window.location.origin }
export const MAX_MANIFEST_BYTES = 1_048_576
const MAX_MANIFEST_ENTRIES = 4096
const MAX_MANIFEST_FIELD_LENGTH = 2048
const MAX_MEMORY_CACHE_ENTRIES = 2
export const MAX_CUSTOM_FIRMWARE_SIZE = 32 * 1024 * 1024
const ESP_IMAGE_MAGIC = 0xe9
const ESP_PARTITION_TABLE_OFFSET = 0x8000
const ESP_PARTITION_ENTRY_MAGIC = [0xaa, 0x50] as const

interface FirmwareCacheEntry {
  progress: number
  listeners: Set<(progress: number) => void>
  promise: Promise<Uint8Array>
  diagnostics: string[]
}

export function espSpeedTrial(image: FirmwareImage, origin: string): boolean {
  return (origin === 'https://flash.solosatoshi.com' || (DEVELOPMENT_ORIGIN !== '' && origin === DEVELOPMENT_ORIGIN)) && Object.hasOwn(APPROVED_REPOSITORIES, image.family)
}

const ESP_CACHE_NAME = 'solo-satoshi-esp-firmware-v1'
const ESP_CACHE_ENTRIES = 2

async function readEspCache(image: FirmwareImage, log: (line: string) => void): Promise<Uint8Array | null> {
  if (typeof caches === 'undefined') { log('[PERF] Persistent cache unavailable.'); return null }
  try {
    const start = performance.now()
    const cache = await caches.open(ESP_CACHE_NAME)
    const key = new URL(`/__verified-firmware/${image.sha256}`, window.location.origin).href
    const response = await cache.match(key)
    if (!response) { log('[PERF] Persistent cache MISS.'); return null }
    const bytes = new Uint8Array(await response.arrayBuffer())
    if (bytes.length !== image.size || await sha256(bytes) !== image.sha256) {
      await cache.delete(key)
      log('[PERF] Cached firmware rejected by size/SHA-256 check; downloading again.')
      return null
    }
    log(`[PERF] Persistent cache HIT; ${bytes.length} bytes, SHA-256 verified in ${((performance.now() - start) / 1000).toFixed(3)} s.`)
    return bytes
  } catch { log('[PERF] Persistent cache read failed; using normal download.'); return null }
}

async function saveEspCache(image: FirmwareImage, bytes: Uint8Array, log: (line: string) => void) {
  if (typeof caches === 'undefined') return
  try {
    const cache = await caches.open(ESP_CACHE_NAME)
    const key = new URL(`/__verified-firmware/${image.sha256}`, window.location.origin).href
    await cache.put(key, new Response(new Uint8Array(bytes), { headers: { 'Content-Type': 'application/octet-stream' } }))
    const keys = await cache.keys()
    for (const old of keys.slice(0, Math.max(0, keys.length - ESP_CACHE_ENTRIES))) await cache.delete(old)
    log('[PERF] Verified firmware cached locally; maximum 2 images. No miner settings or credentials stored.')
  } catch { log('[PERF] Persistent cache save failed; verified firmware remains usable.') }
}

const firmwareCache = new Map<string, FirmwareCacheEntry>()

export const NVS_START = 0x9000
export const NVS_END = 0xf000

function isImage(value: unknown): value is FirmwareImage {
  if (!value || typeof value !== 'object') return false
  const image = value as Partial<FirmwareImage>
  const isTouchImage = image.sourceRepository === TOUCH_REPOSITORY
  const expectedTouchAsset = image.releaseTag === 'v1.0' ? 'esp-display.bin' : `esp-display-${image.releaseTag}.bin`
  return (
    Object.hasOwn(APPROVED_REPOSITORIES, image.family ?? '') &&
    (image.channel === 'stable' || image.channel === 'beta') &&
    typeof image.id === 'string' && typeof image.model === 'string' &&
    typeof image.board === 'string' && typeof image.releaseTag === 'string' &&
    typeof image.assetName === 'string' && typeof image.size === 'number' && Number.isSafeInteger(image.size) &&
    image.size >= (image.sourceRepository === TOUCH_REPOSITORY ? MIN_TOUCH_FACTORY_SIZE : image.family === 'nerdnos' ? MIN_NERDNOS_FACTORY_SIZE : MIN_MINER_FACTORY_SIZE) && image.size <= MAX_FACTORY_SIZE &&
    typeof image.sha256 === 'string' && SHA256_PATTERN.test(image.sha256) &&
    typeof image.downloadUrl === 'string' && isApprovedFirmwareUrl(image.downloadUrl) &&
    typeof image.sourceRepository === 'string' && APPROVED_REPOSITORIES[image.family!]?.some((repository) => repository === image.sourceRepository) &&
    (!isTouchImage || (image.family === 'bitaxe' && image.model === TOUCH_MODEL && image.board === TOUCH_BOARD && image.assetName === expectedTouchAsset)) &&
    typeof image.releaseUrl === 'string' && isApprovedSourcePage(image.sourceRepository, image.releaseUrl)
  )
}

function isApprovedFirmwareUrl(value: string): boolean {
  try {
    const url = new URL(value)
    if (url.username || url.password) return false
    const origin = url.origin
    if (origin === FIRMWARE_ORIGIN) return true
    return DEVELOPMENT_ORIGIN !== '' && origin === DEVELOPMENT_ORIGIN
  } catch {
    return false
  }
}

function isSource(value: unknown): value is FirmwareSource {
  if (!value || typeof value !== 'object') return false
  const source = value as Partial<FirmwareSource>
  return (
    Object.hasOwn(APPROVED_REPOSITORIES, source.family ?? '') &&
    (source.channel === 'stable' || source.channel === 'beta') &&
    typeof source.repository === 'string' && APPROVED_REPOSITORIES[source.family!]?.some((repository) => repository === source.repository) &&
    typeof source.releaseTag === 'string' && typeof source.publishedAt === 'string' &&
    typeof source.releaseUrl === 'string' && isApprovedSourcePage(source.repository, source.releaseUrl) &&
    typeof source.sourceArchiveUrl === 'string' && isApprovedFirmwareUrl(source.sourceArchiveUrl)
  )
}

function isApprovedSourcePage(repository: string | undefined, value: string): boolean {
  if (!repository) return false
  const prefix = `https://github.com/${repository}/`
  return value.startsWith(`${prefix}releases/`) ||
    (repository === 'WantClue/NerdMiner_v2' && /^https:\/\/github\.com\/WantClue\/NerdMiner_v2\/commit\/[a-f0-9]{40}$/.test(value))
}

export function parseManifest(value: unknown): FirmwareManifest {
  if (!value || typeof value !== 'object') throw new Error('Firmware manifest is invalid.')
  const input = value as Record<string, unknown>
  for (const name of ['sources', 'firmware']) {
    const entries = input[name]
    if (!Array.isArray(entries) || entries.length > MAX_MANIFEST_ENTRIES || entries.some((entry) =>
      !entry || typeof entry !== 'object' || Array.isArray(entry) || Object.entries(entry).some(([key, field]) =>
        key.length > 128 || (typeof field === 'string' ? field.length > MAX_MANIFEST_FIELD_LENGTH : typeof field !== 'number')))) {
      throw new Error('Firmware manifest has invalid or excessive fields.')
    }
  }
  const normalized = input.schemaVersion === 1 ? {
    ...input,
    schemaVersion: 2,
    sources: Array.isArray(input.sources) ? input.sources.map((source) => ({ ...(source as object), channel: 'stable' })) : input.sources,
    firmware: Array.isArray(input.firmware) ? input.firmware.map((image) => ({ ...(image as object), channel: 'stable' })) : input.firmware,
  } : input
  const manifest = normalized as Partial<FirmwareManifest>
  if (manifest.schemaVersion !== 2 || typeof manifest.generatedAt !== 'string' ||
    !Array.isArray(manifest.sources) || !manifest.sources.every(isSource) || !Array.isArray(manifest.firmware) ||
    manifest.firmware.length === 0 || !manifest.firmware.every(isImage)) {
    throw new Error('Firmware manifest is invalid or empty.')
  }
  return manifest as FirmwareManifest
}

export async function readManifestResponse(response: Response): Promise<FirmwareManifest> {
  if (response.redirected) throw new Error('Manifest redirects are not allowed.')
  if (!response.body) throw new Error('Firmware manifest size is invalid.')
  if (Number(response.headers.get('content-length')) > MAX_MANIFEST_BYTES) {
    await response.body.cancel()
    throw new Error('Firmware manifest size is invalid.')
  }
  const reader = response.body.getReader()
  const bytes = new Uint8Array(MAX_MANIFEST_BYTES)
  let size = 0
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      size += value.length
      if (size > MAX_MANIFEST_BYTES) { await reader.cancel(); throw new Error('Firmware manifest exceeds size limit.') }
      bytes.set(value, size - value.length)
    }
  } finally { reader.releaseLock() }
  return parseManifest(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(0, size))))
}

export async function loadManifest(): Promise<{ manifest: FirmwareManifest; fallback: boolean }> {
  const configuredUrl = import.meta.env.VITE_FIRMWARE_MANIFEST_URL as string | undefined
  const remoteUrl = configuredUrl || 'https://firmware.solosatoshi.com/firmware-index.json'
  try {
    // The R2 object has a five-minute max-age. Reuse that browser and edge
    // cache instead of creating a unique cache key for every page load.
    const response = await fetch(remoteUrl, { redirect: 'error', signal: AbortSignal.timeout(MANIFEST_TIMEOUT_MS) })
    if (!response.ok) throw new Error(`Firmware service returned ${response.status}.`)
    return { manifest: await readManifestResponse(response), fallback: false }
  } catch (remoteError) {
    const response = await fetch(`${import.meta.env.BASE_URL}firmware-index.json`, { redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(MANIFEST_TIMEOUT_MS) })
    if (!response.ok) throw remoteError
    return { manifest: await readManifestResponse(response), fallback: true }
  }
}

async function fetchAndVerify(image: FirmwareImage, onProgress: (progress: number) => void, persistentCache = false, log: (line: string) => void = () => undefined): Promise<Uint8Array> {
  if (persistentCache) {
    const cached = await readEspCache(image, log)
    if (cached) { onProgress(100); return cached }
  }
  const downloadStarted = performance.now()
  // Firmware URLs contain the release and filename, and the release workflow
  // serves them as immutable. The SHA-256 check below still authenticates bytes
  // returned from either the network or the browser's HTTP cache.
  if (!isApprovedFirmwareUrl(image.downloadUrl)) throw new Error('Firmware download origin is not approved.')
  const response = await fetch(image.downloadUrl, { redirect: 'error', cache: 'force-cache', signal: AbortSignal.timeout(FIRMWARE_TIMEOUT_MS) })
  if (response.redirected) throw new Error('Firmware redirects are not allowed.')
  if (!response.ok) throw new Error(`Firmware download failed (${response.status}).`)
  const contentLength = Number(response.headers.get('content-length'))
  let bytes: Uint8Array
  if (response.body) {
    const reader = response.body.getReader()
    const chunks: Uint8Array[] = []
    let received = 0
    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        received += value.length
        if (received > image.size || received > MAX_FACTORY_SIZE) {
          await reader.cancel()
          throw new Error('Firmware size check failed. Download exceeds the verified image size.')
        }
        chunks.push(value)
        onProgress(Math.min(100, Math.round((received / (contentLength || image.size)) * 100)))
      }
    } finally {
      reader.releaseLock()
    }
    bytes = new Uint8Array(received)
    let offset = 0
    for (const chunk of chunks) {
      bytes.set(chunk, offset)
      offset += chunk.length
    }
  } else {
    bytes = new Uint8Array(await response.arrayBuffer())
  }
  if (bytes.length !== image.size) throw new Error(`Firmware size check failed. Expected ${image.size} bytes, received ${bytes.length}.`)
  if (persistentCache) log(`[PERF] Download/read: ${((performance.now() - downloadStarted) / 1000).toFixed(3)} s, ${bytes.length} bytes (may include browser HTTP cache).`)
  const hashStarted = performance.now()
  const digest = await sha256(bytes)
  if (digest !== image.sha256) throw new Error('Firmware security check failed. The downloaded file does not match the release manifest.')
  if (persistentCache) {
    log(`[PERF] SHA-256 verified: ${((performance.now() - hashStarted) / 1000).toFixed(3)} s.`)
    await saveEspCache(image, bytes, log)
  }
  onProgress(100)
  return bytes
}

function getFirmwareEntry(image: FirmwareImage, persistentCache = false): FirmwareCacheEntry {
  const cached = firmwareCache.get(image.sha256)
  if (cached) return cached

  while (firmwareCache.size >= MAX_MEMORY_CACHE_ENTRIES) {
    const oldestKey = firmwareCache.keys().next().value
    if (oldestKey === undefined) break
    firmwareCache.delete(oldestKey)
  }

  const entry: FirmwareCacheEntry = {
    progress: 0,
    listeners: new Set(),
    promise: Promise.resolve(new Uint8Array()),
    diagnostics: [],
  }
  entry.promise = fetchAndVerify(image, (progress) => {
    entry.progress = progress
    for (const listener of entry.listeners) listener(progress)
  }, persistentCache, (line) => entry.diagnostics.push(line)).catch((error) => {
    // A failed or interrupted response must never remain in the verified cache.
    firmwareCache.delete(image.sha256)
    throw error
  })
  firmwareCache.set(image.sha256, entry)
  return entry
}

export async function downloadAndVerify(image: FirmwareImage, onProgress: (progress: number) => void, options: { persistentCache?: boolean; onLog?: (line: string) => void } = {}): Promise<Uint8Array> {
  const cachedInMemory = firmwareCache.has(image.sha256)
  const entry = getFirmwareEntry(image, options.persistentCache)
  let diagnosticsFlushed = false
  entry.listeners.add(onProgress)
  onProgress(entry.progress)
  try {
    const bytes = await entry.promise
    for (const line of entry.diagnostics) options.onLog?.(line)
    diagnosticsFlushed = true
    // Recheck even when persistent storage is unavailable or disabled.
    const started = performance.now()
    if (bytes.length !== image.size || await sha256(bytes) !== image.sha256) {
      firmwareCache.delete(image.sha256)
      throw new Error('Firmware security check failed before flashing.')
    }
    if (options.persistentCache) {
      if (cachedInMemory) options.onLog?.('[PERF] Reusing selected firmware prefetch/in-memory cache.')
      options.onLog?.(`[PERF] Pre-flash SHA-256 recheck: ${((performance.now() - started) / 1000).toFixed(3)} s.`)
    }
    return bytes
  } finally {
    if (!diagnosticsFlushed) for (const line of entry.diagnostics) options.onLog?.(line)
    entry.listeners.delete(onProgress)
  }
}

export async function prefetchFirmware(image: FirmwareImage, persistentCache = false): Promise<void> {
  await getFirmwareEntry(image, persistentCache).promise
}

export async function sha256(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(bytes).buffer)
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('')
}

export function createFlashSegments(firmware: Uint8Array, keepSettings: boolean) {
  if (!keepSettings) return [{ data: firmware, address: 0 }]
  const invalid = () => new Error('Firmware partition table is invalid; settings cannot be preserved safely.')
  if (firmware.length <= 0x9000 || firmware[0] !== ESP_IMAGE_MAGIC) throw invalid()
  const view = new DataView(firmware.buffer, firmware.byteOffset, firmware.byteLength)
  const partitions: { type: number; subtype: number; start: number; end: number }[] = []
  let terminated = false
  for (let offset = 0x8000; offset + 32 <= 0x9000; offset += 32) {
    const magic = view.getUint16(offset, true)
    if (magic === 0xffff || magic === 0xebeb) { terminated = true; break }
    if (magic !== 0x50aa) throw invalid()
    const start = view.getUint32(offset + 4, true)
    const size = view.getUint32(offset + 8, true)
    const end = start + size
    if (start < 0x9000 || start % 0x1000 || !size || size % 0x1000 || end > MAX_CUSTOM_FIRMWARE_SIZE) throw invalid()
    if (partitions.some((p) => start < p.end && end > p.start)) throw invalid()
    partitions.push({ type: firmware[offset + 2], subtype: firmware[offset + 3], start, end })
  }
  const nvs = partitions.filter((p) => p.type === 1 && p.subtype === 2)
  if (!terminated || nvs.length !== 1 || nvs[0].end >= firmware.length) throw invalid()
  const { start, end } = nvs[0]
  return [
    { data: firmware.slice(0, start), address: 0 },
    { data: firmware.slice(end), address: end },
  ]
}

export function validateCustomFirmware(firmware: Uint8Array) {
  if (firmware.length === 0) throw new Error('The selected firmware file is empty.')
  if (firmware.length > MAX_CUSTOM_FIRMWARE_SIZE) throw new Error('The selected firmware file is larger than 32 MB.')
  if (firmware[0] !== ESP_IMAGE_MAGIC) throw new Error('The selected file is not a bootable ESP binary image for address 0x0.')
  if (firmware.length <= ESP_PARTITION_TABLE_OFFSET + 1 || firmware[ESP_PARTITION_TABLE_OFFSET] !== ESP_PARTITION_ENTRY_MAGIC[0] || firmware[ESP_PARTITION_TABLE_OFFSET + 1] !== ESP_PARTITION_ENTRY_MAGIC[1]) {
    throw new Error('The selected file is not a merged ESP32-S3 factory image with a partition table at 0x8000.')
  }
}
