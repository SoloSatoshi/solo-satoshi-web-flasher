/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 */

type MatomoCommand = [string, ...unknown[]]

declare global {
  interface Window {
    _paq?: MatomoCommand[]
  }
}

const productionHostname = 'flash.solosatoshi.com'
const trackerBaseUrl = 'https://solosatoshi.matomo.cloud/'
const trackerScriptUrl = 'https://cdn.matomo.cloud/solosatoshi.matomo.cloud/matomo.js'
const siteId = '5'

export type AnalyticsEvent =
  | { category: 'Miner family'; action: 'Selected'; name: 'bitaxe' | 'bitforge' | 'nerdaxe' | 'nerdnos' }
  | { category: 'Flashing'; action: 'Started' | 'Completed' | 'Failed'; name: 'verified' | 'custom' }
  | { category: 'Support'; action: 'Issue report submitted' }

export function initializeAnalytics() {
  if (window.location.hostname !== productionHostname || document.querySelector(`script[src="${trackerScriptUrl}"]`)) return

  const queue = window._paq = window._paq ?? []
  queue.push(['disableCookies'])
  queue.push(['setDoNotTrack', true])
  queue.push(['setTrackerUrl', `${trackerBaseUrl}matomo.php`])
  queue.push(['setSiteId', siteId])
  queue.push(['trackPageView'])

  const script = document.createElement('script')
  script.async = true
  script.src = trackerScriptUrl
  document.head.append(script)
}

export function trackAnalyticsEvent(event: AnalyticsEvent) {
  if (window.location.hostname !== productionHostname) return
  const command: MatomoCommand = ['trackEvent', event.category, event.action]
  if ('name' in event) command.push(event.name)
  window._paq?.push(command)
}
