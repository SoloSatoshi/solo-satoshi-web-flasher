/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { CheckCircle2, ChevronRight, CircleAlert, Cpu, ExternalLink, FileUp, GitFork, RefreshCw, ShieldCheck, Usb } from 'lucide-react'
import { siDiscord, siFacebook, siInstagram, siReddit, siTiktok, siX, siYoutube } from 'simple-icons'
import './App.css'
import LanguageSelector from './components/LanguageSelector'
import { familyLabels } from './deviceCatalog'
import { getChannelSources, getCompatibleReleaseSources, getLatestModelImages } from './lib/compatibility'
import { isMobileFlashingDevice, supportsWebSerial } from './lib/browserCompatibility'
import { downloadAndVerify, loadManifest, MAX_CUSTOM_FIRMWARE_SIZE, prefetchFirmware, sha256, validateCustomFirmware } from './lib/firmware'
import { BootloaderConnectionError, flashFirmware, requestMinerPort } from './lib/flasher'
import { flashNano3s, inspectK230Device, K230ReconnectionError, parseKdImage, requestK230Device, supportsWebUsb, verifyKdImage } from './lib/k230'
import type { K230FlashStage, K230Mode, KdImage } from './lib/k230'
import type { FirmwareFamily, FirmwareImage, FirmwareManifest, FlashStatus, ReleaseChannel } from './types'

type FlasherTool = 'verified' | 'mujina' | 'custom'
type FlashSource = 'official' | 'mujina' | 'custom'
type LocalFirmware = { name: string; bytes: Uint8Array; digest: string }
type MujinaTarget = 'nano3s' | 'gamma'

const socialLinks = [
  { label: 'YouTube', href: 'https://www.youtube.com/@solo.satoshi', icon: siYoutube },
  { label: 'X', href: 'https://twitter.com/SoloSatoshi', icon: siX },
  { label: 'TikTok', href: 'https://tiktok.com/@solo.satoshi', icon: siTiktok },
  { label: 'Facebook', href: 'https://www.facebook.com/people/Solo-Satoshi/61575323724787/', icon: siFacebook },
  { label: 'Instagram', href: 'https://www.instagram.com/solosatoshi_/', icon: siInstagram },
  { label: 'Reddit', href: 'https://www.reddit.com/r/SoloSatoshi/', icon: siReddit },
  { label: 'Discord', href: 'https://discord.gg/solosatoshi', icon: siDiscord },
]

function HeroBolt() {
  return (
    <div className="hero-bolt" aria-hidden="true">
      <div className="bolt-halo" />
      <svg className="bolt-orbits" viewBox="0 0 360 380" role="presentation">
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-one" cx="180" cy="190" rx="165" ry="120" />
          <circle className="orbit-ball" r="6">
            <animateMotion dur="2.4s" repeatCount="indefinite" path="M 345 190 A 165 120 0 1 1 15 190 A 165 120 0 1 1 345 190" />
          </circle>
        </g>
        <g transform="rotate(-18 180 190)">
          <ellipse className="orbit-line orbit-line-two" cx="180" cy="190" rx="130" ry="175" />
          <circle className="orbit-ball orbit-ball-secondary" r="5">
            <animateMotion begin="-1.2s" dur="2.4s" repeatCount="indefinite" path="M 310 190 A 130 175 0 1 1 50 190 A 130 175 0 1 1 310 190" />
          </circle>
        </g>
      </svg>
      <svg className="bolt-mark" viewBox="0 0 260 360" role="presentation">
        <defs>
          <linearGradient id="bolt-gradient" x1="35" y1="30" x2="230" y2="330" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#f7931a" />
            <stop offset="0.3" stopColor="#eb4b55" />
            <stop offset="0.62" stopColor="#c71e82" />
            <stop offset="1" stopColor="#54205a" />
          </linearGradient>
          <linearGradient id="bolt-highlight" x1="65" y1="40" x2="180" y2="300" gradientUnits="userSpaceOnUse">
            <stop stopColor="#ffe8f3" stopOpacity="0.9" />
            <stop offset="0.55" stopColor="#f8a8d3" stopOpacity="0.5" />
            <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="bolt-shadow" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-body" d="M151 16 47 197h74l-19 147 111-199h-76z" />
        <path className="bolt-highlight" d="M151 16 72 181h62l-21 120 78-140h-72z" />
      </svg>
    </div>
  )
}

function App() {
  const { t, i18n } = useTranslation()
  const copy = (key: string) => t(`site.${key}`)
  const formatDate = (date: string) => new Intl.DateTimeFormat(i18n.resolvedLanguage, { dateStyle: 'medium' }).format(new Date(date))
  const initialStatus: FlashStatus = { stage: 'idle', message: copy('ready'), progress: 0 }
  const [manifest, setManifest] = useState<FirmwareManifest | null>(null)
  const [manifestError, setManifestError] = useState('')
  const [usingFallback, setUsingFallback] = useState(false)
  const [family, setFamily] = useState<FirmwareFamily>('bitaxe')
  const [familyConfirmed, setFamilyConfirmed] = useState(false)
  const [channel, setChannel] = useState<ReleaseChannel>('stable')
  const [channelConfirmed, setChannelConfirmed] = useState(false)
  const [minerPort, setMinerPort] = useState<SerialPort | null>(null)
  const [selectedModel, setSelectedModel] = useState('')
  const [selectedReleaseTag, setSelectedReleaseTag] = useState('')
  const [selectedBoard, setSelectedBoard] = useState('')
  const [keepSettings, setKeepSettings] = useState(false)
  const [settingsAdvanced, setSettingsAdvanced] = useState(false)
  const [status, setStatus] = useState<FlashStatus>(initialStatus)
  const [logs, setLogs] = useState<string[]>([])
  const [activeTool, setActiveTool] = useState<FlasherTool>('verified')
  const [activeFlashSource, setActiveFlashSource] = useState<FlashSource | null>(null)
  const [customFirmware, setCustomFirmware] = useState<LocalFirmware | null>(null)
  const [customFirmwareError, setCustomFirmwareError] = useState('')
  const [mujinaTarget, setMujinaTarget] = useState<MujinaTarget>('nano3s')
  const [mujinaDevice, setMujinaDevice] = useState<USBDevice | null>(null)
  const [mujinaDeviceMode, setMujinaDeviceMode] = useState<K230Mode | null>(null)
  const [mujinaFirmware, setMujinaFirmware] = useState<KdImage | null>(null)
  const [mujinaFirmwareError, setMujinaFirmwareError] = useState('')
  const [mujinaHardwareConfirmed, setMujinaHardwareConfirmed] = useState(false)
  const [bootloaderRecovery, setBootloaderRecovery] = useState(false)

  useEffect(() => {
    loadManifest().then(({ manifest: value, fallback }) => {
      setManifest(value)
      setUsingFallback(fallback)
    }).catch((error: unknown) => setManifestError(error instanceof Error ? error.message : copy('manifestLoadFailed')))
  // The manifest is language-independent and should load only once.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    setStatus((current) => current.stage === 'idle' ? initialStatus : current)
  // Refresh idle copy when the visitor changes language.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.resolvedLanguage])

  const channelSources = useMemo(() => getChannelSources(manifest, family, channel), [channel, family, manifest])
  const modelImages = useMemo(() => getLatestModelImages(manifest, family, channel, channelSources), [channel, channelSources, family, manifest])
  const modelOptions = useMemo(() => modelImages.filter((image, index, images) => images.findIndex((candidate) => candidate.model === image.model) === index), [modelImages])
  const boardOptions = useMemo(() => modelImages.filter((image) => image.model === selectedModel), [modelImages, selectedModel])
  const activeBoard = modelImages.some((image) => image.board === selectedBoard) ? selectedBoard : undefined
  const releaseSources = useMemo(() => getCompatibleReleaseSources(manifest, family, channel, activeBoard, channelSources), [activeBoard, channel, channelSources, family, manifest])
  const selectedSource = channel === 'beta' ? releaseSources[0] : releaseSources.find((item) => item.releaseTag === selectedReleaseTag)
  const selected = manifest?.firmware.find((image) =>
    image.family === family && image.channel === channel && image.board === activeBoard && image.releaseTag === selectedSource?.releaseTag
  )
  const betaAvailable = manifest?.sources.some((item) => item.family === family && item.channel === 'beta') ?? false
  const isBusy = ['downloading', 'connecting', 'flashing'].includes(status.stage)
  const serialAvailable = supportsWebSerial()
  const mobileDevice = isMobileFlashingDevice(navigator.userAgent, navigator.platform, navigator.maxTouchPoints)

  useEffect(() => {
    if (!selected) return
    // Download and verify the exact selected image while the visitor reviews
    // the final settings. startFlash shares this in-flight or completed work.
    void prefetchFirmware(selected).catch(() => undefined)
  }, [selected])

  async function connectMiner(source: FlashSource) {
    if (minerPort) {
      setMinerPort(null)
      setFamilyConfirmed(false)
      setChannelConfirmed(false)
      setSelectedModel('')
      setSelectedBoard('')
      setSelectedReleaseTag('')
      setKeepSettings(false)
      setSettingsAdvanced(false)
      setCustomFirmware(null)
      setCustomFirmwareError('')
      setBootloaderRecovery(false)
      setActiveFlashSource(null)
      setStatus(initialStatus)
      return
    }
    try {
      setActiveFlashSource(source)
      setStatus({ stage: 'connecting', message: copy('chooseUsb'), progress: 0 })
      setMinerPort(await requestMinerPort())
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotFoundError') {
        setStatus(initialStatus)
        return
      }
      if (error instanceof Error) setLogs([error.message])
      setStatus({ stage: 'error', message: copy('usbFailed'), progress: 0 })
    }
  }

  function selectTool(tool: FlasherTool) {
    if (isBusy) return
    setActiveTool(tool)
    setActiveFlashSource(null)
    setLogs([])
    setBootloaderRecovery(false)
    setStatus(initialStatus)
  }

  async function startFlash(image: FirmwareImage) {
    if (!minerPort) return
    setActiveFlashSource('official')
    setLogs([])
    setBootloaderRecovery(false)
    try {
      setStatus({ stage: 'downloading', message: copy('downloading'), progress: 0 })
      const firmware = await downloadAndVerify(image, (progress) => setStatus({ stage: 'downloading', message: copy('downloading'), progress }))
      await flashFirmware(minerPort, firmware, keepSettings, {
        onConnecting: () => setStatus({ stage: 'connecting', message: copy('connectingDevice'), progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: copy('installing'), progress }),
        onRestarting: () => setStatus({ stage: 'flashing', message: copy('restartingDevice'), progress: 100 }),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: copy('flashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      const needsBootloader = error instanceof BootloaderConnectionError
      setBootloaderRecovery(needsBootloader)
      setStatus({ stage: 'error', message: copy(needsBootloader ? 'bootloaderFailed' : 'flashFailed'), progress: 0 })
    }
  }

  async function chooseCustomFirmware(file?: File) {
    setCustomFirmware(null)
    setCustomFirmwareError('')
    setActiveFlashSource(null)
    setBootloaderRecovery(false)
    setStatus(initialStatus)
    if (!file) return
    try {
      if (!file.name.toLowerCase().endsWith('.bin')) throw new Error(copy('customFileTypeError'))
      const bytes = new Uint8Array(await file.arrayBuffer())
      if (bytes.length === 0) throw new Error(copy('customEmptyError'))
      if (bytes.length > MAX_CUSTOM_FIRMWARE_SIZE) throw new Error(copy('customTooLargeError'))
      try {
        validateCustomFirmware(bytes)
      } catch {
        throw new Error(copy('customHeaderError'))
      }
      setCustomFirmware({ name: file.name, bytes, digest: await sha256(bytes) })
    } catch (error) {
      setCustomFirmwareError(error instanceof Error ? error.message : copy('customInvalid'))
    }
  }

  async function startCustomFlash() {
    if (!minerPort || !customFirmware) return
    setActiveFlashSource('custom')
    setLogs([])
    setBootloaderRecovery(false)
    try {
      await flashFirmware(minerPort, customFirmware.bytes, false, {
        expectedChip: 'ESP32-S3',
        onConnecting: () => setStatus({ stage: 'connecting', message: copy('connectingDevice'), progress: 0 }),
        onProgress: (progress) => setStatus({ stage: 'flashing', message: copy('installingCustom'), progress }),
        onRestarting: () => setStatus({ stage: 'flashing', message: copy('restartingDevice'), progress: 100 }),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setStatus({ stage: 'complete', message: copy('flashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      const needsBootloader = error instanceof BootloaderConnectionError
      setBootloaderRecovery(needsBootloader)
      setStatus({ stage: 'error', message: copy(needsBootloader ? 'bootloaderFailed' : 'flashFailed'), progress: 0 })
    }
  }

  async function chooseMujinaFirmware(file?: File) {
    setMujinaFirmware(null)
    setMujinaFirmwareError('')
    setActiveFlashSource(null)
    setBootloaderRecovery(false)
    setStatus(initialStatus)
    if (!file) return
    try {
      setActiveFlashSource('mujina')
      setStatus({ stage: 'downloading', message: copy('mujinaValidating'), progress: 0 })
      const image = await parseKdImage(file)
      if (!image.chipInfo.toLowerCase().includes('k230') || !image.boardInfo.toLowerCase().includes('nano3')) {
        throw new Error('The KDIMG metadata does not identify an Avalon Nano 3S K230 image.')
      }
      await verifyKdImage(image, (progress) => setStatus({ stage: 'downloading', message: copy('mujinaValidating'), progress }))
      setMujinaFirmware(image)
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof Error) setLogs([error.message])
      setMujinaFirmwareError(copy('mujinaInvalidImage'))
      setStatus(initialStatus)
    }
  }

  async function connectMujinaDevice() {
    if (mujinaDevice) {
      setMujinaDevice(null)
      setMujinaDeviceMode(null)
      setMujinaFirmware(null)
      setMujinaFirmwareError('')
      setMujinaHardwareConfirmed(false)
      setActiveFlashSource(null)
      setStatus(initialStatus)
      return
    }
    try {
      setActiveFlashSource('mujina')
      setStatus({ stage: 'connecting', message: copy('mujinaChooseUsb'), progress: 0 })
      const device = await requestK230Device()
      const mode = await inspectK230Device(device)
      setMujinaDevice(device)
      setMujinaDeviceMode(mode)
      setStatus(initialStatus)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotFoundError') {
        setStatus(initialStatus)
        return
      }
      if (error instanceof Error) setLogs([error.message])
      setStatus({ stage: 'error', message: copy('mujinaConnectFailed'), progress: 0 })
    }
  }

  function mujinaStageMessage(stage: K230FlashStage) {
    const messages: Record<K230FlashStage, string> = {
      loading: 'mujinaLoadingTool',
      'starting-loader': 'mujinaStartingLoader',
      'waiting-loader': 'mujinaWaitingLoader',
      probing: 'mujinaProbingStorage',
      flashing: 'mujinaWritingFirmware',
      restarting: 'restartingDevice',
    }
    return copy(messages[stage])
  }

  async function startMujinaFlash() {
    if (!mujinaDevice || !mujinaHardwareConfirmed || !mujinaFirmware) return
    setActiveFlashSource('mujina')
    setLogs([])
    setBootloaderRecovery(false)
    try {
      await flashNano3s(mujinaDevice, mujinaFirmware, {
        onStage: (stage) => setStatus({ stage: stage === 'loading' ? 'downloading' : 'flashing', message: mujinaStageMessage(stage), progress: stage === 'restarting' ? 100 : 0 }),
        onProgress: (progress) => setStatus((current) => ({ ...current, progress })),
        onLog: (line) => setLogs((current) => [...current.slice(-79), line]),
      })
      setMujinaDevice(null)
      setMujinaDeviceMode(null)
      setStatus({ stage: 'complete', message: copy('mujinaFlashSuccess'), progress: 100 })
    } catch (error) {
      if (error instanceof Error) setLogs((current) => [...current, error.message])
      if (error instanceof K230ReconnectionError) {
        setMujinaDevice(null)
        setMujinaDeviceMode(null)
      }
      setStatus({ stage: 'error', message: copy(error instanceof K230ReconnectionError ? 'mujinaReconnect' : 'mujinaFlashFailed'), progress: 0 })
    }
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}>
          <img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" />
          <span className="brand-name">SOLO SATOSHI</span>
        </a>
        <nav aria-label={copy('pageNavigation')}>
          <a href="https://www.solosatoshi.com/shop" target="_blank" rel="noopener noreferrer">{copy('navShop')}</a>
          {serialAvailable && <a href="#how-it-works">{copy('navGuide')}</a>}
          <a href="https://github.com/SoloSatoshi" target="_blank" rel="noopener noreferrer">{copy('navGithub')} <GitFork size={15} /></a>
          <LanguageSelector />
        </nav>
      </header>

      {!serialAvailable ? (
        <main className="compatibility-gate">
          <section className="compatibility-hero" role="alert" aria-labelledby="compatibility-title">
            <div className="compatibility-copy">
              <div className="compatibility-icon"><CircleAlert size={22} /></div>
              <h1 id="compatibility-title">{t(`errors.${mobileDevice ? 'mobileCompatibility' : 'browserCompatibility'}.title`)}</h1>
              <p>{t(`errors.${mobileDevice ? 'mobileCompatibility' : 'browserCompatibility'}.description`)}</p>
              {!mobileDevice && <div className="browser-links" aria-label={t('errors.browserCompatibility.title')}>
                <a href="https://www.google.com/chrome/" target="_blank" rel="noopener noreferrer">Google Chrome <ExternalLink size={14} /></a>
                <a href="https://www.microsoft.com/edge/download" target="_blank" rel="noopener noreferrer">Microsoft Edge <ExternalLink size={14} /></a>
                <a href="https://brave.com/download/" target="_blank" rel="noopener noreferrer">Brave <ExternalLink size={14} /></a>
              </div>}
            </div>
            <HeroBolt />
          </section>
        </main>
      ) : (
        <>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <h1><span className="headline-line">{copy('heroLineOne')}</span>{' '}<span className="headline-line"><span>{copy('heroWith')} </span><br className="headline-browser-break" aria-hidden="true" /><span className="headline-accent">{copy('heroVerified')}</span></span></h1>
            <p className="hero-summary">{copy('heroSummary')}</p>
          </div>

          <HeroBolt />
        </section>

        <section className="installer" id="installer" aria-labelledby="installer-title">
          <div className="installer-heading">
            <div>
              <p className="section-label">{copy('installerLabel')}</p>
              <h2 id="installer-title">{copy('installerTitle')}</h2>
            </div>
            <div className="verified-mark">
              {activeTool === 'verified' ? <ShieldCheck size={17} /> : activeTool === 'mujina' ? <Cpu size={17} /> : <FileUp size={17} />}
              <span>{activeTool === 'verified' ? copy('verifiedFiles') : activeTool === 'mujina' ? copy('mujinaLocalBadge') : copy('customLocalBadge')}</span>
            </div>
          </div>

          <div className="tool-tabs" role="tablist" aria-label={copy('toolNavigation')}>
            <button type="button" role="tab" aria-selected={activeTool === 'verified'} className={activeTool === 'verified' ? 'active' : ''} disabled={isBusy} onClick={() => selectTool('verified')}><ShieldCheck size={17} />{copy('verifiedTab')}</button>
            <button type="button" role="tab" aria-selected={activeTool === 'mujina'} className={activeTool === 'mujina' ? 'active mujina-tab' : 'mujina-tab'} disabled={isBusy} onClick={() => selectTool('mujina')}><Cpu size={17} />{copy('mujinaTab')}<small>{copy('beta')}</small></button>
            <button type="button" role="tab" aria-selected={activeTool === 'custom'} className={activeTool === 'custom' ? 'active' : ''} disabled={isBusy} onClick={() => selectTool('custom')}><FileUp size={17} />{copy('advancedTab')}</button>
          </div>

          {activeTool === 'verified' && <div className="installer-layout" role="tabpanel">
            <aside className="process-rail" aria-label={copy('processLabel')}>
              <ol>
                <li className={minerPort ? 'complete' : 'active'} aria-current={!minerPort ? 'step' : undefined}><span>1</span><div><strong>{copy('stepsConnect')}</strong><small>{copy('stepsConnectNote')}</small></div></li>
                <li className={!minerPort ? 'locked' : familyConfirmed ? 'complete' : 'active'} aria-current={minerPort && !familyConfirmed ? 'step' : undefined}><span>2</span><div><strong>{copy('stepsFamily')}</strong><small>{copy('stepsFamilyNote')}</small></div></li>
                <li className={!familyConfirmed ? 'locked' : channelConfirmed ? 'complete' : 'active'} aria-current={familyConfirmed && !channelConfirmed ? 'step' : undefined}><span>3</span><div><strong>{copy('stepsChannel')}</strong><small>{copy('stepsChannelNote')}</small></div></li>
                <li className={!channelConfirmed ? 'locked' : selectedModel ? 'complete' : 'active'} aria-current={channelConfirmed && !selectedModel ? 'step' : undefined}><span>4</span><div><strong>{copy('stepsModel')}</strong><small>{copy('stepsModelNote')}</small></div></li>
                <li className={!selectedModel ? 'locked' : activeBoard ? 'complete' : 'active'} aria-current={selectedModel && !activeBoard ? 'step' : undefined}><span>5</span><div><strong>{copy('stepsBoard')}</strong><small>{copy('stepsBoardNote')}</small></div></li>
                <li className={!activeBoard ? 'locked' : selected ? 'complete' : 'active'} aria-current={activeBoard && !selected ? 'step' : undefined}><span>6</span><div><strong>{copy('stepsVersion')}</strong><small>{copy('stepsVersionNote')}</small></div></li>
                <li className={!selected ? 'locked' : settingsAdvanced || status.stage !== 'idle' ? 'complete' : 'active'} aria-current={selected && !settingsAdvanced && status.stage === 'idle' ? 'step' : undefined}><span>7</span><div><strong>{copy('stepsSettings')}</strong><small>{copy('stepsSettingsNote')}</small></div></li>
                <li className={!selected || (!settingsAdvanced && status.stage === 'idle') ? 'locked' : 'active'} aria-current={selected && (settingsAdvanced || status.stage !== 'idle') ? 'step' : undefined}><span>8</span><div><strong>{copy('stepsInstall')}</strong><small>{copy('stepsInstallNote')}</small></div></li>
              </ol>
            </aside>

            <div className="flasher-panel">
              <section className="flow-stage connect-stage" aria-label={copy('connectLabel')}>
                <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={() => void connectMiner('official')}>
                  {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                  {minerPort ? t('hero.disconnect') : t('hero.connect')}
                </button>
                <p className="stage-note">{copy('connectNote')}</p>
              </section>

              <section className={`flow-stage family-stage ${!minerPort ? 'locked' : ''}`} aria-label={copy('familyLabel')} aria-disabled={!minerPort}>
                {manifestError ? (
                  <div className="browser-warning"><CircleAlert size={20} /><div><strong>{copy('firmwareUnavailable')}</strong><span>{copy('manifestLoadFailed')}</span></div></div>
                ) : (
                  <fieldset className="field-group">
                    <legend>{copy('stepsFamily')}</legend>
                    <div className="family-tabs">
                      {(Object.keys(familyLabels) as FirmwareFamily[]).map((key) => (
                        <button type="button" className={`${familyConfirmed && family === key ? 'active' : ''} family-${key}`} aria-pressed={familyConfirmed && family === key} onClick={() => { const hasPrerelease = manifest?.sources.some((item) => item.family === key && item.channel === 'beta') ?? true; setFamily(key); setFamilyConfirmed(true); setChannel('stable'); setChannelConfirmed(!hasPrerelease); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!minerPort || isBusy} key={key}>
                          <img className="family-wordmark" src={`${import.meta.env.BASE_URL}device-logos/${key}-wordmark.webp`} alt={familyLabels[key]} width={key === 'bitaxe' ? 370 : 520} height={key === 'bitaxe' ? 150 : 112} decoding="async" />
                        </button>
                      ))}
                    </div>
                  </fieldset>
                )}
              </section>

              <section className={`flow-stage channel-stage ${!familyConfirmed ? 'locked' : ''}`} aria-label={copy('channelLabel')} aria-disabled={!familyConfirmed}>
                  <fieldset className="field-group">
                    <legend>{copy('stepsChannel')}</legend>
                    <div className="channel-tabs">
                      <button type="button" className={channelConfirmed && channel === 'stable' ? 'active' : ''} aria-pressed={channelConfirmed && channel === 'stable'} onClick={() => { setChannel('stable'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('latestReleases')} <small>{copy('recommended')}</small></button>
                      {betaAvailable ? <button type="button" className={channelConfirmed && channel === 'beta' ? 'active beta' : 'beta'} aria-pressed={channelConfirmed && channel === 'beta'} onClick={() => { setChannel('beta'); setChannelConfirmed(true); setSelectedModel(''); setSelectedReleaseTag(''); setSelectedBoard(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!familyConfirmed || isBusy}>{copy('prereleases')} <small>{copy('betaReleases')}</small></button> : <button type="button" className="unavailable" disabled>{copy('noPrereleases')}</button>}
                    </div>
                  </fieldset>
                  {channel === 'beta' && <div className="beta-warning"><CircleAlert size={20} /><div><strong>{copy('prereleaseTitle')}</strong><span>{copy('prereleaseWarning')}</span></div></div>}
              </section>

              <section className={`flow-stage model-stage ${!channelConfirmed ? 'locked' : ''}`} aria-label={copy('modelLabel')} aria-disabled={!channelConfirmed}>
                    <div className="field-group">
                      <label htmlFor="model">{copy('stepsModel')}</label>
                      <select id="model" value={selectedModel} onChange={(event) => {
                        const model = event.target.value
                        setSelectedModel(model)
                        setSelectedBoard(family === 'nerdaxe' ? modelImages.find((image) => image.model === model)?.board ?? '' : '')
                        setSelectedReleaseTag('')
                        setKeepSettings(false)
                        setSettingsAdvanced(false)
                        setStatus(initialStatus)
                      }} disabled={!manifest || !channelConfirmed || isBusy}>
                        <option value="" disabled>{t('hero.selectDevice')}</option>
                        {modelOptions.map((image) => <option value={image.model} key={image.model}>{image.model}</option>)}
                      </select>
                    </div>
              </section>

              <section className={`flow-stage board-stage ${!selectedModel ? 'locked' : ''}`} aria-label={copy('boardLabel')} aria-disabled={!selectedModel}>
                    {family === 'bitaxe' ? (
                      <div className="field-group">
                        <label htmlFor="board">{copy('boardVersion')}</label>
                        <select id="board" value={selectedBoard} onChange={(event) => { setSelectedBoard(event.target.value); setSelectedReleaseTag(''); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!selectedModel || isBusy}>
                          <option value="" disabled>{t('hero.selectBoard')}</option>
                          {boardOptions.map((image) => <option value={image.board} key={image.board}>{image.board}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!selectedModel ? 'disabled' : ''}`}><span>{copy('boardMatch')}</span><strong>{selectedBoard || copy('selectModelFirst')}</strong><small>{copy('boardAuto')}</small></div>
                    )}
              </section>

              <section className={`flow-stage version-stage ${!activeBoard ? 'locked' : ''}`} aria-label={copy('versionLabel')} aria-disabled={!activeBoard}>
                    {channel === 'stable' ? (
                      <div className="field-group">
                        <label htmlFor="version">{copy('stepsVersion')}</label>
                        <select id="version" value={selectedReleaseTag} onChange={(event) => { setSelectedReleaseTag(event.target.value); setKeepSettings(false); setSettingsAdvanced(false); setStatus(initialStatus) }} disabled={!activeBoard || isBusy}>
                          <option value="" disabled>{t('hero.selectFirmware')}</option>
                          {releaseSources.map((item, index) => <option value={item.releaseTag} key={item.releaseTag}>{item.releaseTag}{index === 0 ? `  •  ${copy('latest')}` : ''}</option>)}
                        </select>
                      </div>
                    ) : (
                      <div className={`firmware-detail ${!activeBoard ? 'disabled' : ''}`}><span>{copy('stepsVersion')}</span><strong>{selected?.releaseTag ?? copy('selectModel')}</strong>{selectedSource && <small>{formatDate(selectedSource.publishedAt)}</small>}</div>
                    )}
              </section>

              <section className={`flow-stage settings-stage ${!selected ? 'locked' : ''}`} aria-label={copy('settingsLabel')} aria-disabled={!selected}>
                  <label className={`settings-row ${!selected ? 'disabled' : ''}`}>
                    <span className="settings-copy"><strong>{t('hero.keepConfig')}</strong><small>{copy('keepSettingsNote')}</small></span>
                    <span className="switch"><input type="checkbox" checked={keepSettings} onChange={(event) => { setKeepSettings(event.target.checked); if (event.target.checked) setSettingsAdvanced(true) }} disabled={!selected || isBusy} /><i /></span>
                  </label>
              </section>

              <section className={`flow-stage install-stage ${!selected ? 'locked' : ''}`} aria-label={copy('installLabel')} aria-disabled={!selected}>
                  {selected && <p className="firmware-preparation-note">{copy('firmwarePreparationNote')}</p>}
                  {activeFlashSource === 'official' && status.stage !== 'idle' && (
                    <div className={`status-panel ${status.stage}`} role="status">
                      <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{['downloading', 'flashing'].includes(status.stage) && <strong>{status.progress}%</strong>}</div>
                      {['downloading', 'flashing'].includes(status.stage) && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                      {status.stage === 'complete' && <p>{copy('disconnectAfterRestart')}</p>}
                    </div>
                  )}

                  {selected && <div className="bootloader-hint"><CircleAlert size={18} /><span>{copy('bootloaderHint')}</span></div>}
                  <button className="flash-button" type="button" disabled={!minerPort || !selected || !serialAvailable || isBusy} onClick={() => selected && startFlash(selected)}><Usb size={19} /> {isBusy ? t('hero.flashing') : bootloaderRecovery && status.stage === 'error' ? copy('retryFlashing') : t('hero.startFlashing')} <ChevronRight size={18} /></button>
                  <p className="button-note">{!minerPort ? copy('connectToUnlock') : !selected ? copy('completeSelections') : copy('keepConnected')}</p>
                  {usingFallback && <p className="fallback-note">{copy('fallbackManifest')}</p>}
                  {activeFlashSource === 'official' && logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
              </section>
            </div>
          </div>}

          {activeTool === 'mujina' && <section className="custom-firmware mujina-firmware" role="tabpanel" aria-labelledby="mujina-firmware-title">
            <div className="custom-firmware-copy">
              <p className="section-label">{copy('mujinaLabel')}</p>
              <h3 id="mujina-firmware-title">{copy('mujinaTitle')}</h3>
              <p>{copy('mujinaDescription')}</p>
              <div className="custom-warning mujina-warning"><CircleAlert size={19} /><span>{copy('mujinaWarning')}</span></div>
              <fieldset className="mujina-target-selector">
                <legend>{copy('mujinaHardwareLabel')}</legend>
                <button type="button" className={mujinaTarget === 'nano3s' ? 'active' : ''} aria-pressed={mujinaTarget === 'nano3s'} disabled={isBusy} onClick={() => { setMujinaTarget('nano3s'); setStatus(initialStatus); setActiveFlashSource(null) }}><strong>{copy('mujinaNano')}</strong><small>{copy('mujinaNanoTool')}</small></button>
                <button type="button" className={mujinaTarget === 'gamma' ? 'active' : ''} aria-pressed={mujinaTarget === 'gamma'} disabled={isBusy} onClick={() => { setMujinaTarget('gamma'); setStatus(initialStatus); setActiveFlashSource(null) }}><strong>{copy('mujinaGamma')}</strong><small>{copy('mujinaGammaTool')}</small></button>
              </fieldset>
            </div>
            {mujinaTarget === 'gamma' ? (
              <div className="custom-firmware-controls mujina-gamma-route">
                <div className="mujina-route-card"><Cpu size={28} /><h4>{copy('mujinaGammaTitle')}</h4><p>{copy('mujinaGammaDescription')}</p></div>
                <button className="flash-button custom-flash-button" type="button" disabled={isBusy} onClick={() => selectTool('custom')}><FileUp size={19} /> {copy('mujinaOpenAdvanced')} <ChevronRight size={18} /></button>
              </div>
            ) : (
              <div className="custom-firmware-controls">
                {!supportsWebUsb() && <div className="browser-warning"><CircleAlert size={20} /><div><strong>{copy('mujinaWebUsbRequired')}</strong><span>{copy('mujinaWebUsbDescription')}</span></div></div>}
                <div className="bootloader-hint mujina-burn-mode"><CircleAlert size={18} /><span>{copy('mujinaBurnMode')}</span></div>
                <button className={`connect-button ${mujinaDevice ? 'connected' : ''}`} type="button" disabled={!supportsWebUsb() || isBusy} onClick={() => void connectMujinaDevice()}>
                  {mujinaDevice ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                  {mujinaDevice ? copy('mujinaDisconnect') : copy('mujinaConnect')}
                </button>
                <p className="stage-note">{mujinaDevice ? copy(mujinaDeviceMode === 'uboot' ? 'mujinaLoaderConnected' : 'mujinaBootromConnected') : copy('mujinaConnectNote')}</p>
                <label className={`custom-file-button ${!mujinaDevice || isBusy ? 'disabled' : ''}`}>
                  <FileUp size={18} />
                  <span>{mujinaFirmware ? copy('customReplace') : copy('mujinaChooseImage')}</span>
                  <input type="file" accept=".kdimg,application/octet-stream" disabled={!mujinaDevice || isBusy} onChange={(event) => void chooseMujinaFirmware(event.target.files?.[0])} />
                </label>
                {mujinaFirmware && (
                  <div className="custom-file-details mujina-image-details">
                    <strong>{mujinaFirmware.file.name}</strong>
                    <span>{(mujinaFirmware.file.size / 1024 / 1024).toFixed(2)} MB · {mujinaFirmware.partitions.length} {copy('mujinaPartitions')}</span>
                    <code>{mujinaFirmware.boardInfo || copy('mujinaK230Image')} · {mujinaFirmware.imageInfo || `KDIMG v${mujinaFirmware.version}`}</code>
                  </div>
                )}
                {mujinaFirmwareError && <p className="custom-file-error" role="alert">{mujinaFirmwareError}</p>}
                <label className={`mujina-device-confirmation ${!mujinaFirmware || isBusy ? 'disabled' : ''}`}>
                  <span className="settings-copy"><strong>{copy('mujinaEraseConfirm')}</strong><small>{copy('mujinaEraseConfirmNote')}</small></span>
                  <span className="switch"><input type="checkbox" checked={mujinaHardwareConfirmed} onChange={(event) => { setMujinaHardwareConfirmed(event.target.checked); setActiveFlashSource(null); setStatus(initialStatus) }} disabled={!mujinaFirmware || isBusy} /><i /></span>
                </label>
                {activeFlashSource === 'mujina' && status.stage !== 'idle' && (
                  <div className={`status-panel ${status.stage}`} role="status">
                    <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{['downloading', 'flashing'].includes(status.stage) && <strong>{status.progress}%</strong>}</div>
                    {['downloading', 'flashing'].includes(status.stage) && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                    {status.stage === 'complete' && <p>{copy('mujinaAfterFlash')}</p>}
                  </div>
                )}
                <button className="flash-button custom-flash-button" type="button" disabled={!mujinaDevice || !mujinaHardwareConfirmed || !mujinaFirmware || !supportsWebUsb() || isBusy} onClick={() => void startMujinaFlash()}><Usb size={19} /> {isBusy ? t('hero.flashing') : copy('mujinaFlash')} <ChevronRight size={18} /></button>
                <p className="button-note">{!mujinaDevice ? copy('mujinaConnectFirst') : !mujinaFirmware ? copy('mujinaChooseFirst') : !mujinaHardwareConfirmed ? copy('mujinaConfirmFirst') : copy('customLocalOnly')}</p>
                {activeFlashSource === 'mujina' && logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
              </div>
            )}
          </section>}

          {activeTool === 'custom' && <section className="custom-firmware" role="tabpanel" aria-labelledby="custom-firmware-title">
            <div className="custom-firmware-copy">
              <p className="section-label">{copy('customLabel')}</p>
              <h3 id="custom-firmware-title">{copy('customTitle')}</h3>
              <p>{copy('customDescription')}</p>
              <div className="custom-warning"><CircleAlert size={19} /><span>{copy('customWarning')}</span></div>
            </div>
            <div className="custom-firmware-controls">
              <button className={`connect-button ${minerPort ? 'connected' : ''}`} type="button" disabled={!serialAvailable || isBusy} onClick={() => void connectMiner('custom')}>
                {minerPort ? <CheckCircle2 size={18} /> : <Usb size={18} />}
                {minerPort ? t('hero.disconnect') : t('hero.connect')}
              </button>
              <p className="stage-note">{copy('connectNote')}</p>
              <label className={`custom-file-button ${!minerPort || isBusy ? 'disabled' : ''}`}>
                <FileUp size={18} />
                <span>{customFirmware ? copy('customReplace') : copy('customChoose')}</span>
                <input type="file" accept=".bin,application/octet-stream" disabled={!minerPort || isBusy} onChange={(event) => void chooseCustomFirmware(event.target.files?.[0])} />
              </label>
              {customFirmware && (
                <div className="custom-file-details">
                  <strong>{customFirmware.name}</strong>
                  <span>{(customFirmware.bytes.length / 1024 / 1024).toFixed(2)} MB</span>
                  <code>SHA-256 {customFirmware.digest}</code>
                </div>
              )}
              {customFirmwareError && <p className="custom-file-error" role="alert">{customFirmwareError}</p>}
              {activeFlashSource === 'custom' && status.stage !== 'idle' && (
                <div className={`status-panel ${status.stage}`} role="status">
                  <div className="status-title">{status.stage === 'complete' ? <CheckCircle2 size={19} /> : status.stage === 'error' ? <CircleAlert size={19} /> : <RefreshCw className="spin" size={19} />}<span>{status.message}</span>{status.stage === 'flashing' && <strong>{status.progress}%</strong>}</div>
                  {status.stage === 'flashing' && <progress className="progress-track" max="100" value={status.progress} aria-label={copy('progressLabel')}>{status.progress}%</progress>}
                  {status.stage === 'complete' && <p>{copy('disconnectAfterRestart')}</p>}
                </div>
              )}
              {customFirmware && <div className="bootloader-hint"><CircleAlert size={18} /><span>{copy('bootloaderHint')}</span></div>}
              <button className="flash-button custom-flash-button" type="button" disabled={!minerPort || !customFirmware || !serialAvailable || isBusy} onClick={() => void startCustomFlash()}><Usb size={19} /> {isBusy ? t('hero.flashing') : bootloaderRecovery && status.stage === 'error' ? copy('retryFlashing') : t('hero.startFlashing')} <ChevronRight size={18} /></button>
              <p className="button-note">{!minerPort ? copy('customConnectFirst') : copy('customLocalOnly')}</p>
              {activeFlashSource === 'custom' && logs.length > 0 && <details className="logs"><summary>{copy('technicalLog')}</summary><pre>{logs.join('\n')}</pre></details>}
            </div>
          </section>}
        </section>

        <section className="preflight" id="how-it-works">
          <div className="preflight-intro">
            <p className="section-label">{copy('beforeConnecting')}</p>
            <h2>{copy('threeChecks')}</h2>
            <p>{copy('checksIntro')}</p>
          </div>
          <ol className="preflight-list">
            <li><span>1</span><div><strong>{copy('dataCable')}</strong><p>{copy('dataCableNote')}</p></div></li>
            <li><span>2</span><div><strong>{copy('matchBoard')}</strong><p>{copy('matchBoardNote')}</p></div></li>
            <li><span>3</span><div><strong>{copy('stablePower')}</strong><p>{copy('stablePowerNote')}</p></div></li>
          </ol>
        </section>

        <section className="provenance">
          <div className="provenance-icon"><ShieldCheck size={23} /></div>
          <div><p className="section-label">{copy('verifiable')}</p><h2>{copy('provenanceTitle')}</h2><p>{copy('provenanceText')}</p></div>
          <div className="source-links">{selected && <a href={selected.releaseUrl} target="_blank" rel="noopener noreferrer">{copy('viewRelease')}<ExternalLink size={14} /></a>}{selectedSource && <a href={selectedSource.sourceArchiveUrl} target="_blank" rel="noopener noreferrer">{copy('downloadSource')}<ExternalLink size={14} /></a>}</div>
        </section>

        <section className="device-support" aria-labelledby="support-title">
          <div className="support-heading"><p className="section-label">{copy('deviceSupport')}</p><h2 id="support-title">{copy('supportTitle')}</h2><p>{copy('supportText')}</p></div>
          <div className="support-list">
            <article><h3>Bitaxe</h3><p>{copy('bitaxeModels')}</p></article>
            <article><h3>NerdAxe</h3><p>{copy('nerdaxeModels')}</p></article>
          </div>
        </section>

        <section className="faq" id="faq" aria-labelledby="faq-title">
          <div><p className="section-label">{copy('questions')}</p><h2 id="faq-title">{copy('faqTitle')}</h2></div>
          <div className="faq-list">
            <details><summary>{copy('faq1q')}</summary><p>{copy('faq1a')}</p></details>
            <details><summary>{copy('faq2q')}</summary><p>{copy('faq2a')}</p></details>
            <details><summary>{copy('faq3q')}</summary><p>{copy('faq3a')}</p></details>
            <details><summary>{copy('faq4q')}</summary><p>{copy('faq4a')}</p></details>
            <details><summary>{copy('faq5q')}</summary><p>{copy('faq5a')}</p></details>
            <details><summary>{copy('faq6q')}</summary><p>{copy('faq6a')}</p></details>
            <details><summary>{copy('faq7q')}</summary><p>{copy('faq7a')}</p></details>
            <details><summary>{copy('faq8q')}</summary><p>{copy('faq8a')}</p></details>
            <details><summary>{copy('faq9q')}</summary><p>{copy('faq9a')}</p></details>
            <details><summary>{copy('faq10q')}</summary><p>{copy('faq10a')}</p></details>
            <details><summary>{copy('faq11q')}</summary><p>{copy('faq11a')}</p></details>
          </div>
        </section>

        <section className="legal-notice" aria-labelledby="legal-title">
          <div>
            <p className="section-label">{copy('policies')}</p>
            <h2 id="legal-title">{copy('legalTitle')}</h2>
          </div>
          <div className="legal-copy">
            <p>{copy('legalText')}</p>
            <nav aria-label={copy('policies')}>
              <a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacyPolicy')}</a>
              <a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('termsService')}</a>
              <a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licensesSource')}</a>
            </nav>
          </div>
        </section>

      </main>

      <footer className="site-footer">
        <div className="footer-row">
          <a className="brand footer-brand" href="https://www.solosatoshi.com" target="_blank" rel="noopener noreferrer" aria-label={copy('homeNewTab')}><img className="brand-logo" src={`${import.meta.env.BASE_URL}solo-satoshi-logo.webp`} alt="" width="34" height="34" /><span className="brand-name">SOLO SATOSHI</span></a>
          <span className="footer-copyright">{copy('rights')}</span>
          <nav className="social-links" aria-label={copy('socialLabel')}>
            {socialLinks.map(({ label, href, icon }) => (
              <a href={href} target="_blank" rel="me noopener noreferrer" aria-label={`${label} (${copy('opensNewTab')})`} title={label} key={label}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d={icon.path} /></svg>
              </a>
            ))}
          </nav>
          <nav className="footer-policies" aria-label={copy('footerPolicies')}><a href={`${import.meta.env.BASE_URL}privacy.html`}>{copy('privacy')}</a><a href={`${import.meta.env.BASE_URL}terms.html`}>{copy('terms')}</a><a href={`${import.meta.env.BASE_URL}licenses.html`}>{copy('licenses')}</a></nav>
        </div>
      </footer>
        </>
      )}
    </div>
  )
}

export default App
