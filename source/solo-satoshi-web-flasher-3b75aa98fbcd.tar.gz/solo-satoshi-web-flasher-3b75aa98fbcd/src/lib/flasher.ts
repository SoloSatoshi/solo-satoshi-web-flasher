/*
 * Solo Satoshi Web Flasher
 * Copyright (C) 2026 Solo Satoshi LLC
 * SPDX-License-Identifier: GPL-3.0-only
 * See NOTICE.md for upstream attribution.
 */

import { ESPLoader, Transport } from 'esptool-js'
import type { IEspLoaderTerminal } from 'esptool-js/lib/types/loaderTerminal.js'
import { createFlashSegments } from './firmware'
import { supportsWebSerial } from './browserCompatibility'

interface FlashCallbacks {
  expectedChip?: string
  onConnecting: (message: string) => void
  onProgress: (progress: number) => void
  onRestarting: (message: string) => void
  onLog: (line: string) => void
}

const sleep = (milliseconds: number) => new Promise((resolve) => window.setTimeout(resolve, milliseconds))
const FLASH_BAUD_RATE = 921600

export class BootloaderConnectionError extends Error {
  readonly originalError: unknown

  constructor(originalError: unknown) {
    super(originalError instanceof Error ? originalError.message : 'The miner did not respond in bootloader mode.')
    this.name = 'BootloaderConnectionError'
    this.originalError = originalError
  }
}

export class IncompatibleChipError extends Error {
  constructor(chip: string, expectedChip: string) {
    super(`Connected chip ${chip} does not match required chip ${expectedChip}.`)
    this.name = 'IncompatibleChipError'
  }
}

async function restartMiner(transport: Transport): Promise<void> {
  // Match the explicit reset pulse used by the upstream Bitaxe and NerdAxe
  // flashers. DTR must be released so GPIO0 stays high for a normal boot, then
  // RTS briefly pulls EN low before releasing it again.
  await transport.setDTR(false)
  await transport.setRTS(true)
  await sleep(100)
  await transport.setRTS(false)
  await sleep(500)
}

export function requestMinerPort(): Promise<SerialPort> {
  if (!supportsWebSerial()) throw new Error('Web Serial is not supported in this browser.')
  return navigator.serial.requestPort()
}

export async function flashFirmware(port: SerialPort, firmware: Uint8Array, keepSettings: boolean, callbacks: FlashCallbacks): Promise<string> {
  const transport = new Transport(port, false)
  const terminal: IEspLoaderTerminal = {
    clean: () => undefined,
    write: (data) => callbacks.onLog(data),
    writeLine: (data) => callbacks.onLog(data),
  }
  // Connect at the ROM-safe speed, then let esptool-js negotiate the faster
  // transfer rate. The library automatically returns to the ROM rate when the
  // chip or serial transport does not respond after the switch.
  const loader = new ESPLoader({ transport, baudrate: FLASH_BAUD_RATE, romBaudrate: 115200, terminal, debugLogging: false })
  try {
    callbacks.onConnecting('Connecting to the miner…')
    let chip: string
    try {
      chip = await loader.main('default_reset')
    } catch (error) {
      throw new BootloaderConnectionError(error)
    }
    if (callbacks.expectedChip && loader.chip.CHIP_NAME.toUpperCase() !== callbacks.expectedChip.toUpperCase()) {
      throw new IncompatibleChipError(loader.chip.CHIP_NAME, callbacks.expectedChip)
    }
    callbacks.onConnecting(`Connected to ${chip}. Writing firmware…`)
    const segments = createFlashSegments(firmware, keepSettings)
    const totalBytes = segments.reduce((sum, segment) => sum + segment.data.length, 0)
    const completedBefore = segments.map((_, index) => segments.slice(0, index).reduce((sum, segment) => sum + segment.data.length, 0))
    await loader.writeFlash({
      fileArray: segments, flashMode: 'keep', flashFreq: 'keep', flashSize: 'keep', eraseAll: false, compress: true,
      reportProgress: (fileIndex, written) => {
        const complete = completedBefore[fileIndex] + written
        callbacks.onProgress(Math.min(100, Math.round((complete / totalBytes) * 100)))
      },
    })
    callbacks.onProgress(100)
    callbacks.onRestarting('Firmware installed. Restarting the miner automatically…')
    await restartMiner(transport)
    return chip
  } finally {
    try { await transport.disconnect() } catch { /* Reset may close the port first. */ }
  }
}
