export type FirmwareFamily = 'bitaxe' | 'nerdaxe'
export type ReleaseChannel = 'stable' | 'beta'

export interface FirmwareSource {
  family: FirmwareFamily
  channel: ReleaseChannel
  repository: string
  releaseTag: string
  releaseUrl: string
  publishedAt: string
  sourceArchiveUrl: string
}

export interface FirmwareImage {
  id: string
  family: FirmwareFamily
  channel: ReleaseChannel
  model: string
  board: string
  supportedSince?: string
  releaseTag: string
  assetName: string
  size: number
  sha256: string
  downloadUrl: string
  sourceRepository: string
  releaseUrl: string
}

export interface FirmwareManifest {
  schemaVersion: 2
  generatedAt: string
  sources: FirmwareSource[]
  firmware: FirmwareImage[]
}

export type FlashStage = 'idle' | 'downloading' | 'connecting' | 'flashing' | 'complete' | 'error'

export interface FlashStatus {
  stage: FlashStage
  message: string
  progress: number
}
