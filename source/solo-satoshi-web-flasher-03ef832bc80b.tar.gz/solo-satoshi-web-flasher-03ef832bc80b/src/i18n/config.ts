import i18n from 'i18next'
import LanguageDetector from 'i18next-browser-languagedetector'
import { initReactI18next } from 'react-i18next'
import de from './locales/de.json'
import en from './locales/en.json'
import it from './locales/it.json'
import pt from './locales/pt.json'
import ro from './locales/ro.json'
import ru from './locales/ru.json'
import sk from './locales/sk.json'
import tlh from './locales/tlh.json'
import tr from './locales/tr.json'

export const supportedLanguages = [
  { value: 'en', label: 'English' },
  { value: 'de', label: 'Deutsch' },
  { value: 'it', label: 'Italiano' },
  { value: 'tlh', label: 'Klingon' },
  { value: 'pt', label: 'Portuguese' },
  { value: 'ru', label: 'Русский' },
  { value: 'tr', label: 'Türkçe' },
  { value: 'sk', label: 'Slovenský' },
  { value: 'ro', label: 'Română' },
] as const

void i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: en },
      de: { translation: de },
      it: { translation: it },
      tlh: { translation: tlh },
      pt: { translation: pt },
      ru: { translation: ru },
      tr: { translation: tr },
      sk: { translation: sk },
      ro: { translation: ro },
    },
    fallbackLng: 'en',
    supportedLngs: supportedLanguages.map(({ value }) => value),
    nonExplicitSupportedLngs: true,
    interpolation: { escapeValue: false },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
      lookupLocalStorage: 'soloSatoshiFlasherLanguage',
    },
  })

export default i18n
