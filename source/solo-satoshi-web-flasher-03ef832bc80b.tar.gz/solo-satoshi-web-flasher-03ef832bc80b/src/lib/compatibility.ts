import type { FirmwareFamily, FirmwareImage, FirmwareManifest, FirmwareSource, ReleaseChannel } from '../types'

export function getChannelSources(manifest: FirmwareManifest | null, family: FirmwareFamily, channel: ReleaseChannel): FirmwareSource[] {
  return manifest?.sources
    .filter((source) => source.family === family && source.channel === channel)
    .sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt)) ?? []
}

export function getLatestModelImages(manifest: FirmwareManifest | null, family: FirmwareFamily, channel: ReleaseChannel, sources: FirmwareSource[]): FirmwareImage[] {
  const images = manifest?.firmware.filter((image) =>
    image.family === family && image.channel === channel && image.releaseTag === sources[0]?.releaseTag
  ) ?? []

  const publishedAt = new Map(
    manifest?.sources.map((source) => [`${source.family}:${source.channel}:${source.releaseTag}`, Date.parse(source.publishedAt)]) ?? [],
  )
  const firstKnownSupport = new Map<string, number>()
  for (const image of manifest?.firmware ?? []) {
    const declared = image.supportedSince ? Date.parse(image.supportedSince) : Number.NaN
    const observed = publishedAt.get(`${image.family}:${image.channel}:${image.releaseTag}`) ?? Number.NaN
    const supportedAt = Number.isFinite(declared) ? declared : observed
    if (!Number.isFinite(supportedAt)) continue
    const key = `${image.family}:${image.board}`
    firstKnownSupport.set(key, Math.min(firstKnownSupport.get(key) ?? supportedAt, supportedAt))
  }

  return images.sort((a, b) => {
    const aDate = firstKnownSupport.get(`${a.family}:${a.board}`) ?? 0
    const bDate = firstKnownSupport.get(`${b.family}:${b.board}`) ?? 0
    return bDate - aDate || a.model.localeCompare(b.model) || a.board.localeCompare(b.board, undefined, { numeric: true })
  })
}

export function getCompatibleReleaseSources(manifest: FirmwareManifest | null, family: FirmwareFamily, channel: ReleaseChannel, board: string | undefined, sources: FirmwareSource[]): FirmwareSource[] {
  return sources.filter((source) => manifest?.firmware.some((image) =>
    image.family === family && image.channel === channel && image.board === board && image.releaseTag === source.releaseTag
  ))
}
